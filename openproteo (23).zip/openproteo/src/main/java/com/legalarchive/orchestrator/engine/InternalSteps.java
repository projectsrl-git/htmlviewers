package com.legalarchive.orchestrator.engine;

import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.legalarchive.orchestrator.ds.DataSourceDef;
import com.legalarchive.orchestrator.ds.DataSourceStore;
import com.legalarchive.orchestrator.ds.IfsSupport;
import com.legalarchive.orchestrator.ds.SqlSupport;
import com.legalarchive.orchestrator.model.def.StepDef;
import com.legalarchive.orchestrator.model.def.Replacement;

/**
 * Executes the built-in step kinds in-process (no external process):
 *   sql      - run a query on a datasource; emit rowCount and first-row columns as vars
 *   ifscopy  - native IFS copy from AS400 to a local directory (JTOpen)
 *   filecopy - copy/move/list files between local directories by glob pattern
 *   setvar   - assign/compute run variables (supports simple +/- integer math)
 *
 * Each method writes a timestamped log to the step log file and returns a
 * StepExecutor.Result so the engine treats internal and external steps uniformly.
 */
@Component
public class InternalSteps {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private final DataSourceStore dataSources;
    private final SqlSupport sql;
    private final IfsSupport ifs;

    public InternalSteps(DataSourceStore dataSources, SqlSupport sql, IfsSupport ifs) {
        this.dataSources = dataSources;
        this.sql = sql;
        this.ifs = ifs;
    }

    public StepExecutor.Result run(String kind, StepDef step, Map<String, String> resolvedParams,
                                   Map<String, String> vars, Path logFile, RunControl control,
                                   com.legalarchive.orchestrator.model.run.StepExec se, Runnable onProgress) {
        StepExecutor.Result res = new StepExecutor.Result();
        BufferedWriter log = null;
        try {
            Files.createDirectories(logFile.getParent());
            log = Files.newBufferedWriter(logFile, StandardCharsets.UTF_8,
                    java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
            final BufferedWriter flog = log;
            java.util.function.Consumer<String> line = new java.util.function.Consumer<String>() {
                public void accept(String s) {
                    try { flog.write("O\t" + LocalDateTime.now().format(TS) + "\t" + s); flog.newLine(); flog.flush(); }
                    catch (Exception ignored) {}
                }
            };

            if (control != null && control.aborted) { line.accept("aborted before start"); res.exitCode = -997; return res; }

            if ("sql".equals(kind)) {
                runSql(step, resolvedParams, vars, res, line);
            } else if ("ifscopy".equals(kind)) {
                runIfsCopy(step, vars, res, line);
            } else if ("filecopy".equals(kind)) {
                runFileCopy(step, vars, res, line);
            } else if ("setvar".equals(kind)) {
                runSetVar(resolvedParams, vars, res, line);
            } else if ("validate".equals(kind)) {
                runValidate(step, resolvedParams, vars, res, line, se, onProgress);
            } else if ("csvreplace".equals(kind)) {
                runReplace(step, resolvedParams, vars, res, line);
            } else {
                line.accept("unknown internal step kind: " + kind);
                res.exitCode = -996;
            }
        } catch (Exception e) {
            res.exitCode = res.exitCode == 0 ? 1 : res.exitCode;
            res.lastLines = e.getMessage();
            safeLine(log, "ERROR: " + e.getMessage());
        } finally {
            if (log != null) try { log.close(); } catch (Exception ignored) {}
        }
        return res;
    }

    // ----------------------------------------------------------------- sql
    private void runSql(StepDef step, Map<String, String> params, Map<String, String> vars,
                        StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        DataSourceDef d = dataSources.get(step.datasource);
        if (d == null) { line.accept("datasource not found: " + step.datasource); res.exitCode = 2; return; }
        String query = VarResolver.resolve(step.query, vars);
        line.accept("datasource: " + d.id + " (" + d.type + ")");
        line.accept("query: " + query);

        // CSV export path: stream the full result set to a file
        String csvFile = VarResolver.resolve(step.csvFile, vars);
        boolean trim = !"false".equalsIgnoreCase(params.get("trim"));   // CHAR padding: trimmed by default
        if (csvFile != null && !csvFile.trim().isEmpty()) {
            char delim = (step.delimiter != null && !step.delimiter.isEmpty()) ? step.delimiter.charAt(0) : ';';
            java.io.File out = new java.io.File(csvFile);
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            long maxRows = step.csvSplitRows > 0 ? step.csvSplitRows : 0;
            long maxBytes = step.csvSplitMb > 0 ? (long) step.csvSplitMb * 1024L * 1024L : 0;
            SqlSupport.ExportResult er = sql.exportCsv(d, query, out, delim, true, maxRows, maxBytes, trim);
            res.outVars.put("rowCount", String.valueOf(er.rows));
            res.outVars.put("csvParts", String.valueOf(er.parts));
            res.outVars.put("csvFile", er.files.isEmpty() ? out.getAbsolutePath() : er.files.get(0));
            res.outVars.put("csvFiles", String.join(step.delimiter == null ? ";" : step.delimiter, er.files));
            if (er.parts > 1) line.accept("exported " + er.rows + " row(s) into " + er.parts + " CSV part(s)");
            else line.accept("exported " + er.rows + " row(s) to " + res.outVars.get("csvFile"));
            for (String f : er.files) line.accept("  " + f);
            for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
            res.exitCode = 0;
            return;
        }

        SqlSupport.QueryResult qr = sql.run(d, query, 1000, trim);
        if (qr.updateCount != null) {
            line.accept("update count: " + qr.updateCount);
            res.outVars.put("updateCount", String.valueOf(qr.updateCount));
        } else {
            line.accept("returned rows: " + qr.rowCount + (qr.truncated ? " (truncated at 1000)" : ""));
            res.outVars.put("rowCount", String.valueOf(qr.rowCount));
            // first row columns exposed as ${col_<NAME>}
            if (!qr.rows.isEmpty()) {
                List<String> r0 = qr.rows.get(0);
                for (int i = 0; i < qr.columns.size() && i < r0.size(); i++) {
                    res.outVars.put("col_" + qr.columns.get(i), r0.get(i));
                }
                res.outVars.put("firstValue", SqlSupport.firstValue(qr));
            }
            // optional: store all first-column values joined, for downstream steps
            if (step.outputVar != null && !step.outputVar.trim().isEmpty() && !qr.columns.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (List<String> r : qr.rows) { if (sb.length() > 0) sb.append(step.delimiter == null ? ";" : step.delimiter); sb.append(r.get(0)); }
                res.outVars.put(step.outputVar.trim(), sb.toString());
            }
        }
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // ------------------------------------------------------------- ifscopy
    private void runIfsCopy(StepDef step, Map<String, String> vars,
                            StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        DataSourceDef d = dataSources.get(step.datasource);
        if (d == null) { line.accept("datasource not found: " + step.datasource); res.exitCode = 2; return; }
        String ifsPath = VarResolver.resolve(step.ifsPath, vars);
        String dest = VarResolver.resolve(step.dest, vars);
        String glob = VarResolver.resolve(step.pattern, vars);
        line.accept("IFS copy " + ifsPath + "  ->  " + dest + "  (pattern " + (glob == null ? "*" : glob) + ")");
        IfsSupport.CopyResult cr = ifs.copyToLocal(d, ifsPath, dest, glob, step.overwrite, line);
        res.outVars.put("filesCopied", String.valueOf(cr.filesCopied));
        res.outVars.put("bytesCopied", String.valueOf(cr.bytesCopied));
        res.outVars.put("matchedFiles", String.join(step.delimiter == null ? ";" : step.delimiter, cr.names));
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // ------------------------------------------------------------ filecopy
    private void runFileCopy(StepDef step, Map<String, String> vars,
                             StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        String source = VarResolver.resolve(step.source, vars);
        String dest = VarResolver.resolve(step.dest, vars);
        String glob = VarResolver.resolve(step.pattern, vars);
        String mode = step.mode == null ? "copy" : step.mode.toLowerCase(); // copy | move | list
        if (glob == null || glob.trim().isEmpty()) glob = "*";

        Path src = Paths.get(source);
        if (!Files.isDirectory(src)) { line.accept("source directory not found: " + source); res.exitCode = 2; return; }
        line.accept(mode + "  " + source + "  pattern " + glob + (("list".equals(mode)) ? "" : ("  -> " + dest)));

        List<String> names = new ArrayList<String>();
        long bytes = 0;
        Path outDir = null;
        if (!"list".equals(mode)) {
            outDir = Paths.get(dest);
            Files.createDirectories(outDir);
        }
        DirectoryStream<Path> ds = Files.newDirectoryStream(src, glob);
        try {
            for (Path f : ds) {
                if (Files.isDirectory(f)) continue;
                names.add(f.getFileName().toString());
                if ("list".equals(mode)) continue;
                Path target = outDir.resolve(f.getFileName());
                if ("move".equals(mode)) {
                    Files.move(f, target, StandardCopyOption.REPLACE_EXISTING);
                } else {
                    Files.copy(f, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                }
                bytes += Files.size(target);
                line.accept(mode + " " + f.getFileName());
            }
        } finally {
            ds.close();
        }
        res.outVars.put("matchedCount", String.valueOf(names.size()));
        res.outVars.put("matchedFiles", String.join(step.delimiter == null ? ";" : step.delimiter, names));
        if (!"list".equals(mode)) res.outVars.put("bytesCopied", String.valueOf(bytes));
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // -------------------------------------------------------------- setvar
    /** params are name -> expression; expressions support ${vars} and simple a + b / a - b integer math. */
    private void runSetVar(Map<String, String> params, Map<String, String> vars,
                           StepExecutor.Result res, java.util.function.Consumer<String> line) {
        for (Map.Entry<String, String> e : params.entrySet()) {
            String value = evalArithmetic(e.getValue());
            res.outVars.put(e.getKey(), value);
            line.accept("##VAR " + e.getKey() + "=" + value);
        }
        res.exitCode = 0;
    }

    /** Evaluate "A + B" or "A - B" as integers when both sides are integers; otherwise return as-is. */
    private String evalArithmetic(String expr) {
        if (expr == null) return "";
        String s = expr.trim();
        for (String op : new String[]{"+", "-"}) {
            int idx = s.indexOf(' ' + op + ' ');
            if (idx > 0) {
                String a = s.substring(0, idx).trim();
                String b = s.substring(idx + 3).trim();
                try {
                    long la = Long.parseLong(a), lb = Long.parseLong(b);
                    return String.valueOf("+".equals(op) ? la + lb : la - lb);
                } catch (NumberFormatException ignored) {
                    return s;
                }
            }
        }
        return s;
    }

    // -------------------------------------------------------------- csvreplace
    private void runReplace(StepDef step, Map<String, String> params, Map<String, String> vars,
                            StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        String inPath = VarResolver.resolve(step.source, vars);
        char delim = (step.delimiter != null && !step.delimiter.isEmpty()) ? step.delimiter.charAt(0) : ';';
        boolean hasHeader = !"false".equalsIgnoreCase(params.get("hasHeader"));
        String outParam = blankToNull(VarResolver.resolve(params.get("outFile"), vars));

        java.io.File in = new java.io.File(inPath);
        if (!in.isFile()) { line.accept("csvreplace: input not found: " + inPath); res.exitCode = 2; return; }
        if (step.replacements == null || step.replacements.isEmpty()) { line.accept("csvreplace: no replacements configured"); res.exitCode = 0; res.outVars.put("outputFile", in.getAbsolutePath()); return; }

        // output: a new file (or overwrite). Default = <name>_replaced.<ext> next to the input.
        java.io.File out = outParam != null ? new java.io.File(outParam)
                : new java.io.File(in.getParentFile(), stripExt(in.getName()) + "_replaced" + ext(in.getName()));
        boolean inPlace = out.getAbsolutePath().equals(in.getAbsolutePath());
        java.io.File target = inPlace ? new java.io.File(in.getParentFile(), in.getName() + ".tmp") : out;
        if (target.getParentFile() != null) target.getParentFile().mkdirs();

        line.accept("csvreplace " + in.getAbsolutePath() + " -> " + out.getAbsolutePath() + "  (" + step.replacements.size() + " rule(s))");

        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(in), StandardCharsets.UTF_8), 1 << 16);
        java.io.Writer w = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(target), StandardCharsets.UTF_8), 1 << 16);
        long rows = 0, hits = 0;
        long[] perRule = new long[step.replacements.size()];
        try {
            r.mark(2); int first = r.read(); boolean hadBom = first == 0xFEFF; if (!hadBom) r.reset();
            if (hadBom) w.write('\uFEFF');

            String[] headerCols = null;
            String header = hasHeader ? r.readLine() : null;
            if (header != null) { headerCols = splitSimple(header, delim).toArray(new String[0]); w.write(header); w.write("\r\n"); }

            // resolve target column indices per rule (empty = all fields => null)
            java.util.List<int[]> ruleCols = new ArrayList<int[]>();
            for (Replacement rp : step.replacements) {
                if (rp.columns == null || rp.columns.isEmpty()) { ruleCols.add(null); continue; }
                java.util.List<Integer> idxs = new ArrayList<Integer>();
                for (String cn : rp.columns) {
                    int found = -1;
                    if (headerCols != null) for (int i = 0; i < headerCols.length; i++) if (headerCols[i].trim().equals(cn.trim())) { found = i; break; }
                    if (found >= 0) idxs.add(found);
                    else line.accept("  warning: column '" + cn + "' not found in header (rule skipped for it)");
                }
                int[] arr = new int[idxs.size()]; for (int i = 0; i < arr.length; i++) arr[i] = idxs.get(i);
                ruleCols.add(arr);
            }

            String ln;
            StringBuilder sb = new StringBuilder();
            while ((ln = r.readLine()) != null) {
                rows++;
                java.util.List<String> f = splitSimple(ln, delim);
                for (int ri = 0; ri < step.replacements.size(); ri++) {
                    Replacement rp = step.replacements.get(ri);
                    if (rp.from == null || rp.from.isEmpty()) continue;
                    int[] cols = ruleCols.get(ri);
                    if (cols == null) {
                        for (int ci = 0; ci < f.size(); ci++) {
                            String v = f.get(ci);
                            if (v.indexOf(rp.from) >= 0) { f.set(ci, v.replace(rp.from, rp.to == null ? "" : rp.to)); hits++; perRule[ri]++; }
                        }
                    } else {
                        for (int ci : cols) {
                            if (ci >= f.size()) continue;
                            String v = f.get(ci);
                            if (v.indexOf(rp.from) >= 0) { f.set(ci, v.replace(rp.from, rp.to == null ? "" : rp.to)); hits++; perRule[ri]++; }
                        }
                    }
                }
                sb.setLength(0);
                for (int ci = 0; ci < f.size(); ci++) { if (ci > 0) sb.append(delim); sb.append(f.get(ci)); }
                w.write(sb.toString()); w.write("\r\n");
            }
        } finally {
            try { r.close(); } catch (Exception ignored) {}
            try { w.flush(); w.close(); } catch (Exception ignored) {}
        }

        if (inPlace) {
            java.nio.file.Files.move(target.toPath(), in.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            out = in;
        }
        for (int ri = 0; ri < perRule.length; ri++) {
            Replacement rp = step.replacements.get(ri);
            line.accept("  rule '" + rp.from + "' -> '" + (rp.to == null ? "" : rp.to) + "'" +
                    (rp.columns == null || rp.columns.isEmpty() ? " [all]" : " " + rp.columns) + ": " + perRule[ri] + " replacement(s)");
        }
        res.outVars.put("outputFile", out.getAbsolutePath());
        res.outVars.put("rowCount", String.valueOf(rows));
        res.outVars.put("replacements", String.valueOf(hits));
        line.accept("##VAR outputFile=" + out.getAbsolutePath());
        line.accept("##VAR rowCount=" + rows);
        line.accept("##VAR replacements=" + hits);
        line.accept("csvreplace finished: " + hits + " replacement(s) over " + rows + " row(s)");
        res.exitCode = 0;
    }

    private static String ext(String name) { int d = name.lastIndexOf('.'); return d > 0 ? name.substring(d) : ".csv"; }

    // -------------------------------------------------------------- validate
    private final com.fasterxml.jackson.databind.ObjectMapper jsonMapper = new com.fasterxml.jackson.databind.ObjectMapper();

    private static String checkLabel(String id) {
        if ("rowCount".equals(id)) return "Row count matches expected";
        if ("colCount".equals(id)) return "Column count consistent (dataschema)";
        if ("jsonSchema".equals(id)) return "Schema JSON well-formed";
        if ("noQuotes".equals(id)) return "No double quotes inside fields";
        if ("colNames".equals(id)) return "Column names match dataschema";
        if ("notNull".equals(id)) return "Non-nullable fields are valued";
        if ("businessDate".equals(id)) return "Business date valued and well-formatted";
        if ("displayDates".equals(id)) return "Display-schema date columns well-formatted";
        return id;
    }

    @SuppressWarnings("unchecked")
    private void runValidate(StepDef step, Map<String, String> params, Map<String, String> vars,
                             StepExecutor.Result res, java.util.function.Consumer<String> line,
                             com.legalarchive.orchestrator.model.run.StepExec se, Runnable onProgress) throws Exception {
        java.util.List<String> selected = (step.validateChecks == null || step.validateChecks.isEmpty())
                ? java.util.Arrays.asList("rowCount", "colCount", "jsonSchema", "noQuotes", "colNames", "notNull", "businessDate", "displayDates")
                : step.validateChecks;

        // seed checklist (PENDING) so the UI shows the sub-steps immediately
        final java.util.List<com.legalarchive.orchestrator.model.run.CheckResult> checks = new ArrayList<com.legalarchive.orchestrator.model.run.CheckResult>();
        for (String id : selected) checks.add(new com.legalarchive.orchestrator.model.run.CheckResult(id, checkLabel(id)));
        if (se != null) { se.checks = checks; if (onProgress != null) onProgress.run(); }

        final java.util.Map<String, com.legalarchive.orchestrator.model.run.CheckResult> byId =
                new java.util.HashMap<String, com.legalarchive.orchestrator.model.run.CheckResult>();
        for (com.legalarchive.orchestrator.model.run.CheckResult c : checks) byId.put(c.id, c);

        // inputs
        String csvPath = VarResolver.resolve(step.source, vars);
        char delim = (step.delimiter != null && !step.delimiter.isEmpty()) ? step.delimiter.charAt(0) : ';';
        boolean hasHeader = !"false".equalsIgnoreCase(params.get("hasHeader"));
        String dataschemaPath = blankToNull(params.get("dataschema"));
        String displayschemaPath = blankToNull(params.get("displayschema"));
        String bizCol = blankToNull(params.get("businessDateColumn"));
        String dateFormat = blankToNull(params.get("dateFormat"));
        Long expected = null;
        try { if (params.get("expectedRows") != null) expected = Long.parseLong(params.get("expectedRows").trim()); } catch (Exception ignore) {}

        line.accept("validate " + csvPath + "  (delimiter '" + delim + "', header=" + hasHeader + ")");

        java.util.function.BiConsumer<String, String[]> set = new java.util.function.BiConsumer<String, String[]>() {
            public void accept(String id, String[] sd) {
                com.legalarchive.orchestrator.model.run.CheckResult c = byId.get(id);
                if (c == null) return;
                c.status = sd[0]; c.detail = sd[1];
                line.accept("[check] " + id + " -> " + sd[0] + (sd[1] != null ? ("  " + sd[1]) : ""));
                if (onProgress != null) onProgress.run();
            }
        };
        boolean sel_rowCount = byId.containsKey("rowCount");
        boolean sel_colCount = byId.containsKey("colCount");
        boolean sel_json = byId.containsKey("jsonSchema");
        boolean sel_noQuotes = byId.containsKey("noQuotes");
        boolean sel_colNames = byId.containsKey("colNames");
        boolean sel_notNull = byId.containsKey("notNull");
        boolean sel_biz = byId.containsKey("businessDate");
        boolean sel_disp = byId.containsKey("displayDates");

        // --- parse schemas (also serves the jsonSchema well-formed check) ---
        java.util.List<Map<String, Object>> dataschema = null;
        java.util.List<Map<String, Object>> displayschema = null;
        String jsonErr = null;
        if (dataschemaPath != null) {
            try { dataschema = (java.util.List<Map<String, Object>>) (java.util.List<?>) jsonMapper.readValue(new java.io.File(dataschemaPath), java.util.List.class); }
            catch (Exception e) { jsonErr = "dataschema: " + e.getMessage(); }
        }
        if (displayschemaPath != null) {
            try { displayschema = (java.util.List<Map<String, Object>>) (java.util.List<?>) jsonMapper.readValue(new java.io.File(displayschemaPath), java.util.List.class); }
            catch (Exception e) { jsonErr = (jsonErr == null ? "" : jsonErr + "; ") + "displayschema: " + e.getMessage(); }
        }
        if (sel_json) {
            if (dataschemaPath == null && displayschemaPath == null) set.accept("jsonSchema", new String[]{"SKIP", "no schema provided"});
            else if (jsonErr != null) set.accept("jsonSchema", new String[]{"FAIL", jsonErr});
            else set.accept("jsonSchema", new String[]{"PASS", "schema(s) parsed"});
        }

        // dataschema-derived metadata
        java.util.List<String> schemaNames = new ArrayList<String>();
        java.util.List<Boolean> schemaNotNull = new ArrayList<Boolean>();
        if (dataschema != null) for (Map<String, Object> c : dataschema) {
            schemaNames.add(String.valueOf(c.get("name")));
            Object nu = c.get("nullable");
            schemaNotNull.add(Boolean.FALSE.equals(nu) || "false".equalsIgnoreCase(String.valueOf(nu)));
        }

        // open file
        java.io.File csv = new java.io.File(csvPath);
        if (!csv.isFile()) {
            String[] miss = new String[]{"FAIL", "CSV file not found: " + csvPath};
            for (String id : selected) if (!"jsonSchema".equals(id)) set.accept(id, miss);
            res.exitCode = 2;
            return;
        }

        // violation report: one CSV row per violation (CHECK;LINE;COLUMN;DETAIL), streamed with a cap
        final java.io.File reportFile = new java.io.File(csv.getParentFile(),
                stripExt(csv.getName()) + "_validation_report.csv");
        try { java.nio.file.Files.deleteIfExists(reportFile.toPath()); } catch (Exception ignored) {}
        class Reporter {
            static final long CAP = 100000;
            java.io.Writer w; long rows = 0; boolean trunc = false;
            void add(String check, long ln, String col, String det) {
                if (trunc) return;
                try {
                    if (rows >= CAP) { trunc = true; return; }
                    if (w == null) {
                        w = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                                new java.io.FileOutputStream(reportFile), StandardCharsets.UTF_8), 1 << 16);
                        w.write('\uFEFF');
                        w.write("CHECK;LINE;COLUMN;DETAIL\r\n");
                    }
                    w.write(check + ";" + ln + ";" + repField(col) + ";" + repField(det) + "\r\n");
                    rows++;
                } catch (Exception ignored) {}
            }
            void close() { if (w != null) try { w.flush(); w.close(); } catch (Exception ignored) {} }
        }
        final Reporter rep = new Reporter();

        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(csv), StandardCharsets.UTF_8), 1 << 16);
        try {
            r.mark(4); if (r.read() != 0xFEFF) r.reset();
            String header = hasHeader ? r.readLine() : null;
            java.util.List<String> headerCols = header != null ? splitSimple(header, delim) : null;

            // colNames check (header vs dataschema)
            if (sel_colNames) {
                if (dataschema == null) set.accept("colNames", new String[]{"SKIP", "dataschema not provided"});
                else if (!hasHeader || headerCols == null) set.accept("colNames", new String[]{"SKIP", "file has no header"});
                else {
                    java.util.List<String> diff = new ArrayList<String>();
                    int n = Math.max(headerCols.size(), schemaNames.size());
                    for (int i = 0; i < n; i++) {
                        String h = i < headerCols.size() ? headerCols.get(i).trim() : "(missing)";
                        String sName = i < schemaNames.size() ? schemaNames.get(i) : "(missing)";
                        if (!h.equals(sName)) diff.add("col " + (i + 1) + ": '" + h + "' != '" + sName + "'");
                    }
                    if (diff.isEmpty()) set.accept("colNames", new String[]{"PASS", schemaNames.size() + " columns match"});
                    else set.accept("colNames", new String[]{"FAIL", join(diff, 5)});
                }
            }

            // column index map for value checks
            java.util.Map<String, Integer> idx = new java.util.HashMap<String, Integer>();
            java.util.List<String> idxNames = (headerCols != null) ? headerCols : schemaNames;
            for (int i = 0; i < idxNames.size(); i++) idx.put(idxNames.get(i).trim(), i);

            int expectedCols = dataschema != null ? schemaNames.size() : (headerCols != null ? headerCols.size() : -1);

            // non-nullable column indices
            java.util.List<Integer> nnIdx = new ArrayList<Integer>();
            if (sel_notNull && dataschema != null) for (int i = 0; i < schemaNames.size(); i++) if (schemaNotNull.get(i)) {
                Integer ci = idx.get(schemaNames.get(i)); if (ci != null) nnIdx.add(ci);
            }
            // business date col index + regex
            Integer bizIdx = (sel_biz && bizCol != null) ? idx.get(bizCol) : null;
            java.util.regex.Pattern datePat = dateFormat != null ? java.util.regex.Pattern.compile(fmtToRegex(dateFormat)) : null;
            // display-schema date columns
            java.util.List<Integer> dateIdx = new ArrayList<Integer>();
            java.util.List<String> dateColNames = new ArrayList<String>();
            if (sel_disp && displayschema != null) for (Map<String, Object> c : displayschema) {
                if ("date".equalsIgnoreCase(String.valueOf(c.get("DataType")))) {
                    String cn = String.valueOf(c.get("ColumnName"));
                    Integer ci = idx.get(cn);
                    if (ci != null) { dateIdx.add(ci); dateColNames.add(cn); }
                }
            }

            // single streaming pass
            long rows = 0, colViol = 0, quoteViol = 0, bizViol = 0;
            java.util.List<String> colViolLines = new ArrayList<String>();
            java.util.List<String> quoteViolLines = new ArrayList<String>();
            java.util.List<String> bizViolLines = new ArrayList<String>();
            long[] nnViol = new long[nnIdx.size()];
            long[] dateViol = new long[dateIdx.size()];
            String line2;
            long lineNo = hasHeader ? 1 : 0;
            while ((line2 = r.readLine()) != null) {
                lineNo++; rows++;
                java.util.List<String> f = splitSimple(line2, delim);
                if (sel_noQuotes && line2.indexOf('"') >= 0) {
                    quoteViol++;
                    String firstCol = null;
                    for (int ci = 0; ci < f.size(); ci++) {
                        if (f.get(ci).indexOf('"') >= 0) {
                            String cn = ci < idxNames.size() ? idxNames.get(ci).trim() : ("col" + (ci + 1));
                            if (firstCol == null) firstCol = cn;
                            rep.add("noQuotes", lineNo, cn, snippet60(f.get(ci)));
                        }
                    }
                    if (firstCol == null) { firstCol = "?"; rep.add("noQuotes", lineNo, "", snippet60(line2)); }
                    if (quoteViolLines.size() < 5) quoteViolLines.add("line " + lineNo + " [" + firstCol + "]");
                }
                if (sel_colCount && expectedCols >= 0 && f.size() != expectedCols) {
                    colViol++;
                    rep.add("colCount", lineNo, "", "found " + f.size() + ", expected " + expectedCols);
                    if (colViolLines.size() < 5) colViolLines.add("line " + lineNo + " has " + f.size());
                }
                if (sel_notNull) for (int k = 0; k < nnIdx.size(); k++) {
                    int ci = nnIdx.get(k);
                    if (ci >= f.size() || f.get(ci).trim().isEmpty()) {
                        nnViol[k]++;
                        rep.add("notNull", lineNo, ci < idxNames.size() ? idxNames.get(ci).trim() : ("col" + (ci + 1)), "empty");
                    }
                }
                if (bizIdx != null) {
                    String v = bizIdx < f.size() ? f.get(bizIdx).trim() : "";
                    boolean bad = v.isEmpty() || (datePat != null && !datePat.matcher(v).matches());
                    if (bad) {
                        bizViol++;
                        rep.add("businessDate", lineNo, bizCol, v.isEmpty() ? "empty" : ("malformed: " + snippet60(v)));
                        if (bizViolLines.size() < 5) bizViolLines.add("line " + lineNo + " ='" + v + "'");
                    }
                }
                if (!dateIdx.isEmpty() && datePat != null) for (int k = 0; k < dateIdx.size(); k++) {
                    int ci = dateIdx.get(k); String v = ci < f.size() ? f.get(ci).trim() : "";
                    if (!v.isEmpty() && !datePat.matcher(v).matches()) {
                        dateViol[k]++;
                        rep.add("displayDates", lineNo, dateColNames.get(k), "malformed: " + snippet60(v));
                    }
                }
            }

            rep.close();
            String repNote = rep.rows > 0
                    ? (" — full report: " + reportFile.getName() + (rep.trunc ? " (truncated at " + Reporter.CAP + " rows)" : ""))
                    : "";
            if (rep.rows > 0) {
                line.accept("violation report (" + rep.rows + " row(s)" + (rep.trunc ? ", truncated" : "") + "): " + reportFile.getAbsolutePath());
                res.outVars.put("validationReport", reportFile.getAbsolutePath());
            }

            if (sel_rowCount) {
                if (expected == null) set.accept("rowCount", new String[]{"SKIP", "expectedRows not provided (actual " + rows + ")"});
                else if (rows == expected) set.accept("rowCount", new String[]{"PASS", rows + " data rows"});
                else set.accept("rowCount", new String[]{"FAIL", "expected " + expected + ", found " + rows});
            }
            if (sel_colCount) {
                if (expectedCols < 0) set.accept("colCount", new String[]{"SKIP", "no dataschema/header to derive column count"});
                else if (colViol == 0) set.accept("colCount", new String[]{"PASS", "all rows have " + expectedCols + " columns"});
                else set.accept("colCount", new String[]{"FAIL", colViol + " row(s) with wrong column count (" + join(colViolLines, 5) + ")" + repNote});
            }
            if (sel_noQuotes) {
                if (quoteViol == 0) set.accept("noQuotes", new String[]{"PASS", "no double quotes in data"});
                else set.accept("noQuotes", new String[]{"FAIL", quoteViol + " row(s) contain a double quote (" + join(quoteViolLines, 5) + ")" + repNote});
            }
            if (sel_notNull) {
                if (dataschema == null) set.accept("notNull", new String[]{"SKIP", "dataschema not provided"});
                else {
                    java.util.List<String> bad = new ArrayList<String>();
                    for (int k = 0; k < nnIdx.size(); k++) if (nnViol[k] > 0) bad.add(idxNames.get(nnIdx.get(k)) + ": " + nnViol[k] + " empty");
                    if (bad.isEmpty()) set.accept("notNull", new String[]{"PASS", nnIdx.size() + " non-nullable column(s) ok"});
                    else set.accept("notNull", new String[]{"FAIL", join(bad, 6) + repNote});
                }
            }
            if (sel_biz) {
                if (bizCol == null) set.accept("businessDate", new String[]{"SKIP", "businessDateColumn not provided"});
                else if (bizIdx == null) set.accept("businessDate", new String[]{"FAIL", "column '" + bizCol + "' not found"});
                else if (bizViol == 0) set.accept("businessDate", new String[]{"PASS", "all rows valued" + (dateFormat != null ? (" and matching " + dateFormat) : "")});
                else set.accept("businessDate", new String[]{"FAIL", bizViol + " row(s) empty or malformed (" + join(bizViolLines, 5) + ")" + repNote});
            }
            if (sel_disp) {
                if (displayschema == null) set.accept("displayDates", new String[]{"SKIP", "displayschema not provided"});
                else if (dateFormat == null) set.accept("displayDates", new String[]{"SKIP", "dateFormat not provided"});
                else if (dateIdx.isEmpty()) set.accept("displayDates", new String[]{"PASS", "no date columns in displayschema"});
                else {
                    java.util.List<String> bad = new ArrayList<String>();
                    for (int k = 0; k < dateIdx.size(); k++) if (dateViol[k] > 0) bad.add(dateColNames.get(k) + ": " + dateViol[k] + " malformed");
                    if (bad.isEmpty()) set.accept("displayDates", new String[]{"PASS", dateIdx.size() + " date column(s) ok"});
                    else set.accept("displayDates", new String[]{"FAIL", join(bad, 6) + repNote});
                }
            }

            int failed = 0, passed = 0;
            for (com.legalarchive.orchestrator.model.run.CheckResult c : checks) {
                if ("FAIL".equals(c.status)) failed++; else if ("PASS".equals(c.status)) passed++;
            }
            res.outVars.put("checksTotal", String.valueOf(checks.size()));
            res.outVars.put("checksPassed", String.valueOf(passed));
            res.outVars.put("checksFailed", String.valueOf(failed));
            for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
            res.exitCode = failed > 0 ? 1 : 0;
            line.accept("validation finished: " + passed + " passed, " + failed + " failed" + (failed > 0 ? " — STEP FAILED" : ""));
        } finally {
            r.close();
        }
    }

    private static String blankToNull(String s) { return (s == null || s.trim().isEmpty()) ? null : s.trim(); }
    private static String stripExt(String name) { int d = name.lastIndexOf('.'); return d > 0 ? name.substring(0, d) : name; }
    private static String snippet60(String v) { v = v == null ? "" : v; return v.length() > 60 ? (v.substring(0, 60) + "…") : v; }
    /** RFC-quote a field for the violation report (it may itself contain quotes/semicolons). */
    private static String repField(String v) {
        if (v == null) return "";
        if (v.indexOf(';') >= 0 || v.indexOf('"') >= 0) return '"' + v.replace("\"", "\"\"") + '"';
        return v;
    }
    private static String join(java.util.List<String> l, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size() && i < max; i++) { if (i > 0) sb.append("; "); sb.append(l.get(i)); }
        if (l.size() > max) sb.append("; …");
        return sb.toString();
    }
    /** naive split by delimiter (validation enforces no quotes anyway). */
    private static java.util.List<String> splitSimple(String line, char delim) {
        java.util.List<String> out = new ArrayList<String>();
        int start = 0;
        for (int i = 0; i < line.length(); i++) if (line.charAt(i) == delim) { out.add(line.substring(start, i)); start = i + 1; }
        out.add(line.substring(start));
        return out;
    }
    /** Convert a token date format (YYYY/MM/DD, YYYYMMDD, DD-MM-YYYY, HH:mm:ss…) to an anchored regex. */
    private static String fmtToRegex(String fmt) {
        StringBuilder sb = new StringBuilder("^");
        int i = 0;
        while (i < fmt.length()) {
            if (fmt.startsWith("YYYY", i)) { sb.append("\\d{4}"); i += 4; }
            else if (fmt.startsWith("YY", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("MM", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("DD", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("HH", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("mm", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("ss", i)) { sb.append("\\d{2}"); i += 2; }
            else { char c = fmt.charAt(i); if ("\\.[]{}()*+-?^$|".indexOf(c) >= 0) sb.append('\\'); sb.append(c); i++; }
        }
        sb.append("$");
        return sb.toString();
    }

    private void safeLine(BufferedWriter log, String s) {
        if (log == null) return;
        try { log.write(LocalDateTime.now().format(TS) + "  " + s); log.newLine(); log.flush(); } catch (Exception ignored) {}
    }
}
