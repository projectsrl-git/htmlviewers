package com.legalarchive.orchestrator.web;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.RequestBody;

import com.legalarchive.orchestrator.audit.AuditLogger;
import com.legalarchive.orchestrator.ds.DataSourceDef;
import com.legalarchive.orchestrator.ds.DataSourceStore;
import com.legalarchive.orchestrator.ds.SqlSupport;
import com.legalarchive.orchestrator.config.AppProperties;
import com.legalarchive.orchestrator.engine.WorkflowEngine;
import com.legalarchive.orchestrator.engine.WorkflowScheduler;
import com.legalarchive.orchestrator.model.def.GateDef;
import com.legalarchive.orchestrator.model.def.NodeDef;
import com.legalarchive.orchestrator.model.def.StepDef;
import com.legalarchive.orchestrator.model.def.WorkflowDef;
import com.legalarchive.orchestrator.model.run.WorkflowRun;
import com.legalarchive.orchestrator.parser.WorkflowXmlParser;
import com.legalarchive.orchestrator.parser.WorkflowXmlWriter;
import com.legalarchive.orchestrator.registry.WorkflowRegistry;
import com.legalarchive.orchestrator.store.FeedLayout;
import com.legalarchive.orchestrator.store.RunStore;
import com.legalarchive.orchestrator.web.dto.WorkflowDto;

@RestController
public class ApiController {

    private final WorkflowRegistry registry;
    private final WorkflowEngine engine;
    private final RunStore store;
    private final AuditLogger audit;
    private final WorkflowScheduler scheduler;
    private final AppProperties props;
    private final DataSourceStore dataSources;
    private final SqlSupport sql;
    private final WorkflowXmlWriter xmlWriter = new WorkflowXmlWriter();
    private final WorkflowXmlParser xmlParser = new WorkflowXmlParser();

    public ApiController(WorkflowRegistry registry, WorkflowEngine engine, RunStore store,
                         AuditLogger audit, WorkflowScheduler scheduler, AppProperties props,
                         DataSourceStore dataSources, SqlSupport sql) {
        this.registry = registry;
        this.engine = engine;
        this.store = store;
        this.audit = audit;
        this.scheduler = scheduler;
        this.props = props;
        this.dataSources = dataSources;
        this.sql = sql;
    }

    // ----------------------------------------------------------- datasources
    @GetMapping("/api/datasources")
    public java.util.List<DataSourceDef> listDataSources() {
        java.util.List<DataSourceDef> out = new java.util.ArrayList<DataSourceDef>();
        for (DataSourceDef d : dataSources.all()) out.add(mask(d));
        return out;
    }

    @PostMapping("/api/datasources")
    public ResponseEntity<Map<String, Object>> saveDataSource(@RequestBody DataSourceDef d) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        if (d.id == null || !d.id.matches("[A-Za-z0-9._-]+")) {
            return badRequest(out, "Invalid datasource id: only letters, digits, . _ - allowed");
        }
        // keep existing password if the UI sends the masked placeholder
        if ("********".equals(d.password)) {
            DataSourceDef ex = dataSources.get(d.id);
            d.password = ex != null ? ex.password : "";
        }
        dataSources.save(d);
        out.put("ok", true);
        return ResponseEntity.ok(out);
    }

    @PostMapping("/api/datasources/{id}/delete")
    public ResponseEntity<Map<String, Object>> deleteDataSource(@PathVariable String id) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("ok", dataSources.delete(id));
        return ResponseEntity.ok(out);
    }

    /** Test connection. Body is a (possibly unsaved) datasource definition. */
    @PostMapping("/api/datasources/test")
    public Map<String, Object> testDataSource(@RequestBody DataSourceDef d) {
        if ("********".equals(d.password) && d.id != null) {
            DataSourceDef ex = dataSources.get(d.id);
            if (ex != null) d.password = ex.password;
        }
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        String err = sql.test(d);
        out.put("ok", err == null);
        if (err != null) out.put("error", err);
        return out;
    }

    /** Query preview for the SQL step textbox: runs against a saved datasource. */
    @PostMapping("/api/datasources/{id}/query")
    public ResponseEntity<Map<String, Object>> previewQuery(@PathVariable String id,
                                                           @RequestParam(defaultValue = "50") int maxRows,
                                                           @RequestBody String query) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        DataSourceDef d = dataSources.get(id);
        if (d == null) return badRequest(out, "Unknown datasource: " + id);
        try {
            SqlSupport.QueryResult qr = sql.run(d, query, maxRows);
            out.put("ok", true);
            out.put("columns", qr.columns);
            out.put("rows", qr.rows);
            out.put("rowCount", qr.rowCount);
            out.put("truncated", qr.truncated);
            out.put("updateCount", qr.updateCount);
            return ResponseEntity.ok(out);
        } catch (Exception e) {
            return badRequest(out, e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    private DataSourceDef mask(DataSourceDef d) {
        DataSourceDef c = new DataSourceDef();
        c.id = d.id; c.name = d.name; c.type = d.type; c.host = d.host; c.user = d.user;
        c.password = (d.password == null || d.password.isEmpty()) ? "" : "********";
        c.properties = d.properties; c.jdbcUrl = d.jdbcUrl; c.driverClass = d.driverClass; c.testQuery = d.testQuery;
        return c;
    }

    /** Avvio manuale di un workflow. */
    @PostMapping("/api/workflows/{feedId}/run")
    public ResponseEntity<Map<String, Object>> run(@PathVariable String feedId, HttpServletRequest req) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        try {
            WorkflowRun run = engine.start(feedId, "MANUAL", user(req));
            if (run == null) {
                out.put("ok", false);
                out.put("error", "A run is already active for this feed");
                return ResponseEntity.status(HttpStatus.CONFLICT).body(out);
            }
            out.put("ok", true);
            out.put("runId", run.runId);
            return ResponseEntity.ok(out);
        } catch (IllegalArgumentException e) {
            out.put("ok", false);
            out.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(out);
        }
    }

    /** Stato corrente di un run (polling UI). */
    @GetMapping("/api/runs/{feedId}/{runId}")
    public ResponseEntity<WorkflowRun> runState(@PathVariable String feedId, @PathVariable String runId) {
        WorkflowRun run = engine.activeRun(runId);
        if (run == null) {
            FeedLayout layout = registry.layout(feedId);
            if (layout != null) run = store.load(layout, runId);
        }
        return run == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(run);
    }

    /** Approvazione/rifiuto di un gate manuale in attesa. */
    @PostMapping("/api/runs/{feedId}/{runId}/decision")
    public ResponseEntity<Map<String, Object>> decision(@PathVariable String feedId, @PathVariable String runId,
                                                        @RequestParam boolean approve,
                                                        @RequestParam(required = false) String note,
                                                        HttpServletRequest req) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        boolean ok = engine.decide(feedId, runId, approve, user(req), note);
        out.put("ok", ok);
        if (!ok) out.put("error", "The run is not waiting for approval");
        return ok ? ResponseEntity.ok(out) : ResponseEntity.status(HttpStatus.CONFLICT).body(out);
    }

    /** Stop a running or waiting run. */
    @PostMapping("/api/runs/{feedId}/{runId}/stop")
    public ResponseEntity<Map<String, Object>> stop(@PathVariable String feedId, @PathVariable String runId,
                                                    HttpServletRequest req) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        boolean ok = engine.stop(feedId, runId, user(req));
        out.put("ok", ok);
        if (!ok) out.put("error", "Run not found or already finished");
        return ok ? ResponseEntity.ok(out) : ResponseEntity.status(HttpStatus.CONFLICT).body(out);
    }

    /** Log PowerShell di uno step (testo). */
    @GetMapping(value = "/api/runs/{feedId}/{runId}/log/{stepId}", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> stepLog(@PathVariable String feedId, @PathVariable String runId,
                                          @PathVariable String stepId,
                                          @RequestParam(value = "tail", defaultValue = "0") int tail) {
        FeedLayout layout = registry.layout(feedId);
        if (layout == null) return ResponseEntity.notFound().build();
        // anti path-traversal: solo nomi semplici
        if (!runId.matches("[A-Za-z0-9._-]+") || !stepId.matches("[A-Za-z0-9._-]+")) {
            return ResponseEntity.badRequest().body("Invalid identifiers");
        }
        Path log = layout.stepLog(runId, stepId);
        if (!Files.exists(log)) return ResponseEntity.ok("(no log available)");
        try {
            java.util.List<String> lines = Files.readAllLines(log, StandardCharsets.UTF_8);
            if (tail > 0 && lines.size() > tail) lines = lines.subList(lines.size() - tail, lines.size());
            return ResponseEntity.ok(String.join(System.lineSeparator(), lines));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error reading log: " + e.getMessage());
        }
    }

    /** Verifica integrita' della catena di audit. */
    @GetMapping("/api/audit/{feedId}/verify")
    public ResponseEntity<AuditLogger.VerifyResult> verify(@PathVariable String feedId) {
        FeedLayout layout = registry.layout(feedId);
        if (layout == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(audit.verify(layout.auditFile()));
    }

    /** Ricarica le definizioni XML e ripianifica i cron. */
    @PostMapping("/api/reload")
    public Map<String, Object> reload() {
        registry.reload();
        scheduler.reschedule();
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("ok", true);
        out.put("workflows", registry.all().size());
        out.put("errors", registry.errors());
        return out;
    }

    /** Designer: current definition of a workflow as JSON. */
    @GetMapping("/api/workflows/{feedId}/definition")
    public ResponseEntity<WorkflowDto> definition(@PathVariable String feedId) {
        WorkflowDef def = registry.get(feedId);
        if (def == null) return ResponseEntity.notFound().build();
        WorkflowDto dto = new WorkflowDto();
        dto.feedId = def.feedId;
        dto.name = def.name;
        dto.cron = def.cron;
        dto.baseDir = def.baseDir;
        dto.description = def.description;
        for (Map.Entry<String, String> v : def.variables.entrySet()) {
            dto.variables.add(new WorkflowDto.KV(v.getKey(), v.getValue()));
        }
        for (NodeDef n : def.nodes) {
            WorkflowDto.NodeDto nd = new WorkflowDto.NodeDto();
            nd.kind = n.getKind();
            nd.id = n.id;
            nd.name = n.name;
            if (n instanceof StepDef) {
                StepDef st = (StepDef) n;
                nd.script = st.script;
                nd.exec = st.exec;
                nd.timeoutSec = st.timeoutSec > 0 ? st.timeoutSec : null;
                nd.retry = st.retry > 0 ? st.retry : null;
                nd.retryDelaySec = st.retry > 0 ? st.retryDelaySec : null;
                nd.datasource = st.datasource;
                nd.query = st.query;
                nd.ifsPath = st.ifsPath;
                nd.source = st.source;
                nd.dest = st.dest;
                nd.pattern = st.pattern;
                nd.mode = st.mode;
                nd.overwrite = st.overwrite ? Boolean.TRUE : null;
                nd.outputVar = st.outputVar;
                nd.delimiter = st.delimiter;
                nd.forEach = st.forEach;
                nd.concurrency = st.concurrency != 4 ? st.concurrency : null;
                for (Map.Entry<String, String> p : st.params.entrySet()) {
                    nd.params.add(new WorkflowDto.KV(p.getKey(), p.getValue()));
                }
                nd.outputs.addAll(st.outputs);
            } else {
                GateDef g = (GateDef) n;
                nd.type = g.type;
                nd.condition = g.condition;
                nd.onTrue = g.onTrue;
                nd.onFalse = g.onFalse;
            }
            dto.nodes.add(nd);
        }
        return ResponseEntity.ok(dto);
    }

    /**
     * Designer: validate and save a workflow definition.
     * The XML is generated server-side, re-validated with the same parser used at
     * load time, written to the workflows directory, then registry and scheduler
     * are reloaded. The save is recorded in the feed audit log.
     */
    @PostMapping("/api/workflows/save")
    public ResponseEntity<Map<String, Object>> save(@RequestBody WorkflowDto dto,
                                                    @RequestParam(defaultValue = "false") boolean overwrite,
                                                    HttpServletRequest req) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        try {
            if (dto.feedId == null || !dto.feedId.matches("[A-Za-z0-9._-]+")) {
                return badRequest(out, "Invalid feedId: only letters, digits, . _ - are allowed");
            }
            String xml = xmlWriter.toXml(dto);

            java.io.File dir = new java.io.File(props.getWorkflowsDir());
            if (!dir.isDirectory() && !dir.mkdirs()) {
                return badRequest(out, "Workflows directory cannot be created: " + dir.getAbsolutePath());
            }

            // validate by parsing the generated XML before touching the real file
            Path tmp = Files.createTempFile(dir.toPath(), "_validate_", ".tmp");
            try {
                Files.write(tmp, xml.getBytes(StandardCharsets.UTF_8));
                WorkflowDef parsed = xmlParser.parse(tmp.toFile());
                if (!parsed.feedId.equals(dto.feedId)) {
                    return badRequest(out, "feedId mismatch after generation");
                }
            } catch (Exception e) {
                return badRequest(out, "Validation failed: " + e.getMessage());
            } finally {
                Files.deleteIfExists(tmp);
            }

            WorkflowDef existing = registry.get(dto.feedId);
            String fileName = existing != null && existing.sourceFile != null
                    ? existing.sourceFile : dto.feedId + ".xml";
            Path target = dir.toPath().resolve(fileName);
            if ((existing != null || Files.exists(target)) && !overwrite) {
                out.put("ok", false);
                out.put("exists", true);
                out.put("error", "Workflow '" + dto.feedId + "' already exists. Confirm overwrite.");
                return ResponseEntity.status(HttpStatus.CONFLICT).body(out);
            }

            Files.write(target, xml.getBytes(StandardCharsets.UTF_8));
            registry.reload();
            scheduler.reschedule();

            FeedLayout layout = registry.layout(dto.feedId);
            if (layout != null) {
                Map<String, String> det = new LinkedHashMap<String, String>();
                det.put("file", fileName);
                det.put("action", existing != null ? "UPDATED" : "CREATED");
                det.put("nodes", String.valueOf(dto.nodes == null ? 0 : dto.nodes.size()));
                audit.log(layout.auditFile(), dto.feedId, null, null, "WORKFLOW_SAVED", user(req), det);
            }

            out.put("ok", true);
            out.put("feedId", dto.feedId);
            out.put("file", fileName);
            out.put("loadErrors", registry.errors());
            return ResponseEntity.ok(out);
        } catch (Exception e) {
            return badRequest(out, "Save failed: " + e.getMessage());
        }
    }

    private ResponseEntity<Map<String, Object>> badRequest(Map<String, Object> out, String error) {
        out.put("ok", false);
        out.put("error", error);
        return ResponseEntity.badRequest().body(out);
    }

    private String user(HttpServletRequest req) {
        String u = req.getHeader("X-User");
        if (u == null || u.trim().isEmpty()) u = req.getRemoteUser();
        if (u == null || u.trim().isEmpty()) u = "operator@" + req.getRemoteAddr();
        return u;
    }
}
