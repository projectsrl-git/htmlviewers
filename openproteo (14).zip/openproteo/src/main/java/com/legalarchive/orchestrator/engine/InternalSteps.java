package com.legalarchive.orchestrator.engine;

import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.legalarchive.orchestrator.ds.DataSourceDef;
import com.legalarchive.orchestrator.ds.DataSourceStore;
import com.legalarchive.orchestrator.ds.IfsSupport;
import com.legalarchive.orchestrator.ds.SqlSupport;
import com.legalarchive.orchestrator.model.def.StepDef;

/**
 * Executes the built-in step kinds in-process (no external process):
 *   sql      - run a query on a datasource; emit rowCount and first-row columns as vars
 *   ifscopy  - native IFS copy from AS400 to a local directory (JTOpen)
 *   filecopy - copy/move/list files between local directories by glob pattern
 *   setvar   - assign/compute run variables (supports simple +/- integer math)
 *
 * Each method writes a timestamped log to the step log file and returns a
 * StepExecutor.Result so the engine treats internal and external steps uniformly.
 */
@Component
public class InternalSteps {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final DataSourceStore dataSources;
    private final SqlSupport sql;
    private final IfsSupport ifs;

    public InternalSteps(DataSourceStore dataSources, SqlSupport sql, IfsSupport ifs) {
        this.dataSources = dataSources;
        this.sql = sql;
        this.ifs = ifs;
    }

    public StepExecutor.Result run(String kind, StepDef step, Map<String, String> resolvedParams,
                                   Map<String, String> vars, Path logFile, RunControl control) {
        StepExecutor.Result res = new StepExecutor.Result();
        BufferedWriter log = null;
        try {
            Files.createDirectories(logFile.getParent());
            log = Files.newBufferedWriter(logFile, StandardCharsets.UTF_8,
                    java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
            final BufferedWriter flog = log;
            java.util.function.Consumer<String> line = new java.util.function.Consumer<String>() {
                public void accept(String s) {
                    try { flog.write(LocalDateTime.now().format(TS) + "  " + s); flog.newLine(); flog.flush(); }
                    catch (Exception ignored) {}
                }
            };

            if (control != null && control.aborted) { line.accept("aborted before start"); res.exitCode = -997; return res; }

            if ("sql".equals(kind)) {
                runSql(step, resolvedParams, vars, res, line);
            } else if ("ifscopy".equals(kind)) {
                runIfsCopy(step, vars, res, line);
            } else if ("filecopy".equals(kind)) {
                runFileCopy(step, vars, res, line);
            } else if ("setvar".equals(kind)) {
                runSetVar(resolvedParams, vars, res, line);
            } else {
                line.accept("unknown internal step kind: " + kind);
                res.exitCode = -996;
            }
        } catch (Exception e) {
            res.exitCode = res.exitCode == 0 ? 1 : res.exitCode;
            res.lastLines = e.getMessage();
            safeLine(log, "ERROR: " + e.getMessage());
        } finally {
            if (log != null) try { log.close(); } catch (Exception ignored) {}
        }
        return res;
    }

    // ----------------------------------------------------------------- sql
    private void runSql(StepDef step, Map<String, String> params, Map<String, String> vars,
                        StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        DataSourceDef d = dataSources.get(step.datasource);
        if (d == null) { line.accept("datasource not found: " + step.datasource); res.exitCode = 2; return; }
        String query = VarResolver.resolve(step.query, vars);
        line.accept("datasource: " + d.id + " (" + d.type + ")");
        line.accept("query: " + query);

        // CSV export path: stream the full result set to a file
        String csvFile = VarResolver.resolve(step.csvFile, vars);
        if (csvFile != null && !csvFile.trim().isEmpty()) {
            char delim = (step.delimiter != null && !step.delimiter.isEmpty()) ? step.delimiter.charAt(0) : ';';
            java.io.File out = new java.io.File(csvFile);
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            long maxRows = step.csvSplitRows > 0 ? step.csvSplitRows : 0;
            long maxBytes = step.csvSplitMb > 0 ? (long) step.csvSplitMb * 1024L * 1024L : 0;
            SqlSupport.ExportResult er = sql.exportCsv(d, query, out, delim, true, maxRows, maxBytes);
            res.outVars.put("rowCount", String.valueOf(er.rows));
            res.outVars.put("csvParts", String.valueOf(er.parts));
            res.outVars.put("csvFile", er.files.isEmpty() ? out.getAbsolutePath() : er.files.get(0));
            res.outVars.put("csvFiles", String.join(step.delimiter == null ? ";" : step.delimiter, er.files));
            if (er.parts > 1) line.accept("exported " + er.rows + " row(s) into " + er.parts + " CSV part(s)");
            else line.accept("exported " + er.rows + " row(s) to " + res.outVars.get("csvFile"));
            for (String f : er.files) line.accept("  " + f);
            for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
            res.exitCode = 0;
            return;
        }

        SqlSupport.QueryResult qr = sql.run(d, query, 1000);
        if (qr.updateCount != null) {
            line.accept("update count: " + qr.updateCount);
            res.outVars.put("updateCount", String.valueOf(qr.updateCount));
        } else {
            line.accept("returned rows: " + qr.rowCount + (qr.truncated ? " (truncated at 1000)" : ""));
            res.outVars.put("rowCount", String.valueOf(qr.rowCount));
            // first row columns exposed as ${col_<NAME>}
            if (!qr.rows.isEmpty()) {
                List<String> r0 = qr.rows.get(0);
                for (int i = 0; i < qr.columns.size() && i < r0.size(); i++) {
                    res.outVars.put("col_" + qr.columns.get(i), r0.get(i));
                }
                res.outVars.put("firstValue", SqlSupport.firstValue(qr));
            }
            // optional: store all first-column values joined, for downstream steps
            if (step.outputVar != null && !step.outputVar.trim().isEmpty() && !qr.columns.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (List<String> r : qr.rows) { if (sb.length() > 0) sb.append(step.delimiter == null ? ";" : step.delimiter); sb.append(r.get(0)); }
                res.outVars.put(step.outputVar.trim(), sb.toString());
            }
        }
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // ------------------------------------------------------------- ifscopy
    private void runIfsCopy(StepDef step, Map<String, String> vars,
                            StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        DataSourceDef d = dataSources.get(step.datasource);
        if (d == null) { line.accept("datasource not found: " + step.datasource); res.exitCode = 2; return; }
        String ifsPath = VarResolver.resolve(step.ifsPath, vars);
        String dest = VarResolver.resolve(step.dest, vars);
        String glob = VarResolver.resolve(step.pattern, vars);
        line.accept("IFS copy " + ifsPath + "  ->  " + dest + "  (pattern " + (glob == null ? "*" : glob) + ")");
        IfsSupport.CopyResult cr = ifs.copyToLocal(d, ifsPath, dest, glob, step.overwrite, line);
        res.outVars.put("filesCopied", String.valueOf(cr.filesCopied));
        res.outVars.put("bytesCopied", String.valueOf(cr.bytesCopied));
        res.outVars.put("matchedFiles", String.join(step.delimiter == null ? ";" : step.delimiter, cr.names));
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // ------------------------------------------------------------ filecopy
    private void runFileCopy(StepDef step, Map<String, String> vars,
                             StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        String source = VarResolver.resolve(step.source, vars);
        String dest = VarResolver.resolve(step.dest, vars);
        String glob = VarResolver.resolve(step.pattern, vars);
        String mode = step.mode == null ? "copy" : step.mode.toLowerCase(); // copy | move | list
        if (glob == null || glob.trim().isEmpty()) glob = "*";

        Path src = Paths.get(source);
        if (!Files.isDirectory(src)) { line.accept("source directory not found: " + source); res.exitCode = 2; return; }
        line.accept(mode + "  " + source + "  pattern " + glob + (("list".equals(mode)) ? "" : ("  -> " + dest)));

        List<String> names = new ArrayList<String>();
        long bytes = 0;
        Path outDir = null;
        if (!"list".equals(mode)) {
            outDir = Paths.get(dest);
            Files.createDirectories(outDir);
        }
        DirectoryStream<Path> ds = Files.newDirectoryStream(src, glob);
        try {
            for (Path f : ds) {
                if (Files.isDirectory(f)) continue;
                names.add(f.getFileName().toString());
                if ("list".equals(mode)) continue;
                Path target = outDir.resolve(f.getFileName());
                if ("move".equals(mode)) {
                    Files.move(f, target, StandardCopyOption.REPLACE_EXISTING);
                } else {
                    Files.copy(f, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                }
                bytes += Files.size(target);
                line.accept(mode + " " + f.getFileName());
            }
        } finally {
            ds.close();
        }
        res.outVars.put("matchedCount", String.valueOf(names.size()));
        res.outVars.put("matchedFiles", String.join(step.delimiter == null ? ";" : step.delimiter, names));
        if (!"list".equals(mode)) res.outVars.put("bytesCopied", String.valueOf(bytes));
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // -------------------------------------------------------------- setvar
    /** params are name -> expression; expressions support ${vars} and simple a + b / a - b integer math. */
    private void runSetVar(Map<String, String> params, Map<String, String> vars,
                           StepExecutor.Result res, java.util.function.Consumer<String> line) {
        for (Map.Entry<String, String> e : params.entrySet()) {
            String value = evalArithmetic(e.getValue());
            res.outVars.put(e.getKey(), value);
            line.accept("##VAR " + e.getKey() + "=" + value);
        }
        res.exitCode = 0;
    }

    /** Evaluate "A + B" or "A - B" as integers when both sides are integers; otherwise return as-is. */
    private String evalArithmetic(String expr) {
        if (expr == null) return "";
        String s = expr.trim();
        for (String op : new String[]{"+", "-"}) {
            int idx = s.indexOf(' ' + op + ' ');
            if (idx > 0) {
                String a = s.substring(0, idx).trim();
                String b = s.substring(idx + 3).trim();
                try {
                    long la = Long.parseLong(a), lb = Long.parseLong(b);
                    return String.valueOf("+".equals(op) ? la + lb : la - lb);
                } catch (NumberFormatException ignored) {
                    return s;
                }
            }
        }
        return s;
    }

    private void safeLine(BufferedWriter log, String s) {
        if (log == null) return;
        try { log.write(LocalDateTime.now().format(TS) + "  " + s); log.newLine(); log.flush(); } catch (Exception ignored) {}
    }
}
