/*
 * viewer.js - online viewer for ASCII/CSV files served by OpenProteo.
 *
 *   initViewer({ host, src, name })
 *     host : container element
 *     src  : URL to fetch the raw file content (same origin)
 *     name : file name (used for the CSV/text heuristic and the title)
 *
 * Text mode : monospace lines with a line-number gutter, virtualized, with a filter.
 * CSV mode  : virtualized table (sticky header, horizontal scroll) handling millions of
 *             rows, a quick row filter, and an Aggregate tab that computes group-by
 *             counts over selected columns (for reconciliation metrics), exportable.
 *
 * Pure vanilla JS, no libraries. No literal newline escapes in source (UBS proxy safe):
 * newline/CR/TAB are referenced via char codes.
 */
(function (global) {
    'use strict';
    var LF = String.fromCharCode(10);
    var CR = 13;
    var TAB = String.fromCharCode(9);
    var SEP = String.fromCharCode(1); // group key separator, won't appear in data

    function el(tag, cls, parent) {
        var e = document.createElement(tag);
        if (cls) e.className = cls;
        if (parent) parent.appendChild(e);
        return e;
    }
    function text(node, s) { node.textContent = (s == null ? '' : String(s)); return node; }
    function fmtSize(n) {
        if (n < 1024) return n + ' B';
        if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
        return (n / 1048576).toFixed(1) + ' MB';
    }

    // ---- virtualized list: renders only the rows in the viewport ----
    function virtualList(scrollEl, rowHeight, getCount, renderRow) {
        scrollEl.innerHTML = '';
        scrollEl.style.position = 'relative';
        var spacer = el('div', null, scrollEl);
        spacer.style.position = 'relative';
        spacer.style.width = '1px';
        var pool = el('div', null, scrollEl);
        pool.style.position = 'absolute';
        pool.style.left = '0';
        pool.style.right = '0';
        pool.style.top = '0';
        var ticking = false, onDraw = null;

        function draw() {
            ticking = false;
            var count = getCount();
            spacer.style.height = (count * rowHeight) + 'px';
            var st = scrollEl.scrollTop, h = scrollEl.clientHeight;
            var start = Math.max(0, Math.floor(st / rowHeight) - 6);
            var end = Math.min(count, Math.ceil((st + h) / rowHeight) + 6);
            pool.style.transform = 'translateY(' + (start * rowHeight) + 'px)';
            pool.innerHTML = '';
            for (var i = start; i < end; i++) {
                var r = renderRow(i);
                r.style.height = rowHeight + 'px';
                pool.appendChild(r);
            }
            if (onDraw) onDraw(scrollEl.scrollLeft);
        }
        scrollEl.addEventListener('scroll', function () {
            if (!ticking) { ticking = true; requestAnimationFrame(draw); }
        });
        return {
            redraw: draw,
            reset: function () { scrollEl.scrollTop = 0; draw(); },
            onDraw: function (cb) { onDraw = cb; }
        };
    }

    // ---- CSV parsing ----
    function detectDelimiter(firstLine, name) {
        if (/\.tsv$/i.test(name)) return TAB;
        var counts = {};
        counts[';'] = (firstLine.split(';').length - 1);
        counts[','] = (firstLine.split(',').length - 1);
        counts[TAB] = (firstLine.split(TAB).length - 1);
        var best = ',', bestN = -1;
        [';', ',', TAB].forEach(function (d) { if (counts[d] > bestN) { bestN = counts[d]; best = d; } });
        return bestN > 0 ? best : (/\.tsv$/i.test(name) ? TAB : ',');
    }

    function firstLineOf(t) {
        var idx = t.indexOf(LF);
        var line = idx < 0 ? t : t.substring(0, idx);
        if (line.length && line.charCodeAt(line.length - 1) === CR) line = line.slice(0, -1);
        return line;
    }

    function parseCsv(t, delim) {
        // fast path when there are no quoted fields (typical DB exports)
        if (t.indexOf('"') < 0) {
            var lines = t.split(LF);
            var out = [];
            for (var i = 0; i < lines.length; i++) {
                var ln = lines[i];
                if (ln.length && ln.charCodeAt(ln.length - 1) === CR) ln = ln.slice(0, -1);
                if (i === lines.length - 1 && ln === '') break; // trailing newline
                out.push(ln.split(delim));
            }
            return out;
        }
        // RFC-4180 state machine for quoted fields
        var rows = [], row = [], field = '', inQ = false, n = t.length, i2 = 0;
        while (i2 < n) {
            var c = t.charAt(i2);
            if (inQ) {
                if (c === '"') {
                    if (t.charAt(i2 + 1) === '"') { field += '"'; i2 += 2; continue; }
                    inQ = false; i2++; continue;
                }
                field += c; i2++; continue;
            }
            if (c === '"') { inQ = true; i2++; continue; }
            if (c === delim) { row.push(field); field = ''; i2++; continue; }
            if (c.charCodeAt(0) === CR) { i2++; continue; }
            if (c === LF) { row.push(field); rows.push(row); row = []; field = ''; i2++; continue; }
            field += c; i2++;
        }
        if (field.length > 0 || row.length > 0) { row.push(field); rows.push(row); }
        return rows;
    }

    // ============================================================ TEXT mode
    function renderText(host, content, name, meta) {
        var lines = content.split(LF);
        if (lines.length && lines[lines.length - 1] === '') lines.pop();
        for (var i = 0; i < lines.length; i++) {
            if (lines[i].length && lines[i].charCodeAt(lines[i].length - 1) === CR) lines[i] = lines[i].slice(0, -1);
        }
        meta.textContent = lines.length + ' lines · ' + fmtSize(content.length);

        var tools = el('div', 'vwr-tools', host);
        var filter = el('input', 'search-box', tools);
        filter.placeholder = '🔎 Filter lines…';
        var info = el('span', 'dim small', tools);
        info.style.marginLeft = '10px';

        var body = el('div', 'vwr-body mono', host);
        var gutterW = String(lines.length).length;

        var view = [];
        for (var k = 0; k < lines.length; k++) view.push(k);

        var vl = virtualList(body, 19, function () { return view.length; }, function (idx) {
            var lineNo = view[idx];
            var row = document.createElement('div');
            row.className = 'tline';
            var g = el('span', 'tgutter', row);
            text(g, lineNo + 1);
            g.style.minWidth = (gutterW + 1) + 'ch';
            var c = el('span', 'tcontent', row);
            text(c, lines[lineNo] === '' ? ' ' : lines[lineNo]);
            return row;
        });
        vl.redraw();

        function applyFilter() {
            var q = filter.value.toLowerCase();
            view = [];
            if (q === '') { for (var k = 0; k < lines.length; k++) view.push(k); info.textContent = ''; }
            else {
                for (var k2 = 0; k2 < lines.length; k2++) if (lines[k2].toLowerCase().indexOf(q) >= 0) view.push(k2);
                info.textContent = view.length + ' matching line(s)';
            }
            vl.reset();
        }
        var deb;
        filter.addEventListener('input', function () { clearTimeout(deb); deb = setTimeout(applyFilter, 200); });
    }

    // ============================================================= CSV mode
    function renderCsv(host, content, name, meta) {
        var delim = detectDelimiter(firstLineOf(content), name);
        var data = parseCsv(content, delim);
        if (!data.length) { text(el('div', 'dim', host), 'Empty file'); return; }
        var header = data[0];
        var rows = data.slice(1);
        var nCols = header.length;
        meta.textContent = rows.length + ' rows · ' + nCols + ' cols · delim "' +
            (delim === TAB ? 'TAB' : delim) + '" · ' + fmtSize(content.length);

        // tabs
        var tabs = el('div', 'vwr-tabs', host);
        var tabTable = el('button', 'vtab active', tabs); text(tabTable, 'Table');
        var tabAgg = el('button', 'vtab', tabs); text(tabAgg, 'Aggregate');

        var paneTable = el('div', null, host);
        var paneAgg = el('div', null, host);
        paneAgg.style.display = 'none';

        tabTable.addEventListener('click', function () {
            tabTable.classList.add('active'); tabAgg.classList.remove('active');
            paneTable.style.display = ''; paneAgg.style.display = 'none';
        });
        tabAgg.addEventListener('click', function () {
            tabAgg.classList.add('active'); tabTable.classList.remove('active');
            paneAgg.style.display = ''; paneTable.style.display = 'none';
        });

        buildTablePane(paneTable, header, rows, nCols);
        buildAggPane(paneAgg, header, rows, name);
    }

    var COLW = 170;

    function buildTablePane(pane, header, rows, nCols) {
        var totalW = nCols * COLW;

        var tools = el('div', 'vwr-tools', pane);
        var filter = el('input', 'search-box', tools);
        filter.placeholder = '🔎 Filter rows (any column)…';
        var info = el('span', 'dim small', tools); info.style.marginLeft = '10px';

        var head = el('div', 'vgrid-head', pane);
        var headInner = el('div', 'vgrid-row', head);
        headInner.style.width = totalW + 'px';
        for (var c = 0; c < nCols; c++) {
            var hc = el('div', 'vgrid-cell head', headInner);
            hc.style.width = COLW + 'px';
            text(hc, header[c]);
        }

        var body = el('div', 'vwr-body vgrid', pane);

        var view = [];
        for (var r = 0; r < rows.length; r++) view.push(r);

        var vl = virtualList(body, 26, function () { return view.length; }, function (idx) {
            var ri = view[idx];
            var row = rows[ri];
            var rd = document.createElement('div');
            rd.className = 'vgrid-row' + (idx % 2 ? ' odd' : '');
            rd.style.width = totalW + 'px';
            for (var c2 = 0; c2 < nCols; c2++) {
                var cell = document.createElement('div');
                cell.className = 'vgrid-cell';
                cell.style.width = COLW + 'px';
                cell.textContent = row[c2] == null ? '' : row[c2];
                rd.appendChild(cell);
            }
            return rd;
        });
        vl.onDraw(function (left) { head.scrollLeft = left; });
        body.addEventListener('scroll', function () { head.scrollLeft = body.scrollLeft; });
        vl.redraw();

        function applyFilter() {
            var q = filter.value.toLowerCase();
            view = [];
            if (q === '') { for (var r2 = 0; r2 < rows.length; r2++) view.push(r2); info.textContent = ''; }
            else {
                for (var r3 = 0; r3 < rows.length; r3++) {
                    var hit = false, row = rows[r3];
                    for (var c3 = 0; c3 < row.length; c3++) { if (String(row[c3]).toLowerCase().indexOf(q) >= 0) { hit = true; break; } }
                    if (hit) view.push(r3);
                }
                info.textContent = view.length + ' / ' + rows.length + ' rows';
            }
            vl.reset();
        }
        var deb;
        filter.addEventListener('input', function () { clearTimeout(deb); deb = setTimeout(applyFilter, 250); });
    }

    function buildAggPane(pane, header, rows, name) {
        var bar = el('div', 'vwr-tools agg', pane);
        text(el('span', 'dim small', bar), 'Group by:');
        var chips = el('div', 'agg-cols', bar);
        var checks = [];
        for (var c = 0; c < header.length; c++) {
            (function (ci) {
                var lbl = el('label', 'agg-chip', chips);
                var cb = el('input', null, lbl); cb.type = 'checkbox'; cb.value = ci;
                text(el('span', null, lbl), header[ci]);
                checks.push(cb);
            })(c);
        }
        var go = el('button', 'btn sm primary', bar); text(go, 'Compute counts');
        go.style.marginLeft = '8px';
        var dl = el('button', 'btn sm', bar); text(dl, '⬇ Export'); dl.style.marginLeft = '6px'; dl.disabled = true;
        var summary = el('div', 'dim small', pane); summary.style.margin = '6px 0';

        var head = el('div', 'vgrid-head', pane);
        var body = el('div', 'vwr-body vgrid', pane);
        var current = null; // { cols, groups:[{vals,count}] }

        go.addEventListener('click', function () {
            var cols = [];
            checks.forEach(function (cb) { if (cb.checked) cols.push(parseInt(cb.value, 10)); });
            if (!cols.length) { summary.textContent = 'Select at least one column.'; return; }
            summary.textContent = 'Computing…';
            setTimeout(function () { compute(cols); }, 10);
        });

        function compute(cols) {
            var map = Object.create(null);
            var total = rows.length;
            for (var r = 0; r < total; r++) {
                var row = rows[r];
                var key = '';
                for (var k = 0; k < cols.length; k++) { if (k) key += SEP; key += (row[cols[k]] == null ? '' : row[cols[k]]); }
                map[key] = (map[key] || 0) + 1;
            }
            var groups = [];
            for (var key2 in map) {
                groups.push({ vals: key2.split(SEP), count: map[key2] });
            }
            groups.sort(function (a, b) { return b.count - a.count; });
            current = { cols: cols, groups: groups };
            summary.textContent = groups.length + ' distinct group(s) over ' + total + ' rows';
            dl.disabled = false;
            renderResult(cols, groups, total);
        }

        function renderResult(cols, groups, total) {
            var nc = cols.length + 2; // group cols + COUNT + %
            var totalW = (cols.length * COLW) + 110 + 90;
            head.innerHTML = '';
            var hr = el('div', 'vgrid-row', head); hr.style.width = totalW + 'px';
            cols.forEach(function (ci) { var h = el('div', 'vgrid-cell head', hr); h.style.width = COLW + 'px'; text(h, header[ci]); });
            var hc1 = el('div', 'vgrid-cell head', hr); hc1.style.width = '110px'; text(hc1, 'COUNT');
            var hc2 = el('div', 'vgrid-cell head', hr); hc2.style.width = '90px'; text(hc2, '%');

            var vl = virtualList(body, 26, function () { return groups.length; }, function (idx) {
                var g = groups[idx];
                var rd = document.createElement('div');
                rd.className = 'vgrid-row' + (idx % 2 ? ' odd' : '');
                rd.style.width = totalW + 'px';
                for (var k = 0; k < cols.length; k++) {
                    var cell = el('div', 'vgrid-cell', rd); cell.style.width = COLW + 'px';
                    cell.textContent = g.vals[k] == null ? '' : g.vals[k];
                }
                var cc = el('div', 'vgrid-cell num', rd); cc.style.width = '110px'; cc.textContent = g.count;
                var pc = el('div', 'vgrid-cell num dim', rd); pc.style.width = '90px';
                pc.textContent = (total ? (g.count * 100 / total).toFixed(2) : '0') + '%';
                return rd;
            });
            vl.onDraw(function (left) { head.scrollLeft = left; });
            body.addEventListener('scroll', function () { head.scrollLeft = body.scrollLeft; });
            vl.reset();
        }

        dl.addEventListener('click', function () {
            if (!current) return;
            var lines = [];
            var hdr = current.cols.map(function (ci) { return header[ci]; });
            hdr.push('COUNT');
            lines.push(hdr.join(';'));
            current.groups.forEach(function (g) {
                var vals = g.vals.slice();
                vals.push(g.count);
                lines.push(vals.map(csvField).join(';'));
            });
            var blob = new Blob([String.fromCharCode(0xFEFF) + lines.join(LF)], { type: 'text/csv;charset=utf-8' });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = (name.replace(/\.[^.]+$/, '') || 'aggregation') + '_counts.csv';
            a.click();
            setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
        });

        function csvField(s) {
            s = (s == null ? '' : String(s));
            if (s.indexOf(';') >= 0 || s.indexOf('"') >= 0 || s.charCodeAt(0) === CR || s.indexOf(LF) >= 0) {
                return '"' + s.replace(/"/g, '""') + '"';
            }
            return s;
        }
    }

    // ---- entry point ----
    function initViewer(opts) {
        var host = opts.host;
        host.innerHTML = '';
        var head = el('div', 'vwr-head', host);
        var title = el('div', null, head);
        text(el('span', 'vwr-name', title), opts.name || 'file');
        var meta = el('span', 'vwr-meta dim small', title); meta.style.marginLeft = '12px';
        var dl = el('a', 'btn sm', head); text(dl, '⬇ Download'); dl.href = opts.src; dl.style.marginLeft = 'auto';

        var bodyHost = el('div', null, host);
        var loading = el('div', 'dim', bodyHost); text(loading, 'Loading…');

        var isCsv = /\.(csv|tsv)$/i.test(opts.name || '');

        fetch(opts.src).then(function (r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.text();
        }).then(function (content) {
            bodyHost.innerHTML = '';
            if (isCsv) renderCsv(bodyHost, content, opts.name || '', meta);
            else renderText(bodyHost, content, opts.name || '', meta);
        }).catch(function (e) {
            bodyHost.innerHTML = '';
            text(el('div', 'banner error', bodyHost), 'Cannot load file: ' + e.message);
        });
    }

    global.initViewer = initViewer;
})(window);
