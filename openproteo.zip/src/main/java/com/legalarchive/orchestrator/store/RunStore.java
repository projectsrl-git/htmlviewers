package com.legalarchive.orchestrator.store;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.legalarchive.orchestrator.model.run.WorkflowRun;

/**
 * Persistenza dei run come singoli file JSON leggibili (pretty-printed)
 * in {feedDir}/_runs/{runId}.json. Nessun database: lo storico e' consultabile
 * anche senza applicazione, con un editor o PowerShell (ConvertFrom-Json).
 */
@Component
public class RunStore {

    private final ObjectMapper mapper = new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT)
            .configure(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    public synchronized void save(FeedLayout layout, WorkflowRun run) {
        try {
            Path f = layout.runFile(run.runId);
            Files.createDirectories(f.getParent());
            // scrittura atomica: tmp + move
            Path tmp = f.resolveSibling(f.getFileName() + ".tmp");
            mapper.writeValue(tmp.toFile(), run);
            Files.move(tmp, f, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            System.err.println("[RUNSTORE] salvataggio run " + run.runId + " fallito: " + e.getMessage());
        }
    }

    public WorkflowRun load(FeedLayout layout, String runId) {
        try {
            File f = layout.runFile(runId).toFile();
            if (!f.exists()) return null;
            return mapper.readValue(f, WorkflowRun.class);
        } catch (Exception e) {
            System.err.println("[RUNSTORE] lettura run " + runId + " fallita: " + e.getMessage());
            return null;
        }
    }

    /** Storico run del feed, dal piu' recente. */
    public List<WorkflowRun> list(FeedLayout layout, int max) {
        List<WorkflowRun> out = new ArrayList<WorkflowRun>();
        File dir = layout.runsDir.toFile();
        File[] files = dir.listFiles((d, n) -> n.endsWith(".json"));
        if (files == null) return out;
        for (File f : files) {
            try {
                out.add(mapper.readValue(f, WorkflowRun.class));
            } catch (Exception ignored) {
            }
        }
        out.sort(Comparator.comparing((WorkflowRun r) -> r.startTs == null ? "" : r.startTs).reversed());
        if (max > 0 && out.size() > max) return out.subList(0, max);
        return out;
    }
}
