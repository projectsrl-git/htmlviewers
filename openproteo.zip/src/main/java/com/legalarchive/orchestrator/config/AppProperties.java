package com.legalarchive.orchestrator.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Proprieta configurabili in application.properties con prefisso "orchestrator.".
 */
@ConfigurationProperties(prefix = "orchestrator")
public class AppProperties {

    /** Directory contenente le definizioni XML dei workflow. */
    private String workflowsDir = "./workflows";

    /** Directory base degli script PowerShell (per path relativi nelle definizioni). */
    private String scriptsDir = "./scripts";

    /** Base directory di default per i feed, usata se il workflow non specifica baseDir. */
    private String defaultBaseDir = "./feeds";

    /** Eseguibile PowerShell. Su server Windows: powershell.exe (o pwsh.exe per PS7). */
    private String powershellExe = "powershell.exe";

    /** Timeout di default in secondi per uno step, se non specificato nella definizione. */
    private int defaultStepTimeoutSec = 1800;

    /** Numero massimo di transizioni di nodo per run (guardia anti-loop nei gate). */
    private int maxTransitions = 500;

    public String getWorkflowsDir() { return workflowsDir; }
    public void setWorkflowsDir(String v) { this.workflowsDir = v; }
    public String getScriptsDir() { return scriptsDir; }
    public void setScriptsDir(String v) { this.scriptsDir = v; }
    public String getDefaultBaseDir() { return defaultBaseDir; }
    public void setDefaultBaseDir(String v) { this.defaultBaseDir = v; }
    public String getPowershellExe() { return powershellExe; }
    public void setPowershellExe(String v) { this.powershellExe = v; }
    public int getDefaultStepTimeoutSec() { return defaultStepTimeoutSec; }
    public void setDefaultStepTimeoutSec(int v) { this.defaultStepTimeoutSec = v; }
    public int getMaxTransitions() { return maxTransitions; }
    public void setMaxTransitions(int v) { this.maxTransitions = v; }
}
