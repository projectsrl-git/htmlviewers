package com.legalarchive.orchestrator.web;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.legalarchive.orchestrator.audit.AuditLogger;
import com.legalarchive.orchestrator.engine.WorkflowEngine;
import com.legalarchive.orchestrator.engine.WorkflowScheduler;
import com.legalarchive.orchestrator.model.run.WorkflowRun;
import com.legalarchive.orchestrator.registry.WorkflowRegistry;
import com.legalarchive.orchestrator.store.FeedLayout;
import com.legalarchive.orchestrator.store.RunStore;

@RestController
public class ApiController {

    private final WorkflowRegistry registry;
    private final WorkflowEngine engine;
    private final RunStore store;
    private final AuditLogger audit;
    private final WorkflowScheduler scheduler;

    public ApiController(WorkflowRegistry registry, WorkflowEngine engine, RunStore store,
                         AuditLogger audit, WorkflowScheduler scheduler) {
        this.registry = registry;
        this.engine = engine;
        this.store = store;
        this.audit = audit;
        this.scheduler = scheduler;
    }

    /** Avvio manuale di un workflow. */
    @PostMapping("/api/workflows/{feedId}/run")
    public ResponseEntity<Map<String, Object>> run(@PathVariable String feedId, HttpServletRequest req) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        try {
            WorkflowRun run = engine.start(feedId, "MANUAL", user(req));
            if (run == null) {
                out.put("ok", false);
                out.put("error", "Esiste gia' un run attivo per questo feed");
                return ResponseEntity.status(HttpStatus.CONFLICT).body(out);
            }
            out.put("ok", true);
            out.put("runId", run.runId);
            return ResponseEntity.ok(out);
        } catch (IllegalArgumentException e) {
            out.put("ok", false);
            out.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(out);
        }
    }

    /** Stato corrente di un run (polling UI). */
    @GetMapping("/api/runs/{feedId}/{runId}")
    public ResponseEntity<WorkflowRun> runState(@PathVariable String feedId, @PathVariable String runId) {
        WorkflowRun run = engine.activeRun(runId);
        if (run == null) {
            FeedLayout layout = registry.layout(feedId);
            if (layout != null) run = store.load(layout, runId);
        }
        return run == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(run);
    }

    /** Approvazione/rifiuto di un gate manuale in attesa. */
    @PostMapping("/api/runs/{feedId}/{runId}/decision")
    public ResponseEntity<Map<String, Object>> decision(@PathVariable String feedId, @PathVariable String runId,
                                                        @RequestParam boolean approve,
                                                        @RequestParam(required = false) String note,
                                                        HttpServletRequest req) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        boolean ok = engine.decide(feedId, runId, approve, user(req), note);
        out.put("ok", ok);
        if (!ok) out.put("error", "Il run non e' in attesa di approvazione");
        return ok ? ResponseEntity.ok(out) : ResponseEntity.status(HttpStatus.CONFLICT).body(out);
    }

    /** Log PowerShell di uno step (testo). */
    @GetMapping(value = "/api/runs/{feedId}/{runId}/log/{stepId}", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> stepLog(@PathVariable String feedId, @PathVariable String runId,
                                          @PathVariable String stepId,
                                          @RequestParam(value = "tail", defaultValue = "0") int tail) {
        FeedLayout layout = registry.layout(feedId);
        if (layout == null) return ResponseEntity.notFound().build();
        // anti path-traversal: solo nomi semplici
        if (!runId.matches("[A-Za-z0-9._-]+") || !stepId.matches("[A-Za-z0-9._-]+")) {
            return ResponseEntity.badRequest().body("Identificatori non validi");
        }
        Path log = layout.stepLog(runId, stepId);
        if (!Files.exists(log)) return ResponseEntity.ok("(nessun log disponibile)");
        try {
            java.util.List<String> lines = Files.readAllLines(log, StandardCharsets.UTF_8);
            if (tail > 0 && lines.size() > tail) lines = lines.subList(lines.size() - tail, lines.size());
            return ResponseEntity.ok(String.join(System.lineSeparator(), lines));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore lettura log: " + e.getMessage());
        }
    }

    /** Verifica integrita' della catena di audit. */
    @GetMapping("/api/audit/{feedId}/verify")
    public ResponseEntity<AuditLogger.VerifyResult> verify(@PathVariable String feedId) {
        FeedLayout layout = registry.layout(feedId);
        if (layout == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(audit.verify(layout.auditFile()));
    }

    /** Ricarica le definizioni XML e ripianifica i cron. */
    @PostMapping("/api/reload")
    public Map<String, Object> reload() {
        registry.reload();
        scheduler.reschedule();
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("ok", true);
        out.put("workflows", registry.all().size());
        out.put("errors", registry.errors());
        return out;
    }

    private String user(HttpServletRequest req) {
        String u = req.getHeader("X-User");
        if (u == null || u.trim().isEmpty()) u = req.getRemoteUser();
        if (u == null || u.trim().isEmpty()) u = "operator@" + req.getRemoteAddr();
        return u;
    }
}
