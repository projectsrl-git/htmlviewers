package com.legalarchive.orchestrator.engine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Esegue uno script PowerShell con ProcessBuilder.
 *
 * - Output (stdout+stderr) catturato riga per riga, timestampato e scritto sul log dello step.
 * - Encoding: la console PowerShell viene forzata a UTF-8 prima dell'invocazione,
 *   cosi' i caratteri accentati nei log non si corrompono.
 * - Variabili di output: lo script emette righe  ##VAR nome=valore  su stdout.
 * - Exit code propagato con "exit $LASTEXITCODE".
 *
 * Nota deploy: nessuna sequenza letterale problematica; la composizione del comando
 * usa solo apici singoli PowerShell (escape: raddoppio dell'apice).
 */
public class PowerShellExecutor {

    public static class Result {
        public int exitCode = -1;
        public boolean timedOut = false;
        public Map<String, String> outVars = new LinkedHashMap<String, String>();
        public String lastLines = "";
    }

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final String VAR_MARKER = "##VAR ";

    private final String powershellExe;

    public PowerShellExecutor(String powershellExe) {
        this.powershellExe = powershellExe;
    }

    public Result execute(String scriptPath, Map<String, String> params, Path logFile,
                          int timeoutSec, File workingDir) throws Exception {

        Result res = new Result();
        StringBuilder cmd = new StringBuilder();
        cmd.append("[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; ");
        cmd.append("$ErrorActionPreference='Stop'; ");
        cmd.append("& '").append(esc(scriptPath)).append("'");
        for (Map.Entry<String, String> p : params.entrySet()) {
            cmd.append(" -").append(p.getKey()).append(" '").append(esc(p.getValue())).append("'");
        }
        cmd.append("; exit $LASTEXITCODE");

        List<String> command = new ArrayList<String>();
        command.add(powershellExe);
        command.add("-NoProfile");
        command.add("-NonInteractive");
        command.add("-ExecutionPolicy");
        command.add("Bypass");
        command.add("-Command");
        command.add(cmd.toString());

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        if (workingDir != null && workingDir.isDirectory()) pb.directory(workingDir);

        Files.createDirectories(logFile.getParent());
        final List<String> tail = new ArrayList<String>();

        Process process = pb.start();
        final BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
        final BufferedWriter log = Files.newBufferedWriter(logFile, StandardCharsets.UTF_8,
                java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);

        Thread pump = new Thread(new Runnable() {
            public void run() {
                try {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        synchronized (log) {
                            log.write(LocalDateTime.now().format(TS) + "  " + line);
                            log.newLine();
                            log.flush();
                        }
                        if (line.startsWith(VAR_MARKER)) {
                            String kv = line.substring(VAR_MARKER.length()).trim();
                            int eq = kv.indexOf('=');
                            if (eq > 0) {
                                synchronized (res.outVars) {
                                    res.outVars.put(kv.substring(0, eq).trim(), kv.substring(eq + 1).trim());
                                }
                            }
                        }
                        synchronized (tail) {
                            tail.add(line);
                            if (tail.size() > 20) tail.remove(0);
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        }, "ps-output-pump");
        pump.setDaemon(true);
        pump.start();

        boolean finished = process.waitFor(timeoutSec, TimeUnit.SECONDS);
        if (!finished) {
            res.timedOut = true;
            process.destroyForcibly();
            process.waitFor(10, TimeUnit.SECONDS);
        }
        pump.join(5000);
        synchronized (log) {
            if (res.timedOut) {
                log.write(LocalDateTime.now().format(TS) + "  !!! TIMEOUT dopo " + timeoutSec + "s - processo terminato dall'orchestratore");
                log.newLine();
            }
            log.flush();
            log.close();
        }
        res.exitCode = res.timedOut ? -999 : process.exitValue();
        StringBuilder sb = new StringBuilder();
        synchronized (tail) {
            for (String t : tail) { sb.append(t); sb.append(' '); }
        }
        res.lastLines = sb.toString().trim();
        return res;
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("'", "''");
    }
}
