package com.legalarchive.orchestrator.engine;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

import com.legalarchive.orchestrator.audit.AuditLogger;
import com.legalarchive.orchestrator.config.AppProperties;
import com.legalarchive.orchestrator.model.def.GateDef;
import com.legalarchive.orchestrator.model.def.NodeDef;
import com.legalarchive.orchestrator.model.def.StepDef;
import com.legalarchive.orchestrator.model.def.WorkflowDef;
import com.legalarchive.orchestrator.model.run.GateExec;
import com.legalarchive.orchestrator.model.run.RunStatus;
import com.legalarchive.orchestrator.model.run.StepExec;
import com.legalarchive.orchestrator.model.run.StepStatus;
import com.legalarchive.orchestrator.model.run.WorkflowRun;
import com.legalarchive.orchestrator.registry.WorkflowRegistry;
import com.legalarchive.orchestrator.store.FeedLayout;
import com.legalarchive.orchestrator.store.RunStore;

/**
 * Motore di esecuzione: percorre i nodi del workflow in sequenza, esegue gli
 * step PowerShell, valuta i gate automatici e sospende il run sui gate manuali
 * (ripresi poi via approve/reject dalla UI). Ogni evento e' tracciato
 * nell'audit log del feed e lo stato del run e' persistito a ogni transizione.
 */
@Component
public class WorkflowEngine {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter ID_TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private final AppProperties props;
    private final WorkflowRegistry registry;
    private final RunStore store;
    private final AuditLogger audit;
    private final ExecutorService executor = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "wf-runner");
        t.setDaemon(true);
        return t;
    });

    /** feedId -> runId attualmente in esecuzione (un run alla volta per feed). */
    private final Map<String, String> runningFeeds = new ConcurrentHashMap<String, String>();
    /** Run attivi in memoria per polling veloce della UI. */
    private final Map<String, WorkflowRun> activeRuns = new ConcurrentHashMap<String, WorkflowRun>();
    private final AtomicLong seq = new AtomicLong(0);

    public WorkflowEngine(AppProperties props, WorkflowRegistry registry, RunStore store, AuditLogger audit) {
        this.props = props;
        this.registry = registry;
        this.store = store;
        this.audit = audit;
    }

    /** Avvia un run. Ritorna il run creato, o null se il feed ha gia' un run attivo. */
    public WorkflowRun start(String feedId, String trigger, String user) {
        WorkflowDef def = registry.get(feedId);
        FeedLayout layout = registry.layout(feedId);
        if (def == null || layout == null) {
            throw new IllegalArgumentException("Workflow sconosciuto: " + feedId);
        }
        synchronized (this) {
            if (runningFeeds.containsKey(feedId)) {
                auditFeed(layout, feedId, null, null, "RUN_REJECTED", user,
                        kv("reason", "run gia' attivo: " + runningFeeds.get(feedId), "trigger", trigger));
                return null;
            }
            WorkflowRun run = buildRun(def, layout, trigger, user);
            runningFeeds.put(feedId, run.runId);
            activeRuns.put(run.runId, run);
            store.save(layout, run);
            auditFeed(layout, feedId, run.runId, null, "RUN_STARTED", user,
                    kv("trigger", trigger, "workflow", def.name));
            executor.submit(() -> loop(def, layout, run, 0));
            return run;
        }
    }

    /** Decisione su un gate manuale in attesa: riprende il run. */
    public boolean decide(String feedId, String runId, boolean approve, String user, String note) {
        WorkflowDef def = registry.get(feedId);
        FeedLayout layout = registry.layout(feedId);
        if (def == null || layout == null) return false;
        WorkflowRun run = activeRuns.get(runId);
        if (run == null) run = store.load(layout, runId);
        if (run == null || run.status != RunStatus.WAITING_APPROVAL || run.waitingGateId == null) return false;

        NodeDef node = def.nodes.get(run.currentIndex);
        if (!(node instanceof GateDef) || !node.id.equals(run.waitingGateId)) return false;
        GateDef gate = (GateDef) node;

        // un altro run dello stesso feed potrebbe essere partito durante l'attesa
        String active = runningFeeds.get(feedId);
        if (active != null && !active.equals(runId)) return false;

        GateExec ge = run.gate(gate.id);
        if (ge != null) {
            ge.result = approve;
            ge.decidedBy = user;
            ge.ts = now();
        }
        auditFeed(layout, feedId, runId, gate.id, "GATE_DECISION", user,
                kv("decision", approve ? "APPROVE" : "REJECT", "note", note == null ? "" : note));

        run.waitingGateId = null;
        run.status = RunStatus.RUNNING;
        runningFeeds.put(feedId, runId);
        activeRuns.put(runId, run);
        store.save(layout, run);

        final WorkflowRun r = run;
        String target = approve ? gate.onTrue : gate.onFalse;
        executor.submit(() -> continueFromTarget(def, layout, r, gate, target));
        return true;
    }

    public WorkflowRun activeRun(String runId) {
        return activeRuns.get(runId);
    }

    // ------------------------------------------------------------------ core

    private WorkflowRun buildRun(WorkflowDef def, FeedLayout layout, String trigger, String user) {
        WorkflowRun run = new WorkflowRun();
        LocalDateTime now = LocalDateTime.now();
        run.runId = def.feedId + "_" + now.format(ID_TS) + "_" + String.format("%03d", seq.incrementAndGet() % 1000);
        run.feedId = def.feedId;
        run.workflowName = def.name;
        run.trigger = trigger;
        run.triggeredBy = user;
        run.startTs = now.format(TS);

        // variabili builtin: l'identita' del feed e' disponibile ovunque
        run.vars.put("feedId", def.feedId);
        run.vars.put("feedName", def.name);
        run.vars.put("runId", run.runId);
        run.vars.put("runDate", now.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
        run.vars.put("runTs", now.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")));
        run.vars.putAll(layout.dirVars());
        run.vars.putAll(def.variables);

        for (NodeDef n : def.nodes) {
            if (n instanceof StepDef) {
                StepExec se = new StepExec();
                se.stepId = n.id;
                se.name = n.name;
                run.steps.add(se);
            } else if (n instanceof GateDef) {
                GateExec ge = new GateExec();
                ge.gateId = n.id;
                ge.name = n.name;
                ge.type = ((GateDef) n).type;
                run.gates.add(ge);
            }
        }
        return run;
    }

    private void loop(WorkflowDef def, FeedLayout layout, WorkflowRun run, int startIndex) {
        int idx = startIndex;
        int transitions = 0;
        try {
            while (idx < def.nodes.size()) {
                if (++transitions > props.getMaxTransitions()) {
                    finish(def, layout, run, RunStatus.FAILED, "Superato il limite di " + props.getMaxTransitions()
                            + " transizioni: probabile loop nei gate");
                    return;
                }
                run.currentIndex = idx;
                NodeDef node = def.nodes.get(idx);

                if (node instanceof StepDef) {
                    boolean ok = executeStep(def, layout, run, (StepDef) node);
                    if (!ok) {
                        finish(def, layout, run, RunStatus.FAILED, "Step '" + node.id + "' fallito");
                        return;
                    }
                    idx++;
                } else {
                    GateDef gate = (GateDef) node;
                    if ("manual".equals(gate.type)) {
                        run.status = RunStatus.WAITING_APPROVAL;
                        run.waitingGateId = gate.id;
                        store.save(layout, run);
                        auditFeed(layout, run.feedId, run.runId, gate.id, "GATE_WAITING", "system",
                                kv("gate", gate.name));
                        runningFeeds.remove(run.feedId); // il feed non occupa il motore mentre attende
                        return; // sospeso: ripresa via decide()
                    }
                    String resolved = VarResolver.resolve(gate.condition, run.vars);
                    boolean result;
                    try {
                        result = VarResolver.evalCondition(resolved);
                    } catch (Exception e) {
                        auditFeed(layout, run.feedId, run.runId, gate.id, "GATE_ERROR", "system",
                                kv("condition", resolved, "error", e.getMessage()));
                        finish(def, layout, run, RunStatus.FAILED, "Gate '" + gate.id + "': condizione non valutabile");
                        return;
                    }
                    GateExec ge = run.gate(gate.id);
                    if (ge != null) { ge.condition = resolved; ge.result = result; ge.ts = now(); }
                    auditFeed(layout, run.feedId, run.runId, gate.id, "GATE_EVALUATED", "system",
                            kv("condition", resolved, "result", String.valueOf(result),
                               "target", result ? s(gate.onTrue) : s(gate.onFalse)));
                    store.save(layout, run);

                    Integer next = resolveTarget(def, layout, run, gate, result ? gate.onTrue : gate.onFalse);
                    if (next == null) return; // terminato da END:
                    idx = next;
                }
            }
            finish(def, layout, run, RunStatus.SUCCESS, null);
        } catch (Exception e) {
            finish(def, layout, run, RunStatus.FAILED, "Errore interno: " + e.getMessage());
        }
    }

    private void continueFromTarget(WorkflowDef def, FeedLayout layout, WorkflowRun run, GateDef gate, String target) {
        try {
            Integer next = resolveTarget(def, layout, run, gate, target);
            if (next == null) return;
            loop(def, layout, run, next);
        } catch (Exception e) {
            finish(def, layout, run, RunStatus.FAILED, "Errore interno: " + e.getMessage());
        }
    }

    /**
     * Risolve il target di un gate: indice del nodo, oppure null se il run e' stato
     * terminato (target END:STATO o assente = prosegui col nodo successivo).
     */
    private Integer resolveTarget(WorkflowDef def, FeedLayout layout, WorkflowRun run, GateDef gate, String target) {
        if (target == null) {
            int next = def.indexOfNode(gate.id) + 1;
            if (next >= def.nodes.size()) { finish(def, layout, run, RunStatus.SUCCESS, null); return null; }
            return next;
        }
        if (target.startsWith("END:")) {
            String st = target.substring(4).trim().toUpperCase();
            RunStatus rs;
            try { rs = RunStatus.valueOf(st); } catch (Exception e) { rs = RunStatus.ABORTED; }
            finish(def, layout, run, rs, "Terminato dal gate '" + gate.id + "' (" + target + ")");
            return null;
        }
        return def.indexOfNode(target);
    }

    private boolean executeStep(WorkflowDef def, FeedLayout layout, WorkflowRun run, StepDef step) {
        StepExec se = run.step(step.id);
        se.status = StepStatus.RUNNING;
        se.startTs = now();
        run.vars.put("stepDir", layout.stepDirs.get(step.id).toString());
        store.save(layout, run);

        String scriptPath = resolveScript(step.script);
        java.nio.file.Path logFile = layout.stepLog(run.runId, step.id);
        se.logFile = layout.logsDir.toAbsolutePath().relativize(logFile.toAbsolutePath()).toString();

        Map<String, String> resolvedParams = new LinkedHashMap<String, String>();
        for (Map.Entry<String, String> p : step.params.entrySet()) {
            resolvedParams.put(p.getKey(), VarResolver.resolve(p.getValue(), run.vars));
        }

        Map<String, String> startDet = new LinkedHashMap<String, String>();
        startDet.put("script", scriptPath);
        startDet.putAll(prefix(resolvedParams));
        auditFeed(layout, run.feedId, run.runId, step.id, "STEP_STARTED", "system", startDet);

        int timeout = step.timeoutSec > 0 ? step.timeoutSec : props.getDefaultStepTimeoutSec();
        PowerShellExecutor ps = new PowerShellExecutor(props.getPowershellExe());

        int maxAttempts = 1 + Math.max(0, step.retry);
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            se.attempts = attempt;
            try {
                PowerShellExecutor.Result res = ps.execute(scriptPath, resolvedParams, logFile,
                        timeout, layout.stepDirs.get(step.id).toFile());
                se.exitCode = res.exitCode;

                for (Map.Entry<String, String> ov : res.outVars.entrySet()) {
                    run.vars.put(ov.getKey(), ov.getValue());
                    auditFeed(layout, run.feedId, run.runId, step.id, "STEP_OUTPUT_VAR", "system",
                            kv("var", ov.getKey(), "value", ov.getValue()));
                }
                // segnala output dichiarati ma non prodotti
                for (String expected : step.outputs) {
                    if (!res.outVars.containsKey(expected)) {
                        auditFeed(layout, run.feedId, run.runId, step.id, "STEP_OUTPUT_MISSING", "system",
                                kv("var", expected));
                    }
                }

                if (res.exitCode == 0) {
                    se.status = StepStatus.SUCCESS;
                    se.endTs = now();
                    auditFeed(layout, run.feedId, run.runId, step.id, "STEP_COMPLETED", "system",
                            kv("exitCode", "0", "attempt", String.valueOf(attempt)));
                    store.save(layout, run);
                    return true;
                }

                String reason = res.timedOut ? "timeout " + timeout + "s" : "exit code " + res.exitCode;
                se.message = reason + (res.lastLines.isEmpty() ? "" : " - " + res.lastLines);
                if (attempt < maxAttempts) {
                    auditFeed(layout, run.feedId, run.runId, step.id, "STEP_RETRY", "system",
                            kv("attempt", String.valueOf(attempt), "reason", reason,
                               "nextInSec", String.valueOf(step.retryDelaySec)));
                    store.save(layout, run);
                    Thread.sleep(step.retryDelaySec * 1000L);
                } else {
                    se.status = StepStatus.FAILED;
                    se.endTs = now();
                    auditFeed(layout, run.feedId, run.runId, step.id, "STEP_FAILED", "system",
                            kv("exitCode", String.valueOf(res.exitCode), "attempts", String.valueOf(attempt),
                               "reason", reason));
                    store.save(layout, run);
                    return false;
                }
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                se.status = StepStatus.FAILED;
                se.endTs = now();
                se.message = "Interrotto";
                store.save(layout, run);
                return false;
            } catch (Exception e) {
                se.message = e.getMessage();
                if (attempt >= maxAttempts) {
                    se.status = StepStatus.FAILED;
                    se.endTs = now();
                    auditFeed(layout, run.feedId, run.runId, step.id, "STEP_FAILED", "system",
                            kv("error", String.valueOf(e.getMessage())));
                    store.save(layout, run);
                    return false;
                }
            }
        }
        return false;
    }

    private void finish(WorkflowDef def, FeedLayout layout, WorkflowRun run, RunStatus status, String message) {
        run.status = status;
        run.message = message;
        run.endTs = now();
        for (StepExec se : run.steps) {
            if (se.status == StepStatus.PENDING) se.status = StepStatus.SKIPPED;
        }
        store.save(layout, run);
        activeRuns.remove(run.runId);
        runningFeeds.remove(run.feedId);
        auditFeed(layout, run.feedId, run.runId, null,
                "RUN_" + (status == RunStatus.SUCCESS ? "COMPLETED" : status.name()), "system",
                message == null ? null : kv("message", message));
    }

    // --------------------------------------------------------------- helpers

    private String resolveScript(String script) {
        java.io.File f = new java.io.File(script);
        if (f.isAbsolute()) return f.getPath();
        return new java.io.File(props.getScriptsDir(), script).getAbsolutePath();
    }

    private void auditFeed(FeedLayout layout, String feedId, String runId, String node,
                           String event, String user, Map<String, String> details) {
        audit.log(layout.auditFile(), feedId, runId, node, event, user, details);
    }

    private static Map<String, String> kv(String... pairs) {
        Map<String, String> m = new LinkedHashMap<String, String>();
        for (int i = 0; i + 1 < pairs.length; i += 2) m.put(pairs[i], pairs[i + 1]);
        return m;
    }

    private static Map<String, String> prefix(Map<String, String> params) {
        Map<String, String> m = new LinkedHashMap<String, String>();
        for (Map.Entry<String, String> e : params.entrySet()) m.put("param." + e.getKey(), e.getValue());
        return m;
    }

    private static String now() { return LocalDateTime.now().format(TS); }
    private static String s(String v) { return v == null ? "(next)" : v; }

    @PreDestroy
    public void shutdown() {
        executor.shutdownNow();
    }
}
