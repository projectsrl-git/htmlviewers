package com.legalarchive.orchestrator.model.def;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Step eseguibile: lancia uno script PowerShell con parametri risolti. */
public class StepDef extends NodeDef {

    /** Path dello script .ps1 (assoluto o relativo a orchestrator.scriptsDir). */
    public String script;

    /** Timeout in secondi (0 = default applicativo). */
    public int timeoutSec = 0;

    /** Numero di tentativi aggiuntivi in caso di exit code != 0. */
    public int retry = 0;

    /** Attesa in secondi tra i tentativi. */
    public int retryDelaySec = 30;

    /** Parametri passati allo script come -Nome 'Valore' (con ${var} risolte). */
    public Map<String, String> params = new LinkedHashMap<String, String>();

    /** Variabili di output attese dallo script (righe "##VAR nome=valore" su stdout). */
    public List<String> outputs = new ArrayList<String>();

    @Override
    public String getKind() { return "STEP"; }
}
