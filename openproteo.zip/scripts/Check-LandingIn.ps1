param(
    [Parameter(Mandatory=$true)][string]$Path,
    [Parameter(Mandatory=$true)][string]$FeedId
)
# Conta i file presenti nella landing IN del feed.
# Convenzione orchestratore: le variabili di output si emettono con righe "##VAR nome=valore".

Write-Output "[$FeedId] Verifica landing: $Path"

if (-not (Test-Path -LiteralPath $Path)) {
    Write-Output "ERRORE: directory inesistente"
    exit 2
}

$files = Get-ChildItem -LiteralPath $Path -File
$count = ($files | Measure-Object).Count
Write-Output "Trovati $count file"
$files | ForEach-Object { Write-Output ("  - " + $_.Name + "  (" + $_.Length + " byte)") }

Write-Output "##VAR fileCount=$count"
exit 0
