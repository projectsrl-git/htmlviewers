param(
    [Parameter(Mandatory=$true)][string]$Source,
    [Parameter(Mandatory=$true)][string]$WorkDir,
    [Parameter(Mandatory=$true)][string]$Target,
    [Parameter(Mandatory=$true)][string]$FeedId,
    [Parameter(Mandatory=$true)][string]$RunId
)
# Demo di preparazione: copia i file dalla landing IN nella dir di lavoro,
# li comprime in un pacchetto ZIP nominato con feedId+runId e lo deposita in landing OUT.

Write-Output "[$FeedId] Preparazione pacchetto per run $RunId"

$staging = Join-Path $WorkDir $RunId
New-Item -ItemType Directory -Force -Path $staging | Out-Null
Copy-Item -Path (Join-Path $Source '*') -Destination $staging -Force

$zipName = "{0}_{1}.zip" -f $FeedId, $RunId
$zipPath = Join-Path $Target $zipName
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }

Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($staging, $zipPath)

$sizeKB = [math]::Round((Get-Item -LiteralPath $zipPath).Length / 1KB, 1)
Write-Output "Creato pacchetto: $zipPath ($sizeKB KB)"

Write-Output "##VAR packageFile=$zipPath"
Write-Output "##VAR packageSizeKB=$sizeKB"
exit 0
