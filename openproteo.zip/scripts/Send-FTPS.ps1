param(
    [Parameter(Mandatory=$true)][string]$PackageFile,
    [Parameter(Mandatory=$true)][string]$FtpsHost,
    [Parameter(Mandatory=$true)][string]$RemoteFolder,
    [Parameter(Mandatory=$true)][string]$FeedId
)
# Demo di spedizione FTPS: qui va integrato il client reale (WinSCP .NET assembly,
# curl.exe, o System.Net.FtpWebRequest con EnableSsl). Lo scheletro valida il
# pacchetto e simula l'upload, propagando l'exit code per il retry dell'orchestratore.

Write-Output "[$FeedId] Spedizione $PackageFile verso ftps://$FtpsHost$RemoteFolder"

if (-not (Test-Path -LiteralPath $PackageFile)) {
    Write-Output "ERRORE: pacchetto non trovato"
    exit 3
}

# --- ESEMPIO con WinSCP (decommentare e adattare) ---------------------------
# Add-Type -Path 'C:\Program Files (x86)\WinSCP\WinSCPnet.dll'
# $opt = New-Object WinSCP.SessionOptions -Property @{
#     Protocol   = [WinSCP.Protocol]::Ftp
#     FtpSecure  = [WinSCP.FtpSecure]::Explicit
#     HostName   = $FtpsHost
#     UserName   = $env:FTPS_USER
#     Password   = $env:FTPS_PASS
# }
# $session = New-Object WinSCP.Session
# try {
#     $session.Open($opt)
#     $res = $session.PutFiles($PackageFile, ($RemoteFolder + '/'))
#     $res.Check()
# } finally { $session.Dispose() }
# -----------------------------------------------------------------------------

Start-Sleep -Seconds 2
Write-Output "Upload simulato completato"
exit 0
