# Feed Orchestrator — Legal Archive

Orchestratore ed esecutore programmato di script PowerShell per la preparazione e
spedizione dei feed Legal Archive. Applicazione **Java 8 + Spring Boot 2.7 + Thymeleaf**,
un solo fat JAR con Tomcat embedded, **zero dipendenze esterne a runtime**
(nessuna CDN, nessun database server: tutto su file leggibili).

## I tre pilastri di ogni workflow

1. **feedId come chiave di tutto** — Ogni workflow è identificato dal *feed ID* del
   Legal Archive (es. `LA-EOR-001`) più un nome friendly. Il feedId compare nel run id,
   nella struttura directory, nei file di log e di stato, ed è disponibile in ogni step
   come variabile `${feedId}` da inserire in parametri e nomi file.

2. **Struttura directory provisionata automaticamente** — Al caricamento del workflow:

   ```
   {baseDir}/{feedId}/
     00_landing_in/            ← dati grezzi in arrivo (AS400)
     10_check_landing/         ← una directory per ogni step, in ordine
     20_prepare/
     30_send/
     99_landing_out/           ← pacchetti pronti per la spedizione FTPS
     _logs/
       audit_{feedId}.jsonl    ← audit log append-only con hash chain
       runs/{runId}/{step}.log ← output PowerShell di ogni step
     _runs/
       {runId}.json            ← stato di ogni esecuzione (pretty JSON)
   ```

3. **Audit log "audit proof"** — Un file JSON Lines per feed, append-only, dove ogni
   record contiene `prevHash` e `hash = SHA-256(seq|ts|feedId|runId|node|event|user|detailsJson|prevHash)`.
   Manomettere, cancellare o inserire una riga rompe la catena: la UI (e una verifica
   manuale) lo evidenziano. È testo semplice, consultabile con Notepad o PowerShell
   anche senza applicazione.

Nessun DB binario: lo "stato" è interamente in `_runs/*.json` (pretty-printed) e
`_logs/*.jsonl`.

## Build

Richiede Maven e un JDK 8+ (target bytecode 1.8):

```
mvn clean package
```

Produce `target/feed-orchestrator.jar`. *(Il progetto è consegnato come sorgente non
compilato: fare una prima build e un giro di test sul proprio ambiente, applicando poi
eventuali modifiche in modo incrementale.)*

## Avvio

```
java -jar feed-orchestrator.jar
```

UI su `http://localhost:8085`. Layout consigliato sul server:

```
D:\orchestrator\
  feed-orchestrator.jar
  application.properties      (override della configurazione)
  workflows\*.xml             (definizioni)
  scripts\*.ps1               (script PowerShell)
  feeds\                      (baseDir di default dei feed)
```

`application.properties` accanto al JAR sovrascrive i default:

```properties
server.port=8085
orchestrator.workflows-dir=D:/orchestrator/workflows
orchestrator.scripts-dir=D:/orchestrator/scripts
orchestrator.default-base-dir=D:/feeds
orchestrator.powershell-exe=powershell.exe
orchestrator.default-step-timeout-sec=1800
```

### Come servizio Windows (WinSW)

1. Scaricare `WinSW-x64.exe`, rinominarlo `feed-orchestrator-svc.exe` accanto al JAR.
2. Creare `feed-orchestrator-svc.xml`:

```xml
<service>
  <id>feed-orchestrator</id>
  <name>Legal Archive Feed Orchestrator</name>
  <description>Orchestratore feed Legal Archive</description>
  <executable>java</executable>
  <arguments>-jar "D:\orchestrator\feed-orchestrator.jar"</arguments>
  <workingdirectory>D:\orchestrator</workingdirectory>
  <logmode>rotate</logmode>
</service>
```

3. `feed-orchestrator-svc.exe install` poi `feed-orchestrator-svc.exe start`.

(In alternativa NSSM: `nssm install feed-orchestrator java -jar D:\orchestrator\feed-orchestrator.jar`.)

## Definizione di un workflow (XML)

Un file per feed in `workflows/`. Vedere `workflows/LA-EOR-001.xml` commentato. Sintesi:

```xml
<workflow feedId="LA-EOR-001" name="EORFULL verso Legal Archive"
          cron="0 30 6 * * MON-FRI" baseDir="D:/feeds">
  <description>...</description>
  <variables>
    <var name="minFiles" value="1"/>
  </variables>
  <steps>
    <step id="check_landing" name="Verifica landing IN" script="Check-LandingIn.ps1" timeoutSec="300">
      <param name="Path" value="${landingIn}"/>
      <param name="FeedId" value="${feedId}"/>
      <output var="fileCount"/>
    </step>
    <gate id="files_present" name="File presenti?"
          condition="${fileCount} &gt;= ${minFiles}"
          onTrue="prepare" onFalse="END:SKIPPED"/>
    <step id="prepare" ... retry="1" retryDelaySec="60"> ... </step>
    <gate id="approval" name="Approvazione spedizione" type="manual"
          onTrue="send" onFalse="END:REJECTED"/>
    <step id="send" ...> ... </step>
  </steps>
</workflow>
```

* **cron**: espressione Spring a 6 campi (`sec min ora giorno mese giornoSettimana`).
  Senza attributo `cron` il workflow è solo manuale.
* **gate auto**: `condition` con clausole `&&` o `||` (non misti) e operatori
  `== != >= <= > < contains notcontains matches exists notexists`.
  Confronto numerico se entrambi i lati sono numeri.
* **gate manual**: il run si sospende in `WAITING_APPROVAL`; un operatore approva o
  rifiuta dalla pagina del run (decisione, utente e nota finiscono nell'audit).
* **target dei gate**: id di un nodo, oppure `END:SUCCESS` / `END:SKIPPED` /
  `END:REJECTED` / `END:FAILED` per terminare il run con quello stato.
  Target omesso = prosegue col nodo successivo.

### Variabili builtin negli step

`${feedId}` `${feedName}` `${runId}` `${runDate}` `${runTs}`
`${feedDir}` `${landingIn}` `${landingOut}` `${logDir}`
`${stepDir}` (dir dello step corrente) `${dir.<stepId>}` (dir di uno step specifico)

### Contratto degli script PowerShell

* Parametri ricevuti come `-Nome 'Valore'` (i `${...}` sono già risolti).
* Working directory = directory dello step.
* **Exit code 0 = successo**; qualunque altro valore = fallimento (con retry se configurato).
* Variabili di output per gli step/gate successivi: righe su stdout nel formato

  ```
  ##VAR nome=valore
  ```

* Tutto lo stdout/stderr finisce timestampato in `_logs/runs/{runId}/{stepId}.log`.
* Non usare `$Host` come nome di parametro (variabile riservata PowerShell).

## API (usate dalla UI, utilizzabili anche da script)

| Metodo | Path | Descrizione |
|---|---|---|
| POST | `/api/workflows/{feedId}/run` | avvio manuale |
| GET | `/api/runs/{feedId}/{runId}` | stato del run (JSON) |
| POST | `/api/runs/{feedId}/{runId}/decision?approve=true&note=...` | decisione gate manuale |
| GET | `/api/runs/{feedId}/{runId}/log/{stepId}?tail=500` | log step (testo) |
| GET | `/api/audit/{feedId}/verify` | verifica catena audit |
| POST | `/api/reload` | ricarica XML e ripianifica i cron |

L'utente registrato nell'audit è preso dall'header `X-User` se presente (comodo dietro
reverse proxy con autenticazione), altrimenti `operator@<ip>`.

## Verifica manuale dell'audit (senza applicazione)

Il file `_logs/audit_{feedId}.jsonl` è verificabile a mano: per ogni riga,
`hash` deve essere lo SHA-256 della stringa
`seq|ts|feedId|runId|node|event|user|detailsJson|prevHash`
e `prevHash` deve coincidere con l'`hash` della riga precedente (prima riga: `GENESIS`).
Esempio di lettura rapida in PowerShell:

```powershell
Get-Content audit_LA-EOR-001.jsonl | ForEach-Object { $_ | ConvertFrom-Json } |
  Format-Table seq, ts, event, node, user
```

## Note operative

* **Un run alla volta per feed**: avvii concorrenti vengono rifiutati e tracciati in audit.
* Durante un gate manuale il feed non occupa il motore: il run resta sospeso su disco e
  riprende alla decisione, anche dopo riavvio dell'applicazione.
* Anti-loop: guardia configurabile `orchestrator.max-transitions` (default 500).
* Sviluppo consigliato: partire dalla base verificata e applicare modifiche una alla
  volta, testando sull'ambiente di rete aziendale dopo ogni passo.
