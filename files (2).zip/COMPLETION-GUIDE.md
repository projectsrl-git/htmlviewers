# Completion guide

How to fill the template and where each value comes from on the CMOD / IBM i instance. Replace every yellow `[[ ... ]]` placeholder.

## 1. Document control & system identification

Most of these are organisational. The technical ones:

| Field | Where to find it |
|-------|------------------|
| CMOD / OnDemand version & PTF level | Admin client *About*, or `arsadmin` version output on the instance. |
| Instance name | The instance you administer (`ARS_HOME` / instance config on IBM i). |
| DB2 library / schema | The library/schema that holds the instance's `ARS*` tables. |
| Storage manager | Whether the instance uses ASM only, or TSM / Spectrum Protect as backend. |
| Storage media | Whether content is in disk cache, optical, or tape (affects retrieval time and the dangling-pointer risk). |
| Primary formats | AFP / PDF / line-data — drives how much weight to give resources (AFP) and CCSID (line-data). |
| Character encoding | The CCSID(s) of index strings and line-data. |

## 2. Data model (6.1.1)

The narrative and Figure 1 are reusable as-is. If you want to list the concrete objects, retrieve the inventory from the system tables (names version-dependent):

- application groups — `ARSAG`
- applications — `ARSAPP`
- folders — `ARSFOLDER`
- segments per application group — `ARSSEG`

Confirm the actual names/columns on your version before quoting them.

## 3. Data dictionary (6.1.2)

For each in-scope application group, complete the field table (Section 4.2). Best sources, in order of reliability:

1. **OnDemand administration client** — shows each field's display name, type, and mapping between folder and application group.
2. **System field tables** — `ARSAGFLD` (application-group fields), `ARSFOLDERFLD` (folder fields), or your version's equivalents.

For each field record: folder name, physical column, type/length, **how it is actually stored** (verify dates — see below), business meaning, example, searchable Y/N.

Also complete **Note 2 (key datasets)**: list which application groups are in scope and which are out, one line of rationale each. This is the part that protects Legal.

## 4. Sample queries (6.1.3)

- Verify `arsdoc` flags with `arsdoc -h` on the instance (syntax differs across versions and platforms; on IBM i the utilities run under QSHELL/PASE).
- Resolve each application group's physical table name(s) via `ARSAG` / `ARSSEG` before writing Level 2 SQL — the data tables are system-named.
- Deliver the queries as **separate attachments**: one `.sql` (Level 2) and one `arsdoc`/shell script (Level 1).

## 5. Query guidance (6.1.4)

Two items you must verify on the instance and write down, because they cause silent errors:

- **Date storage** — confirm whether each date field is stored as an integer day-count and document the conversion. Test a known document's date both via the admin client (human-readable) and via SQL (raw) and reconcile them.
- **Segmentation** — confirm whether in-scope application groups are segmented and over how many tables, so Level 2 SQL spans them all.

## 6. Preservation controls (Section 7)

Before the hold is effective:

- **Suspend expiration** — disable or exclude `arsmaint` for the in-scope application groups, or extend their retention. Record it in the hold register (7.5).
- **Preserve the whole set** — DB2 index + storage objects + AFP resources + ASM/TSM environment. Preserving DB2 alone leaves dangling pointers.
- **Arrange access** — a CMOD user with permissions on the in-scope groups, or admin-performed extraction.
- **Chain of custody** — record tool/version, operator, date; keep hashes/manifests of extracted sets.

## Final check

Work through **Appendix B — Completion checklist** in the document. Confirm no yellow highlight remains.
