# Changelog

All notable changes to the CMOD Legal Hold / Preservation template.

## [0.1] — initial

### Added
- Fillable DOCX template (US Letter, Arial) for a CMOD-on-IBM i legal hold / preservation document, Legal + IT audience.
- Front matter: document control table, table of contents, "template note" callout.
- Section 1 — Purpose & scope, with the "CMOD is a document archive, not a relational database" key-concept callout.
- Section 2 — System identification table.
- Section 3 — Data model (6.1.1): logical objects, two physical planes, AFP resources, and Figure 1 (`cmod_data_model.png`).
- Section 4 — Data dictionary (6.1.2): worked finance example + empty field table to complete; physical-to-logical and key-dataset notes.
- Section 5 — Sample queries (6.1.3): Level 1 (`arsdoc` / ODWEK, returns documents) and Level 2 (DB2 SQL, index only), with a "Critical" callout and code blocks.
- Section 6 — Query guidance (6.1.4): twelve peculiarities.
- Section 7 — Preservation & legal hold controls: expiration suspension, storage/resource/ASM-TSM preservation, access, chain of custody, hold register.
- Appendix A (glossary) and Appendix B (completion checklist).
- Placeholders highlighted in yellow as `[[ ... ]]`; header/footer with page numbering and classification placeholder.

### Build notes
- Generated with `generate_docx.js` (Node, `docx` v9.x).
- Post-build fix: docx-js emits an invalid `highlightCs` element with run highlighting. Strip it before issue:
  ```
  unpack → sed -i '/highlightCs/d' word/document.xml word/header1.xml → pack
  ```
  After this the document passes OOXML validation.

### To verify before issue
- All `arsdoc` flags and `ARS*` table/column names against the target CMOD version.
- Date-field storage representation and application-group segmentation on the instance.
