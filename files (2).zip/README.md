# CMOD Legal Hold / Preservation — Deliverable

A reusable **data preservation & legal hold** document for an **IBM Content Manager OnDemand (CMOD)** archive running on **IBM i / AS400**, written for a combined **Legal + IT** audience. It answers the four sections of the standard decommissioning/preservation framework (6.1.1–6.1.4) and adds the legal-hold controls that the framework itself does not cover.

## Files

| File | Purpose |
|------|---------|
| `CMOD_Legal_Hold_Preservation.docx` | The fillable template (US Letter). Edit the highlighted placeholders, then issue. |
| `cmod_data_model.png` | The Figure 1 diagram, in case you want to reuse it elsewhere. |
| `COMPLETION-GUIDE.md` | How to fill every placeholder and where to source each value on the instance. |
| `CHANGELOG.md` | Version history of the template. |
| `README.md` | This file. |

## What the document contains

1. **Purpose & scope** — including the one concept Legal must grasp first: *CMOD is a document archive, not a relational database*. The DB2 index and the document content are two separate planes; SQL returns the index only.
2. **System identification** — the instance facts a third party needs.
3. **6.1.1 Data model** — four logical objects (Instance, Application group, Application, Folder), two physical planes (DB2 index / storage objects), AFP resources, and Figure 1.
4. **6.1.2 Data dictionary** — a worked finance example plus an empty field table to complete, linking physical columns to business concepts.
5. **6.1.3 Sample queries** — two levels: `arsdoc` / ODWEK retrieval (returns documents) vs direct DB2 SQL (index only).
6. **6.1.4 Query guidance** — the twelve peculiarities that silently break queries (segmentation, integer dates, CCSID, dangling pointers, etc.).
7. **Preservation & legal hold controls** — suspending `arsmaint` expiration, preserving storage + resources + ASM/TSM, access, chain of custody, hold register.
8. **Appendix A — Glossary**, **Appendix B — Completion checklist**.

## Conventions

- Placeholders are **highlighted in yellow** as `[[ ... ]]`. Replace every one before issue (see the checklist in Appendix B).
- CMOD **system-table and column names** (`ARSAG`, `ARSSEG`, `cpty`, etc.) and **`arsdoc` flags** are **version-dependent** and shown as examples. Verify them on the target instance before finalising.

## Editing

Open in Word/LibreOffice and edit directly, or regenerate from `generate_docx.js` (Node + the `docx` package). After regenerating, strip the spurious `highlightCs` tags (a docx-js quirk) and repack — see CHANGELOG for the exact step.
