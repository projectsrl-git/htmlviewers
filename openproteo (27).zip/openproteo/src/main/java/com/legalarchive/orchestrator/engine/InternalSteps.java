package com.legalarchive.orchestrator.engine;

import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.legalarchive.orchestrator.ds.DataSourceDef;
import com.legalarchive.orchestrator.ds.DataSourceStore;
import com.legalarchive.orchestrator.ds.IfsSupport;
import com.legalarchive.orchestrator.ds.SqlSupport;
import com.legalarchive.orchestrator.model.def.StepDef;
import com.legalarchive.orchestrator.model.def.Replacement;

/**
 * Executes the built-in step kinds in-process (no external process):
 *   sql      - run a query on a datasource; emit rowCount and first-row columns as vars
 *   ifscopy  - native IFS copy from AS400 to a local directory (JTOpen)
 *   filecopy - copy/move/list files between local directories by glob pattern
 *   setvar   - assign/compute run variables (supports simple +/- integer math)
 *
 * Each method writes a timestamped log to the step log file and returns a
 * StepExecutor.Result so the engine treats internal and external steps uniformly.
 */
@Component
public class InternalSteps {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private final DataSourceStore dataSources;
    private final SqlSupport sql;
    private final IfsSupport ifs;
    private final com.legalarchive.orchestrator.config.AppProperties props;

    public InternalSteps(DataSourceStore dataSources, SqlSupport sql, IfsSupport ifs,
                         com.legalarchive.orchestrator.config.AppProperties props) {
        this.dataSources = dataSources;
        this.sql = sql;
        this.ifs = ifs;
        this.props = props;
    }

    public StepExecutor.Result run(String kind, StepDef step, Map<String, String> resolvedParams,
                                   Map<String, String> vars, Path logFile, RunControl control,
                                   com.legalarchive.orchestrator.model.run.StepExec se, Runnable onProgress) {
        StepExecutor.Result res = new StepExecutor.Result();
        BufferedWriter log = null;
        try {
            Files.createDirectories(logFile.getParent());
            log = Files.newBufferedWriter(logFile, StandardCharsets.UTF_8,
                    java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
            final BufferedWriter flog = log;
            java.util.function.Consumer<String> line = new java.util.function.Consumer<String>() {
                public void accept(String s) {
                    try { flog.write("O\t" + LocalDateTime.now().format(TS) + "\t" + s); flog.newLine(); flog.flush(); }
                    catch (Exception ignored) {}
                }
            };

            if (control != null && control.aborted) { line.accept("aborted before start"); res.exitCode = -997; return res; }

            if ("sql".equals(kind)) {
                runSql(step, resolvedParams, vars, res, line);
            } else if ("ifscopy".equals(kind)) {
                runIfsCopy(step, vars, res, line);
            } else if ("filecopy".equals(kind)) {
                runFileCopy(step, vars, res, line);
            } else if ("setvar".equals(kind)) {
                runSetVar(resolvedParams, vars, res, line);
            } else if ("validate".equals(kind)) {
                runValidate(step, resolvedParams, vars, res, line, se, onProgress);
            } else if ("encoding".equals(kind)) {
                runEncoding(step, resolvedParams, vars, res, line);
            } else if ("anonymize".equals(kind)) {
                runAnonymize(step, resolvedParams, vars, res, line, se, onProgress);
            } else if ("csvreplace".equals(kind)) {
                runReplace(step, resolvedParams, vars, res, line);
            } else {
                line.accept("unknown internal step kind: " + kind);
                res.exitCode = -996;
            }
        } catch (Exception e) {
            res.exitCode = res.exitCode == 0 ? 1 : res.exitCode;
            res.lastLines = e.getMessage();
            safeLine(log, "ERROR: " + e.getMessage());
        } finally {
            if (log != null) try { log.close(); } catch (Exception ignored) {}
        }
        return res;
    }

    // ----------------------------------------------------------------- sql
    private void runSql(StepDef step, Map<String, String> params, Map<String, String> vars,
                        StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        DataSourceDef d = dataSources.get(step.datasource);
        if (d == null) { line.accept("datasource not found: " + step.datasource); res.exitCode = 2; return; }
        String query = VarResolver.resolve(step.query, vars);
        line.accept("datasource: " + d.id + " (" + d.type + ")");
        line.accept("query: " + query);

        // CSV export path: stream the full result set to a file
        String csvFile = VarResolver.resolve(step.csvFile, vars);
        boolean trim = !"false".equalsIgnoreCase(params.get("trim"));   // CHAR padding: trimmed by default
        if (csvFile != null && !csvFile.trim().isEmpty()) {
            char delim = (step.delimiter != null && !step.delimiter.isEmpty()) ? step.delimiter.charAt(0) : ';';
            java.io.File out = new java.io.File(csvFile);
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            long maxRows = step.csvSplitRows > 0 ? step.csvSplitRows : 0;
            long maxBytes = step.csvSplitMb > 0 ? (long) step.csvSplitMb * 1024L * 1024L : 0;
            SqlSupport.ExportResult er = sql.exportCsv(d, query, out, delim, true, maxRows, maxBytes, trim);
            res.outVars.put("rowCount", String.valueOf(er.rows));
            res.outVars.put("csvParts", String.valueOf(er.parts));
            res.outVars.put("csvFile", er.files.isEmpty() ? out.getAbsolutePath() : er.files.get(0));
            res.outVars.put("csvFiles", String.join(step.delimiter == null ? ";" : step.delimiter, er.files));
            if (er.parts > 1) line.accept("exported " + er.rows + " row(s) into " + er.parts + " CSV part(s)");
            else line.accept("exported " + er.rows + " row(s) to " + res.outVars.get("csvFile"));
            for (String f : er.files) line.accept("  " + f);
            for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
            res.exitCode = 0;
            return;
        }

        SqlSupport.QueryResult qr = sql.run(d, query, 1000, trim);
        if (qr.updateCount != null) {
            line.accept("update count: " + qr.updateCount);
            res.outVars.put("updateCount", String.valueOf(qr.updateCount));
        } else {
            line.accept("returned rows: " + qr.rowCount + (qr.truncated ? " (truncated at 1000)" : ""));
            res.outVars.put("rowCount", String.valueOf(qr.rowCount));
            // first row columns exposed as ${col_<NAME>}
            if (!qr.rows.isEmpty()) {
                List<String> r0 = qr.rows.get(0);
                for (int i = 0; i < qr.columns.size() && i < r0.size(); i++) {
                    res.outVars.put("col_" + qr.columns.get(i), r0.get(i));
                }
                res.outVars.put("firstValue", SqlSupport.firstValue(qr));
            }
            // optional: store all first-column values joined, for downstream steps
            if (step.outputVar != null && !step.outputVar.trim().isEmpty() && !qr.columns.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (List<String> r : qr.rows) { if (sb.length() > 0) sb.append(step.delimiter == null ? ";" : step.delimiter); sb.append(r.get(0)); }
                res.outVars.put(step.outputVar.trim(), sb.toString());
            }
        }
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // ------------------------------------------------------------- ifscopy
    private void runIfsCopy(StepDef step, Map<String, String> vars,
                            StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        DataSourceDef d = dataSources.get(step.datasource);
        if (d == null) { line.accept("datasource not found: " + step.datasource); res.exitCode = 2; return; }
        String ifsPath = VarResolver.resolve(step.ifsPath, vars);
        String dest = VarResolver.resolve(step.dest, vars);
        String glob = VarResolver.resolve(step.pattern, vars);
        line.accept("IFS copy " + ifsPath + "  ->  " + dest + "  (pattern " + (glob == null ? "*" : glob) + ")");
        IfsSupport.CopyResult cr = ifs.copyToLocal(d, ifsPath, dest, glob, step.overwrite, line);
        res.outVars.put("filesCopied", String.valueOf(cr.filesCopied));
        res.outVars.put("bytesCopied", String.valueOf(cr.bytesCopied));
        res.outVars.put("matchedFiles", String.join(step.delimiter == null ? ";" : step.delimiter, cr.names));
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // ------------------------------------------------------------ filecopy
    private void runFileCopy(StepDef step, Map<String, String> vars,
                             StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        String source = VarResolver.resolve(step.source, vars);
        String dest = VarResolver.resolve(step.dest, vars);
        String glob = VarResolver.resolve(step.pattern, vars);
        String mode = step.mode == null ? "copy" : step.mode.toLowerCase(); // copy | move | list
        if (glob == null || glob.trim().isEmpty()) glob = "*";

        Path src = Paths.get(source);
        if (!Files.isDirectory(src)) { line.accept("source directory not found: " + source); res.exitCode = 2; return; }
        line.accept(mode + "  " + source + "  pattern " + glob + (("list".equals(mode)) ? "" : ("  -> " + dest)));

        List<String> names = new ArrayList<String>();
        long bytes = 0;
        Path outDir = null;
        if (!"list".equals(mode)) {
            outDir = Paths.get(dest);
            Files.createDirectories(outDir);
        }
        DirectoryStream<Path> ds = Files.newDirectoryStream(src, glob);
        try {
            for (Path f : ds) {
                if (Files.isDirectory(f)) continue;
                names.add(f.getFileName().toString());
                if ("list".equals(mode)) continue;
                Path target = outDir.resolve(f.getFileName());
                if ("move".equals(mode)) {
                    Files.move(f, target, StandardCopyOption.REPLACE_EXISTING);
                } else {
                    Files.copy(f, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                }
                bytes += Files.size(target);
                line.accept(mode + " " + f.getFileName());
            }
        } finally {
            ds.close();
        }
        res.outVars.put("matchedCount", String.valueOf(names.size()));
        res.outVars.put("matchedFiles", String.join(step.delimiter == null ? ";" : step.delimiter, names));
        if (!"list".equals(mode)) res.outVars.put("bytesCopied", String.valueOf(bytes));
        for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
        res.exitCode = 0;
    }

    // -------------------------------------------------------------- setvar
    /** params are name -> expression; expressions support ${vars} and simple a + b / a - b integer math. */
    private void runSetVar(Map<String, String> params, Map<String, String> vars,
                           StepExecutor.Result res, java.util.function.Consumer<String> line) {
        for (Map.Entry<String, String> e : params.entrySet()) {
            String value = evalArithmetic(e.getValue());
            res.outVars.put(e.getKey(), value);
            line.accept("##VAR " + e.getKey() + "=" + value);
        }
        res.exitCode = 0;
    }

    /** Evaluate "A + B" or "A - B" as integers when both sides are integers; otherwise return as-is. */
    private String evalArithmetic(String expr) {
        if (expr == null) return "";
        String s = expr.trim();
        for (String op : new String[]{"+", "-"}) {
            int idx = s.indexOf(' ' + op + ' ');
            if (idx > 0) {
                String a = s.substring(0, idx).trim();
                String b = s.substring(idx + 3).trim();
                try {
                    long la = Long.parseLong(a), lb = Long.parseLong(b);
                    return String.valueOf("+".equals(op) ? la + lb : la - lb);
                } catch (NumberFormatException ignored) {
                    return s;
                }
            }
        }
        return s;
    }

    // -------------------------------------------------------------- csvreplace
    // -------------------------------------------------------------- anonymize (ARX) — Batch 1 skeleton
    /**
     * BATCH 1 scaffold for CSV anonymisation with ARX. It performs preflight, a conservative
     * resource fail-fast guard, date-column passthrough detection (with explicit overrides) and
     * writes the output — but the actual ARX transformation is NOT wired yet: every column is
     * passed through verbatim (placeholder), as agreed for Batch 1. Sub-steps are surfaced as a
     * live checklist (like the validate step).
     */
    private void runAnonymize(StepDef step, Map<String, String> params, Map<String, String> vars,
                              StepExecutor.Result res, java.util.function.Consumer<String> line,
                              com.legalarchive.orchestrator.model.run.StepExec se, Runnable onProgress) throws Exception {
        final java.util.List<com.legalarchive.orchestrator.model.run.CheckResult> checks = new ArrayList<com.legalarchive.orchestrator.model.run.CheckResult>();
        String[][] subs = {
                {"preflight", "Preflight (rows/columns/cells/delimiter/encoding)"},
                {"guard", "Resource guard (estimate vs heap) — fail-fast"},
                {"dates", "Date column detection + overrides"},
                {"config", "Build anonymisation configuration"},
                {"anonymize", "Run anonymisation"},
                {"output", "Write output"}
        };
        for (String[] sb : subs) checks.add(new com.legalarchive.orchestrator.model.run.CheckResult(sb[0], sb[1]));
        if (se != null) { se.checks = checks; if (onProgress != null) onProgress.run(); }
        final java.util.Map<String, com.legalarchive.orchestrator.model.run.CheckResult> byId = new java.util.HashMap<String, com.legalarchive.orchestrator.model.run.CheckResult>();
        for (com.legalarchive.orchestrator.model.run.CheckResult c : checks) byId.put(c.id, c);
        java.util.function.BiConsumer<String, String[]> set = new java.util.function.BiConsumer<String, String[]>() {
            public void accept(String id, String[] sd) {
                com.legalarchive.orchestrator.model.run.CheckResult c = byId.get(id);
                if (c == null) return;
                c.status = sd[0]; c.detail = sd[1];
                line.accept("[" + id + "] " + sd[0] + (sd[1] != null ? ("  " + sd[1]) : ""));
                if (onProgress != null) onProgress.run();
            }
        };
        java.util.function.Consumer<String> running = new java.util.function.Consumer<String>() {
            public void accept(String id) { com.legalarchive.orchestrator.model.run.CheckResult c = byId.get(id); if (c != null) { c.status = "RUNNING"; if (onProgress != null) onProgress.run(); } }
        };

        long maxRows = pLong(params.get("maxRows"), props != null ? props.getAnonymizeMaxRows() : 5_000_000L);
        long maxCells = pLong(params.get("maxCells"), props != null ? props.getAnonymizeMaxCells() : 200_000_000L);
        int bytesPerCell = (int) pLong(params.get("bytesPerCell"), props != null ? props.getAnonymizeBytesPerCell() : 64);
        int heapHeadroomMb = (int) pLong(params.get("heapHeadroomMb"), props != null ? props.getAnonymizeHeapHeadroomMb() : 256);
        int sampleSize = (int) pLong(params.get("dateSampleSize"), props != null ? props.getDateSampleSize() : 200);
        double dateThreshold = pDouble(params.get("datePassthroughThreshold"), props != null ? props.getDatePassthroughThreshold() : 0.95);
        int minYear = (int) pLong(params.get("dateMinYear"), props != null ? props.getDateMinYear() : 1900);
        int maxYear = (int) pLong(params.get("dateMaxYear"), props != null ? props.getDateMaxYear() : 2099);

        String inPath = VarResolver.resolve(step.source, vars);
        java.io.File in = new java.io.File(inPath);
        if (!in.isFile()) { set.accept("preflight", new String[]{"FAIL", "input file not found: " + inPath}); res.exitCode = 2; return; }

        // 1) preflight: quote-aware single streaming pass (bounded memory)
        running.accept("preflight");
        char delim = (step.delimiter != null && !step.delimiter.isEmpty()) ? step.delimiter.charAt(0) : sniffDelimiter(in);
        long fileBytes = in.length();
        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(in), StandardCharsets.UTF_8), 1 << 16);
        long dataRows = 0; int columns = 0;
        java.util.List<String> headerCols = null;
        boolean bom = false;
        try {
            r.mark(4); if (r.read() != 0xFEFF) r.reset(); else bom = true;
            String header = r.readLine();
            if (header != null) { headerCols = parseCsv(header, delim); columns = headerCols.size(); }
            boolean inQ = false, anyChar = false; int ch;
            while ((ch = r.read()) != -1) {
                char c = (char) ch;
                if (c == '"') { inQ = !inQ; anyChar = true; continue; }
                if (!inQ && c == '\n') { dataRows++; anyChar = false; continue; }
                if (c != '\r') anyChar = true;
            }
            if (anyChar) dataRows++;
        } finally { r.close(); }
        long cells = dataRows * (long) columns;
        set.accept("preflight", new String[]{"PASS", dataRows + " rows x " + columns + " cols = " + cells + " cells; delimiter '" + delim + "'; " + fileBytes + " bytes; UTF-8" + (bom ? " (BOM)" : "")});
        res.outVars.put("dataRows", String.valueOf(dataRows));
        res.outVars.put("columns", String.valueOf(columns));
        res.outVars.put("cells", String.valueOf(cells));

        // 2) resource guard (conservative fail-fast)
        running.accept("guard");
        long maxHeap = Runtime.getRuntime().maxMemory();
        long estimate = cells * (long) bytesPerCell;
        long headroom = (long) heapHeadroomMb * 1024L * 1024L;
        java.util.List<String> guardFail = new ArrayList<String>();
        if (maxRows > 0 && dataRows > maxRows) guardFail.add("rows " + dataRows + " > limit " + maxRows);
        if (maxCells > 0 && cells > maxCells) guardFail.add("cells " + cells + " > limit " + maxCells);
        if (estimate + headroom > maxHeap) guardFail.add("estimate " + mb(estimate) + "MB + headroom " + heapHeadroomMb + "MB > maxHeap " + mb(maxHeap) + "MB");
        if (!guardFail.isEmpty()) {
            set.accept("guard", new String[]{"FAIL", String.join("; ", guardFail) + " — aborting before ARX to avoid OutOfMemory"});
            for (String id : new String[]{"dates", "config", "anonymize", "output"}) set.accept(id, new String[]{"SKIP", "blocked by resource guard"});
            res.exitCode = 3;
            return;
        }
        set.accept("guard", new String[]{"PASS", "estimate ~" + mb(estimate) + "MB, maxHeap " + mb(maxHeap) + "MB, headroom " + heapHeadroomMb + "MB (conservative proxy)"});

        // 3) date column detection + overrides
        running.accept("dates");
        java.util.Set<String> forcePass = csvSet(params.get("forcePassthroughColumns"));
        java.util.Set<String> forceAnon = csvSet(params.get("forceAnonymizeColumns"));
        java.util.List<String> dateCols = new ArrayList<String>();
        if (headerCols != null && columns > 0) {
            int[] sampled = new int[columns];
            int[] matched = new int[columns];
            java.io.BufferedReader r2 = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(in), StandardCharsets.UTF_8), 1 << 16);
            try {
                r2.mark(4); if (r2.read() != 0xFEFF) r2.reset();
                r2.readLine();
                String dl; boolean more = true;
                while (more && (dl = r2.readLine()) != null) {
                    java.util.List<String> f = parseCsv(dl, delim);
                    more = false;
                    for (int ci = 0; ci < columns; ci++) {
                        if (sampled[ci] >= sampleSize) continue;
                        more = true;
                        String v = ci < f.size() ? f.get(ci).trim() : "";
                        if (v.isEmpty()) continue;
                        sampled[ci]++;
                        if (looksLikeDate(v, minYear, maxYear)) matched[ci]++;
                    }
                }
            } finally { r2.close(); }
            for (int ci = 0; ci < columns; ci++) {
                String name = headerCols.get(ci).trim();
                boolean pass = sampled[ci] > 0 && (matched[ci] / (double) sampled[ci]) >= dateThreshold;
                if (forceAnon.contains(name)) pass = false;
                if (forcePass.contains(name)) pass = true;
                if (pass) dateCols.add(name);
            }
        }
        set.accept("dates", new String[]{"PASS", dateCols.isEmpty() ? "no date-passthrough columns" : (dateCols.size() + " passthrough: " + join(dateCols, 8))});
        res.outVars.put("dateColumns", String.join(",", dateCols));

        // 4) build configuration (deferred to Batch 2)
        running.accept("config");
        set.accept("config", new String[]{"SKIP", "ARX configuration deferred to Batch 2 (date columns -> INSENSITIVE; other roles TBD)"});

        // 5) anonymise (Batch 1 placeholder passthrough)
        running.accept("anonymize");
        set.accept("anonymize", new String[]{"SKIP", "Batch 1 placeholder — passthrough (no ARX transformation yet)"});

        // 6) write output (verbatim copy, same delimiter/encoding)
        running.accept("output");
        String outParam = blankToNull(VarResolver.resolve(params.get("outFile"), vars));
        java.io.File out = outParam != null ? new java.io.File(outParam) : new java.io.File(in.getParentFile(), stripExt(in.getName()) + "_anon" + ext(in.getName()));
        if (out.getParentFile() != null) out.getParentFile().mkdirs();
        java.nio.file.Files.copy(in.toPath(), out.toPath(), StandardCopyOption.REPLACE_EXISTING);
        set.accept("output", new String[]{"PASS", "written " + out.getName() + " (passthrough copy)"});
        res.outVars.put("outputFile", out.getAbsolutePath());
        line.accept("##VAR outputFile=" + out.getAbsolutePath());
        line.accept("##VAR dataRows=" + dataRows);
        line.accept("##VAR dateColumns=" + String.join(",", dateCols));
        res.exitCode = 0;
        line.accept("anonymize (Batch 1 skeleton): preflight+guard+date-detection done, output is a passthrough copy");
    }

    private static long pLong(String v, long def) { try { return v == null || v.trim().isEmpty() ? def : Long.parseLong(v.trim()); } catch (Exception e) { return def; } }
    private static double pDouble(String v, double def) { try { return v == null || v.trim().isEmpty() ? def : Double.parseDouble(v.trim()); } catch (Exception e) { return def; } }
    private static long mb(long bytes) { return bytes / (1024L * 1024L); }
    private static java.util.Set<String> csvSet(String v) {
        java.util.Set<String> out = new java.util.HashSet<String>();
        if (v != null) for (String t : v.split(",")) { String tt = t.trim(); if (!tt.isEmpty()) out.add(tt); }
        return out;
    }
    private static char sniffDelimiter(java.io.File f) {
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(f), StandardCharsets.UTF_8));
            try {
                r.mark(4); if (r.read() != 0xFEFF) r.reset();
                String h = r.readLine();
                if (h == null) return ';';
                int sc = 0, cc = 0; for (int i = 0; i < h.length(); i++) { char c = h.charAt(i); if (c == ';') sc++; else if (c == ',') cc++; }
                return (cc > sc) ? ',' : ';';
            } finally { r.close(); }
        } catch (Exception e) { return ';'; }
    }
    private static final java.util.regex.Pattern DATE_SLASH = java.util.regex.Pattern.compile("^\\d{4}/(0[1-9]|1[0-2])/(0[1-9]|[12]\\d|3[01])$");
    private static final java.util.regex.Pattern DATE_DASH = java.util.regex.Pattern.compile("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$");
    private static final java.util.regex.Pattern DATE_COMPACT = java.util.regex.Pattern.compile("^\\d{4}(0[1-9]|1[0-2])(0[1-9]|[12]\\d|3[01])$");
    private static boolean looksLikeDate(String v, int minYear, int maxYear) {
        if (!(DATE_SLASH.matcher(v).matches() || DATE_DASH.matcher(v).matches() || DATE_COMPACT.matcher(v).matches())) return false;
        try { int y = Integer.parseInt(v.substring(0, 4)); return y >= minYear && y <= maxYear; } catch (Exception e) { return false; }
    }

    // -------------------------------------------------------------- encoding
    /**
     * Normalises a text file's character encoding to UTF-8.
     *  - If the file is already valid UTF-8 (optionally with BOM), only the BOM is adjusted.
     *  - Otherwise it is decoded from the declared source charset (param "from", default
     *    windows-1252) — with an optional best-effort guess — and re-encoded as UTF-8.
     *  - The BOM in the output is controlled by param "bom" (default false = UTF-8 without BOM).
     *
     * IMPORTANT (honest limitation): detecting the charset of a non-UTF-8 file is heuristic
     * and never 100% reliable (e.g. ISO-8859-1 vs Windows-1252 are practically
     * indistinguishable from bytes alone). Declare "from" when you know it.
     *
     * Params: from (source charset if not UTF-8, default windows-1252), bom (true/false,
     * default false), outFile (default: overwrite input). source = input file.
     */
    private void runEncoding(StepDef step, Map<String, String> params, Map<String, String> vars,
                             StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        String inPath = VarResolver.resolve(step.source, vars);
        java.io.File in = new java.io.File(inPath);
        if (!in.isFile()) { res.exitCode = 2; line.accept("encoding: input file not found: " + inPath); return; }

        boolean outBom = "true".equalsIgnoreCase(params.get("bom"));
        String fromName = blankToNull(params.get("from"));
        String outParam = blankToNull(VarResolver.resolve(params.get("outFile"), vars));
        java.io.File out = outParam != null ? new java.io.File(outParam) : in;
        boolean inPlace = out.getAbsolutePath().equals(in.getAbsolutePath());

        byte[] bytes = java.nio.file.Files.readAllBytes(in.toPath());
        // detect/strip an existing BOM
        boolean hadBom = bytes.length >= 3 && (bytes[0] & 0xFF) == 0xEF && (bytes[1] & 0xFF) == 0xBB && (bytes[2] & 0xFF) == 0xBF;
        int off = hadBom ? 3 : 0;
        boolean hadUtf16 = bytes.length >= 2 &&
                (((bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xFE) || ((bytes[0] & 0xFF) == 0xFE && (bytes[1] & 0xFF) == 0xFF));

        String text;
        String detectedFrom;
        if (hadUtf16) {
            // UTF-16 with BOM: decode via the BOM-aware charset
            boolean le = (bytes[0] & 0xFF) == 0xFF;
            text = new String(bytes, 2, bytes.length - 2, le ? StandardCharsets.UTF_16LE : StandardCharsets.UTF_16BE);
            detectedFrom = le ? "UTF-16LE (BOM)" : "UTF-16BE (BOM)";
        } else if (isValidUtf8(bytes, off, bytes.length - off)) {
            text = new String(bytes, off, bytes.length - off, StandardCharsets.UTF_8);
            detectedFrom = "UTF-8" + (hadBom ? " (BOM)" : "");
        } else {
            // not UTF-8: use the declared source charset, else a best-effort guess, else windows-1252
            String srcName = fromName != null ? fromName : guessLegacyCharset(bytes);
            java.nio.charset.Charset src;
            try { src = java.nio.charset.Charset.forName(srcName); }
            catch (Exception e) { src = java.nio.charset.Charset.forName("windows-1252"); srcName = "windows-1252"; }
            text = new String(bytes, off, bytes.length - off, src);
            detectedFrom = srcName + (fromName == null ? " (assumed)" : " (declared)");
        }

        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream(text.length() + 8);
        if (outBom) bos.write(0xEF); if (outBom) bos.write(0xBB); if (outBom) bos.write(0xBF);
        byte[] body = text.getBytes(StandardCharsets.UTF_8);
        bos.write(body, 0, body.length);
        byte[] result = bos.toByteArray();

        if (inPlace) {
            java.io.File tmp = new java.io.File(out.getParentFile(), out.getName() + ".tmp");
            java.nio.file.Files.write(tmp.toPath(), result);
            java.nio.file.Files.move(tmp.toPath(), out.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } else {
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            java.nio.file.Files.write(out.toPath(), result);
        }

        line.accept("encoding: source=" + detectedFrom + " -> UTF-8" + (outBom ? " with BOM" : " without BOM")
                + (hadBom && !outBom ? " (BOM removed)" : "") + (!hadBom && outBom ? " (BOM added)" : ""));
        line.accept("encoding: wrote " + result.length + " bytes to " + out.getAbsolutePath());
        res.outVars.put("outputFile", out.getAbsolutePath());
        res.outVars.put("sourceEncoding", detectedFrom);
        line.accept("##VAR outputFile=" + out.getAbsolutePath());
        line.accept("##VAR sourceEncoding=" + detectedFrom);
        res.exitCode = 0;
    }

    /** Strict UTF-8 validity check over bytes[off..end). */
    private static boolean isValidUtf8(byte[] b, int off, int len) {
        int i = off, end = off + len;
        while (i < end) {
            int c = b[i] & 0xFF;
            if (c < 0x80) { i++; continue; }
            int n;            // number of continuation bytes
            if ((c & 0xE0) == 0xC0) { n = 1; if (c < 0xC2) return false; }      // reject overlong
            else if ((c & 0xF0) == 0xE0) { n = 2; }
            else if ((c & 0xF8) == 0xF0) { n = 3; if (c > 0xF4) return false; } // > U+10FFFF
            else return false;
            if (i + n >= end) return false;
            for (int k = 1; k <= n; k++) if ((b[i + k] & 0xC0) != 0x80) return false;
            i += n + 1;
        }
        return true;
    }

    /** Very small heuristic for the legacy single-byte charset; defaults to windows-1252. */
    private static String guessLegacyCharset(byte[] b) {
        // windows-1252 defines almost all 0x80-0x9F; ISO-8859-1 leaves them as controls.
        // If we see bytes in 0x80-0x9F (other than none), 1252 is the safer default for Windows feeds.
        return "windows-1252";
    }

    private void runReplace(StepDef step, Map<String, String> params, Map<String, String> vars,
                            StepExecutor.Result res, java.util.function.Consumer<String> line) throws Exception {
        String inPath = VarResolver.resolve(step.source, vars);
        char delim = (step.delimiter != null && !step.delimiter.isEmpty()) ? step.delimiter.charAt(0) : ';';
        boolean hasHeader = !"false".equalsIgnoreCase(params.get("hasHeader"));
        String outParam = blankToNull(VarResolver.resolve(params.get("outFile"), vars));

        java.io.File in = new java.io.File(inPath);
        if (!in.isFile()) { line.accept("csvreplace: input not found: " + inPath); res.exitCode = 2; return; }
        if (step.replacements == null || step.replacements.isEmpty()) { line.accept("csvreplace: no replacements configured"); res.exitCode = 0; res.outVars.put("outputFile", in.getAbsolutePath()); return; }

        // output: a new file (or overwrite). Default = <name>_replaced.<ext> next to the input.
        java.io.File out = outParam != null ? new java.io.File(outParam)
                : new java.io.File(in.getParentFile(), stripExt(in.getName()) + "_replaced" + ext(in.getName()));
        boolean inPlace = out.getAbsolutePath().equals(in.getAbsolutePath());
        java.io.File target = inPlace ? new java.io.File(in.getParentFile(), in.getName() + ".tmp") : out;
        if (target.getParentFile() != null) target.getParentFile().mkdirs();

        line.accept("csvreplace " + in.getAbsolutePath() + " -> " + out.getAbsolutePath() + "  (" + step.replacements.size() + " rule(s))");

        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(in), StandardCharsets.UTF_8), 1 << 16);
        java.io.Writer w = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(target), StandardCharsets.UTF_8), 1 << 16);
        long rows = 0, hits = 0;
        long[] perRule = new long[step.replacements.size()];
        try {
            r.mark(2); int first = r.read(); boolean hadBom = first == 0xFEFF; if (!hadBom) r.reset();
            if (hadBom) w.write('\uFEFF');

            String[] headerCols = null;
            String header = hasHeader ? r.readLine() : null;
            if (header != null) { headerCols = splitSimple(header, delim).toArray(new String[0]); w.write(header); w.write("\r\n"); }

            // resolve target column indices per rule (empty = all fields => null)
            java.util.List<int[]> ruleCols = new ArrayList<int[]>();
            for (Replacement rp : step.replacements) {
                if (rp.columns == null || rp.columns.isEmpty()) { ruleCols.add(null); continue; }
                java.util.List<Integer> idxs = new ArrayList<Integer>();
                for (String cn : rp.columns) {
                    int found = -1;
                    if (headerCols != null) for (int i = 0; i < headerCols.length; i++) if (headerCols[i].trim().equals(cn.trim())) { found = i; break; }
                    if (found >= 0) idxs.add(found);
                    else line.accept("  warning: column '" + cn + "' not found in header (rule skipped for it)");
                }
                int[] arr = new int[idxs.size()]; for (int i = 0; i < arr.length; i++) arr[i] = idxs.get(i);
                ruleCols.add(arr);
            }

            String ln;
            StringBuilder sb = new StringBuilder();
            while ((ln = r.readLine()) != null) {
                rows++;
                java.util.List<String> f = splitSimple(ln, delim);
                for (int ri = 0; ri < step.replacements.size(); ri++) {
                    Replacement rp = step.replacements.get(ri);
                    if (rp.from == null || rp.from.isEmpty()) continue;
                    int[] cols = ruleCols.get(ri);
                    if (cols == null) {
                        for (int ci = 0; ci < f.size(); ci++) {
                            String v = f.get(ci);
                            if (v.indexOf(rp.from) >= 0) { f.set(ci, v.replace(rp.from, rp.to == null ? "" : rp.to)); hits++; perRule[ri]++; }
                        }
                    } else {
                        for (int ci : cols) {
                            if (ci >= f.size()) continue;
                            String v = f.get(ci);
                            if (v.indexOf(rp.from) >= 0) { f.set(ci, v.replace(rp.from, rp.to == null ? "" : rp.to)); hits++; perRule[ri]++; }
                        }
                    }
                }
                sb.setLength(0);
                for (int ci = 0; ci < f.size(); ci++) { if (ci > 0) sb.append(delim); sb.append(f.get(ci)); }
                w.write(sb.toString()); w.write("\r\n");
            }
        } finally {
            try { r.close(); } catch (Exception ignored) {}
            try { w.flush(); w.close(); } catch (Exception ignored) {}
        }

        if (inPlace) {
            java.nio.file.Files.move(target.toPath(), in.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            out = in;
        }
        for (int ri = 0; ri < perRule.length; ri++) {
            Replacement rp = step.replacements.get(ri);
            line.accept("  rule '" + rp.from + "' -> '" + (rp.to == null ? "" : rp.to) + "'" +
                    (rp.columns == null || rp.columns.isEmpty() ? " [all]" : " " + rp.columns) + ": " + perRule[ri] + " replacement(s)");
        }
        res.outVars.put("outputFile", out.getAbsolutePath());
        res.outVars.put("rowCount", String.valueOf(rows));
        res.outVars.put("replacements", String.valueOf(hits));
        line.accept("##VAR outputFile=" + out.getAbsolutePath());
        line.accept("##VAR rowCount=" + rows);
        line.accept("##VAR replacements=" + hits);
        line.accept("csvreplace finished: " + hits + " replacement(s) over " + rows + " row(s)");
        res.exitCode = 0;
    }

    private static String ext(String name) { int d = name.lastIndexOf('.'); return d > 0 ? name.substring(d) : ".csv"; }

    // -------------------------------------------------------------- validate
    private final com.fasterxml.jackson.databind.ObjectMapper jsonMapper = new com.fasterxml.jackson.databind.ObjectMapper();

    private static String checkLabel(String id) {
        if ("rowCount".equals(id)) return "Row count matches expected";
        if ("colCount".equals(id)) return "Column count consistent (dataschema)";
        if ("jsonSchema".equals(id)) return "Schema JSON well-formed";
        if ("noQuotes".equals(id)) return "No double quotes inside fields";
        if ("colNames".equals(id)) return "Column names match dataschema";
        if ("notNull".equals(id)) return "Non-nullable fields are valued";
        if ("businessDate".equals(id)) return "Business date valued and well-formatted";
        if ("displayDates".equals(id)) return "Display-schema date columns well-formatted";
        return id;
    }

    @SuppressWarnings("unchecked")
    private void runValidate(StepDef step, Map<String, String> params, Map<String, String> vars,
                             StepExecutor.Result res, java.util.function.Consumer<String> line,
                             com.legalarchive.orchestrator.model.run.StepExec se, Runnable onProgress) throws Exception {
        java.util.List<String> selected = (step.validateChecks == null || step.validateChecks.isEmpty())
                ? java.util.Arrays.asList("rowCount", "colCount", "jsonSchema", "noQuotes", "colNames", "notNull", "businessDate", "displayDates")
                : step.validateChecks;

        // seed checklist (PENDING) so the UI shows the sub-steps immediately
        final java.util.List<com.legalarchive.orchestrator.model.run.CheckResult> checks = new ArrayList<com.legalarchive.orchestrator.model.run.CheckResult>();
        for (String id : selected) checks.add(new com.legalarchive.orchestrator.model.run.CheckResult(id, checkLabel(id)));
        if (se != null) { se.checks = checks; if (onProgress != null) onProgress.run(); }

        final java.util.Map<String, com.legalarchive.orchestrator.model.run.CheckResult> byId =
                new java.util.HashMap<String, com.legalarchive.orchestrator.model.run.CheckResult>();
        for (com.legalarchive.orchestrator.model.run.CheckResult c : checks) byId.put(c.id, c);

        // inputs
        String csvPath = VarResolver.resolve(step.source, vars);
        char delim = (step.delimiter != null && !step.delimiter.isEmpty()) ? step.delimiter.charAt(0) : ';';
        boolean hasHeader = !"false".equalsIgnoreCase(params.get("hasHeader"));
        String dataschemaPath = blankToNull(params.get("dataschema"));
        String displayschemaPath = blankToNull(params.get("displayschema"));
        String bizCol = blankToNull(params.get("businessDateColumn"));
        String dateFormat = blankToNull(params.get("dateFormat"));
        Long expected = null;
        try { if (params.get("expectedRows") != null) expected = Long.parseLong(params.get("expectedRows").trim()); } catch (Exception ignore) {}

        line.accept("validate " + csvPath + "  (delimiter '" + delim + "', header=" + hasHeader + ")");

        java.util.function.BiConsumer<String, String[]> set = new java.util.function.BiConsumer<String, String[]>() {
            public void accept(String id, String[] sd) {
                com.legalarchive.orchestrator.model.run.CheckResult c = byId.get(id);
                if (c == null) return;
                c.status = sd[0]; c.detail = sd[1];
                line.accept("[check] " + id + " -> " + sd[0] + (sd[1] != null ? ("  " + sd[1]) : ""));
                if (onProgress != null) onProgress.run();
            }
        };
        boolean sel_rowCount = byId.containsKey("rowCount");
        boolean sel_colCount = byId.containsKey("colCount");
        boolean sel_json = byId.containsKey("jsonSchema");
        boolean sel_noQuotes = byId.containsKey("noQuotes");
        boolean sel_colNames = byId.containsKey("colNames");
        boolean sel_notNull = byId.containsKey("notNull");
        boolean sel_biz = byId.containsKey("businessDate");
        boolean sel_disp = byId.containsKey("displayDates");

        // --- parse schemas (also serves the jsonSchema well-formed check) ---
        java.util.List<Map<String, Object>> dataschema = null;
        java.util.List<Map<String, Object>> displayschema = null;
        String jsonErr = null;
        if (dataschemaPath != null) {
            try { dataschema = (java.util.List<Map<String, Object>>) (java.util.List<?>) jsonMapper.readValue(new java.io.File(dataschemaPath), java.util.List.class); }
            catch (Exception e) { jsonErr = "dataschema: " + e.getMessage(); }
        }
        if (displayschemaPath != null) {
            try { displayschema = (java.util.List<Map<String, Object>>) (java.util.List<?>) jsonMapper.readValue(new java.io.File(displayschemaPath), java.util.List.class); }
            catch (Exception e) { jsonErr = (jsonErr == null ? "" : jsonErr + "; ") + "displayschema: " + e.getMessage(); }
        }
        if (sel_json) {
            if (dataschemaPath == null && displayschemaPath == null) set.accept("jsonSchema", new String[]{"SKIP", "no schema provided"});
            else if (jsonErr != null) set.accept("jsonSchema", new String[]{"FAIL", jsonErr});
            else set.accept("jsonSchema", new String[]{"PASS", "schema(s) parsed"});
        }

        // dataschema-derived metadata
        java.util.List<String> schemaNames = new ArrayList<String>();
        java.util.List<Boolean> schemaNotNull = new ArrayList<Boolean>();
        if (dataschema != null) for (Map<String, Object> c : dataschema) {
            schemaNames.add(String.valueOf(c.get("name")));
            Object nu = c.get("nullable");
            schemaNotNull.add(Boolean.FALSE.equals(nu) || "false".equalsIgnoreCase(String.valueOf(nu)));
        }

        // open file
        java.io.File csv = new java.io.File(csvPath);
        if (!csv.isFile()) {
            String[] miss = new String[]{"FAIL", "CSV file not found: " + csvPath};
            for (String id : selected) if (!"jsonSchema".equals(id)) set.accept(id, miss);
            res.exitCode = 2;
            return;
        }

        // violation report: one CSV row per violation (CHECK;LINE;COLUMN;DETAIL), streamed with a cap
        final java.io.File reportFile = new java.io.File(csv.getParentFile(),
                stripExt(csv.getName()) + "_validation_report.csv");
        try { java.nio.file.Files.deleteIfExists(reportFile.toPath()); } catch (Exception ignored) {}
        class Reporter {
            static final long CAP = 100000;
            java.io.Writer w; long rows = 0; boolean trunc = false;
            void add(String check, long ln, String col, String det) {
                if (trunc) return;
                try {
                    if (rows >= CAP) { trunc = true; return; }
                    if (w == null) {
                        w = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                                new java.io.FileOutputStream(reportFile), StandardCharsets.UTF_8), 1 << 16);
                        w.write('\uFEFF');
                        w.write("CHECK;LINE;COLUMN;DETAIL\r\n");
                    }
                    w.write(check + ";" + ln + ";" + repField(col) + ";" + repField(det) + "\r\n");
                    rows++;
                } catch (Exception ignored) {}
            }
            void close() { if (w != null) try { w.flush(); w.close(); } catch (Exception ignored) {} }
        }
        final Reporter rep = new Reporter();

        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(csv), StandardCharsets.UTF_8), 1 << 16);
        try {
            r.mark(4); if (r.read() != 0xFEFF) r.reset();
            String header = hasHeader ? r.readLine() : null;
            java.util.List<String> headerCols = header != null ? parseCsv(header, delim) : null;

            // colNames check (header vs dataschema)
            if (sel_colNames) {
                if (dataschema == null) set.accept("colNames", new String[]{"SKIP", "dataschema not provided"});
                else if (!hasHeader || headerCols == null) set.accept("colNames", new String[]{"SKIP", "file has no header"});
                else {
                    java.util.List<String> diff = new ArrayList<String>();
                    int n = Math.max(headerCols.size(), schemaNames.size());
                    for (int i = 0; i < n; i++) {
                        String h = i < headerCols.size() ? headerCols.get(i).trim() : "(missing)";
                        String sName = i < schemaNames.size() ? schemaNames.get(i) : "(missing)";
                        if (!h.equals(sName)) diff.add("col " + (i + 1) + ": '" + h + "' != '" + sName + "'");
                    }
                    if (diff.isEmpty()) set.accept("colNames", new String[]{"PASS", schemaNames.size() + " columns match"});
                    else set.accept("colNames", new String[]{"FAIL", join(diff, 5)});
                }
            }

            // column index map for value checks
            java.util.Map<String, Integer> idx = new java.util.HashMap<String, Integer>();
            java.util.List<String> idxNames = (headerCols != null) ? headerCols : schemaNames;
            for (int i = 0; i < idxNames.size(); i++) idx.put(idxNames.get(i).trim(), i);

            int expectedCols = dataschema != null ? schemaNames.size() : -1;   // colCount is defined vs dataschema; SKIP without it

            // non-nullable column indices
            java.util.List<Integer> nnIdx = new ArrayList<Integer>();
            if (sel_notNull && dataschema != null) for (int i = 0; i < schemaNames.size(); i++) if (schemaNotNull.get(i)) {
                Integer ci = idx.get(schemaNames.get(i)); if (ci != null) nnIdx.add(ci);
            }
            // business date col index + regex
            Integer bizIdx = (sel_biz && bizCol != null) ? idx.get(bizCol) : null;
            java.util.regex.Pattern datePat = dateFormat != null ? java.util.regex.Pattern.compile(fmtToRegex(dateFormat)) : null;
            // display-schema date columns
            java.util.List<Integer> dateIdx = new ArrayList<Integer>();
            java.util.List<String> dateColNames = new ArrayList<String>();
            if (sel_disp && displayschema != null) for (Map<String, Object> c : displayschema) {
                if ("date".equalsIgnoreCase(String.valueOf(c.get("DataType")))) {
                    String cn = String.valueOf(c.get("ColumnName"));
                    Integer ci = idx.get(cn);
                    if (ci != null) { dateIdx.add(ci); dateColNames.add(cn); }
                }
            }

            // single streaming pass
            long rows = 0, colViol = 0, quoteViol = 0, bizViol = 0;
            java.util.List<String> colViolLines = new ArrayList<String>();
            java.util.List<String> quoteViolLines = new ArrayList<String>();
            java.util.List<String> bizViolLines = new ArrayList<String>();
            long[] nnViol = new long[nnIdx.size()];
            long[] dateViol = new long[dateIdx.size()];
            String line2;
            long lineNo = hasHeader ? 1 : 0;
            while ((line2 = r.readLine()) != null) {
                lineNo++; rows++;
                java.util.List<String> f = parseCsv(line2, delim);
                if (sel_noQuotes) {
                    String firstCol = null;
                    for (int ci = 0; ci < f.size(); ci++) {
                        if (f.get(ci).indexOf('"') >= 0) {     // a quote left AFTER RFC parsing = embedded quote inside the field
                            String cn = ci < idxNames.size() ? idxNames.get(ci).trim() : ("col" + (ci + 1));
                            if (firstCol == null) firstCol = cn;
                            rep.add("noQuotes", lineNo, cn, snippet60(f.get(ci)));
                        }
                    }
                    if (firstCol != null) {
                        quoteViol++;
                        if (quoteViolLines.size() < 5) quoteViolLines.add("line " + lineNo + " [" + firstCol + "]");
                    }
                }
                if (sel_colCount && expectedCols >= 0 && f.size() != expectedCols) {
                    colViol++;
                    rep.add("colCount", lineNo, "", "found " + f.size() + ", expected " + expectedCols);
                    if (colViolLines.size() < 5) colViolLines.add("line " + lineNo + " has " + f.size());
                }
                if (sel_notNull) for (int k = 0; k < nnIdx.size(); k++) {
                    int ci = nnIdx.get(k);
                    if (ci >= f.size() || f.get(ci).trim().isEmpty()) {
                        nnViol[k]++;
                        rep.add("notNull", lineNo, ci < idxNames.size() ? idxNames.get(ci).trim() : ("col" + (ci + 1)), "empty");
                    }
                }
                if (bizIdx != null) {
                    String v = bizIdx < f.size() ? f.get(bizIdx).trim() : "";
                    boolean bad = v.isEmpty() || (datePat != null && !datePat.matcher(v).matches());
                    if (bad) {
                        bizViol++;
                        rep.add("businessDate", lineNo, bizCol, v.isEmpty() ? "empty" : ("malformed: " + snippet60(v)));
                        if (bizViolLines.size() < 5) bizViolLines.add("line " + lineNo + " ='" + v + "'");
                    }
                }
                if (!dateIdx.isEmpty() && datePat != null) for (int k = 0; k < dateIdx.size(); k++) {
                    int ci = dateIdx.get(k); String v = ci < f.size() ? f.get(ci).trim() : "";
                    if (!v.isEmpty() && !datePat.matcher(v).matches()) {
                        dateViol[k]++;
                        rep.add("displayDates", lineNo, dateColNames.get(k), "malformed: " + snippet60(v));
                    }
                }
            }

            rep.close();
            String repNote = rep.rows > 0
                    ? (" — full report: " + reportFile.getName() + (rep.trunc ? " (truncated at " + Reporter.CAP + " rows)" : ""))
                    : "";
            if (rep.rows > 0) {
                line.accept("violation report (" + rep.rows + " row(s)" + (rep.trunc ? ", truncated" : "") + "): " + reportFile.getAbsolutePath());
                res.outVars.put("validationReport", reportFile.getAbsolutePath());
            }

            if (sel_rowCount) {
                if (expected == null) set.accept("rowCount", new String[]{"SKIP", "expectedRows not provided (actual " + rows + ")"});
                else if (rows == expected) set.accept("rowCount", new String[]{"PASS", rows + " data rows"});
                else set.accept("rowCount", new String[]{"FAIL", "expected " + expected + ", found " + rows});
            }
            if (sel_colCount) {
                if (expectedCols < 0) set.accept("colCount", new String[]{"SKIP", "dataschema not provided"});
                else if (colViol == 0) set.accept("colCount", new String[]{"PASS", "all rows have " + expectedCols + " columns"});
                else set.accept("colCount", new String[]{"FAIL", colViol + " row(s) with wrong column count (" + join(colViolLines, 5) + ")" + repNote});
            }
            if (sel_noQuotes) {
                if (quoteViol == 0) set.accept("noQuotes", new String[]{"PASS", "no embedded double quotes inside fields"});
                else set.accept("noQuotes", new String[]{"FAIL", quoteViol + " row(s) have a double quote inside a field (" + join(quoteViolLines, 5) + ")" + repNote});
            }
            if (sel_notNull) {
                if (dataschema == null) set.accept("notNull", new String[]{"SKIP", "dataschema not provided"});
                else {
                    java.util.List<String> bad = new ArrayList<String>();
                    for (int k = 0; k < nnIdx.size(); k++) if (nnViol[k] > 0) bad.add(idxNames.get(nnIdx.get(k)) + ": " + nnViol[k] + " empty");
                    if (bad.isEmpty()) set.accept("notNull", new String[]{"PASS", nnIdx.size() + " non-nullable column(s) ok"});
                    else set.accept("notNull", new String[]{"FAIL", join(bad, 6) + repNote});
                }
            }
            if (sel_biz) {
                if (bizCol == null) set.accept("businessDate", new String[]{"SKIP", "businessDateColumn not provided"});
                else if (bizIdx == null) set.accept("businessDate", new String[]{"FAIL", "column '" + bizCol + "' not found"});
                else if (bizViol == 0) set.accept("businessDate", new String[]{"PASS", "all rows valued" + (dateFormat != null ? (" and matching " + dateFormat) : "")});
                else set.accept("businessDate", new String[]{"FAIL", bizViol + " row(s) empty or malformed (" + join(bizViolLines, 5) + ")" + repNote});
            }
            if (sel_disp) {
                if (displayschema == null) set.accept("displayDates", new String[]{"SKIP", "displayschema not provided"});
                else if (dateFormat == null) set.accept("displayDates", new String[]{"SKIP", "dateFormat not provided"});
                else if (dateIdx.isEmpty()) set.accept("displayDates", new String[]{"PASS", "no date columns in displayschema"});
                else {
                    java.util.List<String> bad = new ArrayList<String>();
                    for (int k = 0; k < dateIdx.size(); k++) if (dateViol[k] > 0) bad.add(dateColNames.get(k) + ": " + dateViol[k] + " malformed");
                    if (bad.isEmpty()) set.accept("displayDates", new String[]{"PASS", dateIdx.size() + " date column(s) ok"});
                    else set.accept("displayDates", new String[]{"FAIL", join(bad, 6) + repNote});
                }
            }

            int failed = 0, passed = 0;
            for (com.legalarchive.orchestrator.model.run.CheckResult c : checks) {
                if ("FAIL".equals(c.status)) failed++; else if ("PASS".equals(c.status)) passed++;
            }
            res.outVars.put("checksTotal", String.valueOf(checks.size()));
            res.outVars.put("checksPassed", String.valueOf(passed));
            res.outVars.put("checksFailed", String.valueOf(failed));
            for (Map.Entry<String, String> e : res.outVars.entrySet()) line.accept("##VAR " + e.getKey() + "=" + e.getValue());
            res.exitCode = failed > 0 ? 1 : 0;
            line.accept("validation finished: " + passed + " passed, " + failed + " failed" + (failed > 0 ? " — STEP FAILED" : ""));
        } finally {
            r.close();
        }
    }

    private static String blankToNull(String s) { return (s == null || s.trim().isEmpty()) ? null : s.trim(); }
    private static String stripExt(String name) { int d = name.lastIndexOf('.'); return d > 0 ? name.substring(0, d) : name; }
    private static String snippet60(String v) { v = v == null ? "" : v; return v.length() > 60 ? (v.substring(0, 60) + "…") : v; }
    /** RFC-quote a field for the violation report (it may itself contain quotes/semicolons). */
    private static String repField(String v) {
        if (v == null) return "";
        if (v.indexOf(';') >= 0 || v.indexOf('"') >= 0) return '"' + v.replace("\"", "\"\"") + '"';
        return v;
    }
    private static String join(java.util.List<String> l, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size() && i < max; i++) { if (i > 0) sb.append("; "); sb.append(l.get(i)); }
        if (l.size() > max) sb.append("; …");
        return sb.toString();
    }
    /** RFC-style quote-aware split: wrapping double quotes are removed and "" -> " inside fields.
        So header names and values are compared without their surrounding quotes, and only
        EMBEDDED quotes survive in a field (used by the noQuotes check). */
    private static java.util.List<String> parseCsv(String line, char delim) {
        java.util.List<String> out = new ArrayList<String>();
        StringBuilder sb = new StringBuilder();
        boolean inQ = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (inQ) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') { sb.append('"'); i++; }
                    else inQ = false;
                } else sb.append(c);
            } else {
                if (c == '"') inQ = true;
                else if (c == delim) { out.add(sb.toString()); sb.setLength(0); }
                else sb.append(c);
            }
        }
        out.add(sb.toString());
        return out;
    }

    /** naive split by delimiter. */
    private static java.util.List<String> splitSimple(String line, char delim) {
        java.util.List<String> out = new ArrayList<String>();
        int start = 0;
        for (int i = 0; i < line.length(); i++) if (line.charAt(i) == delim) { out.add(line.substring(start, i)); start = i + 1; }
        out.add(line.substring(start));
        return out;
    }
    /** Convert a token date format (YYYY/MM/DD, YYYYMMDD, DD-MM-YYYY, HH:mm:ss…) to an anchored regex. */
    private static String fmtToRegex(String fmt) {
        StringBuilder sb = new StringBuilder("^");
        int i = 0;
        while (i < fmt.length()) {
            if (fmt.startsWith("YYYY", i)) { sb.append("\\d{4}"); i += 4; }
            else if (fmt.startsWith("YY", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("MM", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("DD", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("HH", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("mm", i)) { sb.append("\\d{2}"); i += 2; }
            else if (fmt.startsWith("ss", i)) { sb.append("\\d{2}"); i += 2; }
            else { char c = fmt.charAt(i); if ("\\.[]{}()*+-?^$|".indexOf(c) >= 0) sb.append('\\'); sb.append(c); i++; }
        }
        sb.append("$");
        return sb.toString();
    }

    private void safeLine(BufferedWriter log, String s) {
        if (log == null) return;
        try { log.write(LocalDateTime.now().format(TS) + "  " + s); log.newLine(); log.flush(); } catch (Exception ignored) {}
    }
}
