/*
 * viewer.js - online viewer for ASCII/CSV files served by OpenProteo.
 * Server mode (api+path) streams data so the browser never loads millions of rows.
 * No literal newline escapes in source (UBS proxy safe).
 */
(function (global) {
    'use strict';
    var LF = String.fromCharCode(10);
    var CR = 13;
    var COLW = 170;

    function el(tag, cls, parent) { var e = document.createElement(tag); if (cls) e.className = cls; if (parent) parent.appendChild(e); return e; }
    function text(n, s) { n.textContent = (s == null ? '' : String(s)); return n; }
    function fmt(n) { if (n < 1024) return n + ' B'; if (n < 1048576) return (n / 1024).toFixed(1) + ' KB'; return (n / 1048576).toFixed(1) + ' MB'; }
    function json(r) { return r.json(); }
    function showErr(host, msg) { var d = el('div', 'banner error', host); text(d, 'Cannot load: ' + (msg || 'error')); }

    function virtualList(scrollEl, rowHeight, getCount, renderRow) {
        scrollEl.innerHTML = ''; scrollEl.style.position = 'relative';
        var spacer = el('div', null, scrollEl); spacer.style.position = 'relative'; spacer.style.width = '1px';
        var pool = el('div', null, scrollEl); pool.style.position = 'absolute'; pool.style.left = '0'; pool.style.right = '0'; pool.style.top = '0';
        var ticking = false, onDraw = null;
        function draw() {
            ticking = false;
            var count = getCount();
            spacer.style.height = (count * rowHeight) + 'px';
            var st = scrollEl.scrollTop, h = scrollEl.clientHeight;
            var start = Math.max(0, Math.floor(st / rowHeight) - 6);
            var end = Math.min(count, Math.ceil((st + h) / rowHeight) + 6);
            pool.style.transform = 'translateY(' + (start * rowHeight) + 'px)';
            pool.innerHTML = '';
            for (var i = start; i < end; i++) { var r = renderRow(i); r.style.height = rowHeight + 'px'; pool.appendChild(r); }
            if (onDraw) onDraw(scrollEl.scrollLeft);
        }
        scrollEl.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(draw); } });
        return { redraw: draw, reset: function () { scrollEl.scrollTop = 0; draw(); }, onDraw: function (cb) { onDraw = cb; } };
    }

    function renderCsvServer(host, api, path, name, meta) {
        var PAGE = 200;
        var columns = [], totalRows = 0, curTotal = 0, q = '';
        var cache = {}, inflight = {};
        fetch(api + 'csv/meta?path=' + encodeURIComponent(path)).then(json).then(function (j) {
            if (!j.ok) { showErr(host, j.error); return; }
            columns = j.columns; totalRows = j.totalRows; curTotal = totalRows;
            meta.textContent = totalRows + ' rows · ' + columns.length + ' cols · delim "' + j.delimiter + '"';
            build();
        }).catch(function (e) { showErr(host, String(e)); });

        function build() {
            var top = el('div', 'vwr-tools', host);
            var filter = el('input', 'search-box', top); filter.placeholder = '🔎 Filter (all columns)…';
            var info = el('span', 'dim small', top); info.style.marginLeft = '10px';
            var tabs = el('div', 'vwr-tabs', host);
            var tT = el('button', 'vtab active', tabs); text(tT, 'Table');
            var tA = el('button', 'vtab', tabs); text(tA, 'Aggregate');
            var paneT = el('div', null, host);
            var paneA = el('div', null, host); paneA.style.display = 'none';
            tT.addEventListener('click', function () { tT.classList.add('active'); tA.classList.remove('active'); paneT.style.display = ''; paneA.style.display = 'none'; });
            tA.addEventListener('click', function () { tA.classList.add('active'); tT.classList.remove('active'); paneA.style.display = ''; paneT.style.display = 'none'; });

            var totalW = columns.length * COLW;
            var head = el('div', 'vgrid-head', paneT);
            var hr = el('div', 'vgrid-row', head); hr.style.width = totalW + 'px';
            for (var c = 0; c < columns.length; c++) { var hc = el('div', 'vgrid-cell head', hr); hc.style.width = COLW + 'px'; text(hc, columns[c]); }
            var body = el('div', 'vwr-body vgrid', paneT);

            var vl = virtualList(body, 26, function () { return curTotal; }, function (i) {
                var pg = Math.floor(i / PAGE);
                var rows = cache[pg];
                var rd = document.createElement('div'); rd.className = 'vgrid-row' + (i % 2 ? ' odd' : ''); rd.style.width = totalW + 'px';
                var row = rows ? rows[i - pg * PAGE] : null;
                for (var c2 = 0; c2 < columns.length; c2++) { var cell = document.createElement('div'); cell.className = 'vgrid-cell'; cell.style.width = COLW + 'px'; cell.textContent = row ? (row[c2] == null ? '' : row[c2]) : ''; rd.appendChild(cell); }
                if (!rows) ensure(pg);
                return rd;
            });
            vl.onDraw(function (left) { head.scrollLeft = left; });
            body.addEventListener('scroll', function () { head.scrollLeft = body.scrollLeft; });
            function ensure(pg) {
                if (cache[pg] || inflight[pg]) return; inflight[pg] = true;
                var url = api + 'csv/page?path=' + encodeURIComponent(path) + '&offset=' + (pg * PAGE) + '&limit=' + PAGE + (q ? ('&q=' + encodeURIComponent(q)) : '');
                fetch(url).then(json).then(function (j) { delete inflight[pg]; if (j.ok) { cache[pg] = j.rows; if (q) curTotal = j.total; vl.redraw(); } }).catch(function () { delete inflight[pg]; });
            }
            vl.redraw();
            var deb;
            filter.addEventListener('input', function () {
                clearTimeout(deb);
                deb = setTimeout(function () {
                    q = filter.value.trim(); cache = {}; inflight = {};
                    if (!q) { curTotal = totalRows; info.textContent = ''; vl.reset(); return; }
                    info.textContent = 'filtering…';
                    fetch(api + 'csv/page?path=' + encodeURIComponent(path) + '&offset=0&limit=' + PAGE + '&q=' + encodeURIComponent(q)).then(json).then(function (j) {
                        if (j.ok) { cache[0] = j.rows; curTotal = j.total; info.textContent = j.total + ' / ' + totalRows + ' rows'; vl.reset(); }
                    });
                }, 300);
            });
            buildAgg(paneA, api, path, name, columns, function () { return q; });
        }
    }

    function buildAgg(pane, api, path, name, columns, getQ) {
        var PIVOT_MAX = 30;
        var bar = el('div', 'vwr-tools agg', pane);
        text(el('div', 'dim small', bar), 'Group by (count of rows per combination):');
        var grpWrap = el('div', 'agg-cols', bar);
        text(el('div', 'dim small', bar), 'Distinct count of (no group selected = global distinct per column):');
        var dstWrap = el('div', 'agg-cols', bar);
        var pvRow = el('div', null, bar);
        text(el('span', 'dim small', pvRow), 'Pivot by (optional, counts only): ');
        var pivotSel = el('select', null, pvRow);
        var o0 = el('option', null, pivotSel); o0.value = ''; text(o0, '— none —');
        columns.forEach(function (cn, ci) { var o = el('option', null, pivotSel); o.value = String(ci); text(o, cn); });

        var grp = [], dst = [];
        columns.forEach(function (cn, ci) {
            var l1 = el('label', 'agg-chip', grpWrap); var b1 = el('input', null, l1); b1.type = 'checkbox'; b1.value = ci; text(el('span', null, l1), cn); grp.push(b1);
            var l2 = el('label', 'agg-chip', dstWrap); var b2 = el('input', null, l2); b2.type = 'checkbox'; b2.value = ci; text(el('span', null, l2), cn); dst.push(b2);
        });
        var go = el('button', 'btn sm primary', bar); text(go, 'Compute'); go.style.marginTop = '6px';
        var dl = el('button', 'btn sm', bar); text(dl, '⬇ Export'); dl.style.marginLeft = '6px'; dl.style.marginTop = '6px'; dl.disabled = true;
        var summary = el('div', 'dim small', pane); summary.style.margin = '6px 0';
        var head = el('div', 'vgrid-head', pane);
        var body = el('div', 'vwr-body vgrid', pane);
        var exportRows = null;   // array of arrays (header + TOTAL + data) for CSV export

        go.addEventListener('click', function () {
            var g = [], dd = [];
            grp.forEach(function (b) { if (b.checked) g.push(b.value); });
            dst.forEach(function (b) { if (b.checked) dd.push(b.value); });
            var pv = pivotSel.value;
            if (pv !== '') {
                g = g.filter(function (x) { return String(x) !== pv; });
                dd = [];   // pivot mode shows counts only
            }
            if (!g.length && !dd.length && pv === '') { summary.textContent = 'Select at least one Group-by or Distinct column.'; return; }
            summary.textContent = 'Computing on the server…';
            var reqGroup = pv !== '' ? g.concat([pv]) : g;
            var url = api + 'csv/aggregate?path=' + encodeURIComponent(path) +
                (reqGroup.length ? ('&group=' + reqGroup.join(',')) : '') +
                (dd.length ? ('&distinct=' + dd.join(',')) : '') +
                (getQ() ? ('&q=' + encodeURIComponent(getQ())) : '');
            fetch(url).then(json).then(function (j) {
                if (!j.ok) { summary.textContent = 'ERROR: ' + (j.error || 'failed'); return; }
                summary.textContent = j.distinctGroups + ' distinct group(s) over ' + j.scanned + ' rows' +
                    (j.truncated ? ' (groups truncated)' : '') + (j.truncatedDistinct ? ' (distinct counts are lower bounds: cap reached)' : '');
                dl.disabled = false;
                if (pv !== '') renderPivot(j); else renderFlat(j);
            }).catch(function (e) { summary.textContent = 'Error: ' + e; });
        });

        function gridRow(parent, w, odd) {
            var rd = document.createElement('div');
            rd.className = 'vgrid-row' + (odd ? ' odd' : '');
            rd.style.width = w + 'px';
            if (parent) parent.appendChild(rd);
            return rd;
        }
        function cellEl(parent, w, cls, content) {
            var c = el('div', 'vgrid-cell' + (cls ? (' ' + cls) : ''), parent);
            c.style.width = w + 'px';
            c.textContent = content == null ? '' : content;
            return c;
        }
        function syncScroll(vl) {
            vl.onDraw(function (left) { head.scrollLeft = left; });
            body.addEventListener('scroll', function () { head.scrollLeft = body.scrollLeft; });
            vl.reset();
        }

        // ---- flat (group-by / distinct-only) rendering with a pinned TOTAL row ----
        function renderFlat(j) {
            var gc = j.groupColumns, dc = j.distinctColumns;
            var totalW = gc.length * COLW + 110 + dc.length * 130;
            head.innerHTML = '';
            var hr = gridRow(head, totalW, false);
            gc.forEach(function (cn) { cellEl(hr, COLW, 'head', cn); });
            cellEl(hr, 110, 'head num', 'COUNT');
            dc.forEach(function (cn) { cellEl(hr, 130, 'head num', 'DISTINCT ' + cn); });

            // totals pinned under the headers
            var tr = gridRow(head, totalW, false);
            tr.className = 'vgrid-row totals';
            gc.forEach(function (cn, i) { cellEl(tr, COLW, null, i === 0 ? 'TOTAL' : ''); });
            if (!gc.length) { /* distinct-only: the single data row IS the total */ }
            cellEl(tr, 110, 'num', j.totalCount);
            dc.forEach(function (cn, k) { cellEl(tr, 130, 'num', j.totalDistinct ? j.totalDistinct[k] : ''); });

            var groups = gc.length ? j.groups : [];   // distinct-only: totals row says it all
            var vl = virtualList(body, 26, function () { return groups.length; }, function (i) {
                var g = groups[i];
                var rd = gridRow(null, totalW, i % 2 === 1);
                for (var k = 0; k < gc.length; k++) cellEl(rd, COLW, null, g.vals[k]);
                cellEl(rd, 110, 'num', g.count);
                if (g.distinct) for (var d2 = 0; d2 < g.distinct.length; d2++) cellEl(rd, 130, 'num dim', g.distinct[d2]);
                return rd;
            });
            syncScroll(vl);

            exportRows = [];
            var hdr = gc.slice(); hdr.push('COUNT');
            dc.forEach(function (c) { hdr.push('DISTINCT_' + c); });
            exportRows.push(hdr);
            var trow = []; gc.forEach(function (c, i) { trow.push(i === 0 ? 'TOTAL' : ''); });
            trow.push(j.totalCount);
            dc.forEach(function (c, k) { trow.push(j.totalDistinct ? j.totalDistinct[k] : ''); });
            exportRows.push(trow);
            j.groups.forEach(function (g) {
                var row = []; for (var k = 0; k < gc.length; k++) row.push(g.vals[k]);
                row.push(g.count);
                if (g.distinct) g.distinct.forEach(function (x) { row.push(x); });
                exportRows.push(row);
            });
        }

        // ---- pivot rendering: rows = group combo, columns = pivot values (top N + OTHER) ----
        function renderPivot(j) {
            var gc = j.groupColumns;
            var nG = gc.length - 1;                 // last group column is the pivot
            var pivotName = gc[nG];
            var SEPC = String.fromCharCode(1);

            var pvTotals = {}, pvOrder = [];
            j.groups.forEach(function (g) {
                var v = g.vals[nG];
                if (!(v in pvTotals)) { pvTotals[v] = 0; pvOrder.push(v); }
                pvTotals[v] += g.count;
            });
            pvOrder.sort(function (a, b) { return pvTotals[b] - pvTotals[a]; });
            var shown = pvOrder.slice(0, PIVOT_MAX);
            var hasOther = pvOrder.length > shown.length;
            var nCols = shown.length + (hasOther ? 1 : 0);
            var shownIdx = {};
            shown.forEach(function (v, i) { shownIdx[v] = i; });

            var rowMap = {}, rows = [];
            j.groups.forEach(function (g) {
                var key = nG ? g.vals.slice(0, nG).join(SEPC) : 'ALL';
                var r = rowMap[key];
                if (!r) {
                    r = { vals: nG ? g.vals.slice(0, nG) : ['ALL'], cells: [], total: 0 };
                    for (var k = 0; k < nCols; k++) r.cells.push(0);
                    rowMap[key] = r; rows.push(r);
                }
                var v = g.vals[nG];
                var ci = (v in shownIdx) ? shownIdx[v] : (hasOther ? shown.length : -1);
                if (ci >= 0) r.cells[ci] += g.count;
                r.total += g.count;
            });
            rows.sort(function (a, b) { return b.total - a.total; });
            var colTotals = []; for (var k = 0; k < nCols; k++) colTotals.push(0);
            var grand = 0;
            rows.forEach(function (r) { grand += r.total; for (var k = 0; k < nCols; k++) colTotals[k] += r.cells[k]; });

            var labelCols = nG ? gc.slice(0, nG) : ['ROWS'];
            var colNames = shown.slice(); if (hasOther) colNames.push('OTHER');
            var PVW = 110;
            var totalW = labelCols.length * COLW + 100 + nCols * PVW;

            head.innerHTML = '';
            var hr = gridRow(head, totalW, false);
            labelCols.forEach(function (cn) { cellEl(hr, COLW, 'head', cn); });
            cellEl(hr, 100, 'head num', 'TOTAL');
            colNames.forEach(function (cn) { var c = cellEl(hr, PVW, 'head num', cn); c.setAttribute('title', pivotName + ' = ' + cn); });

            var tr = gridRow(head, totalW, false);
            tr.className = 'vgrid-row totals';
            labelCols.forEach(function (cn, i) { cellEl(tr, COLW, null, i === 0 ? 'TOTAL' : ''); });
            cellEl(tr, 100, 'num', grand);
            colTotals.forEach(function (t) { cellEl(tr, PVW, 'num', t); });

            summary.textContent += '  ·  pivot ' + pivotName + ': ' + pvOrder.length + ' value(s)' + (hasOther ? (', showing top ' + shown.length + ' + OTHER') : '');

            var vl = virtualList(body, 26, function () { return rows.length; }, function (i) {
                var r = rows[i];
                var rd = gridRow(null, totalW, i % 2 === 1);
                for (var k = 0; k < labelCols.length; k++) cellEl(rd, COLW, null, r.vals[k]);
                cellEl(rd, 100, 'num', r.total);
                for (var k2 = 0; k2 < nCols; k2++) cellEl(rd, PVW, 'num dim', r.cells[k2] || '');
                return rd;
            });
            syncScroll(vl);

            exportRows = [];
            var hdr = labelCols.slice(); hdr.push('TOTAL');
            colNames.forEach(function (c) { hdr.push(pivotName + '=' + c); });
            exportRows.push(hdr);
            var trow = []; labelCols.forEach(function (c, i) { trow.push(i === 0 ? 'TOTAL' : ''); });
            trow.push(grand); colTotals.forEach(function (t) { trow.push(t); });
            exportRows.push(trow);
            rows.forEach(function (r) {
                var row = r.vals.slice(); row.push(r.total);
                r.cells.forEach(function (c) { row.push(c); });
                exportRows.push(row);
            });
        }

        dl.addEventListener('click', function () {
            if (!exportRows) return;
            var out = [];
            exportRows.forEach(function (r) { out.push(r.map(field).join(';')); });
            var blob = new Blob([String.fromCharCode(0xFEFF) + out.join(LF)], { type: 'text/csv;charset=utf-8' });
            var a = document.createElement('a'); a.href = URL.createObjectURL(blob);
            a.download = (name.replace(/\.[^.]+$/, '') || 'aggregation') + '_counts.csv'; a.click();
            setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
        });
        function field(s) { s = (s == null ? '' : String(s)); if (s.indexOf(';') >= 0 || s.indexOf('"') >= 0 || s.charCodeAt(0) === CR || s.indexOf(LF) >= 0) return '"' + s.replace(/"/g, '""') + '"'; return s; }
    }

    function renderTextServer(host, api, path, name, src, meta) {
        var PAGE = 500, totalLines = 0, cache = {}, inflight = {}, gutterW = 6;
        var tools = el('div', 'vwr-tools', host);
        var editBtn = el('button', 'btn sm', tools); text(editBtn, '✎ Edit');
        var info = el('span', 'dim small', tools); info.style.marginLeft = '10px';
        var body = el('div', 'vwr-body mono', host);
        fetch(api + 'text/meta?path=' + encodeURIComponent(path)).then(json).then(function (j) {
            if (!j.ok) { showErr(host, j.error); return; }
            totalLines = j.totalLines; gutterW = String(totalLines).length + 1;
            meta.textContent = totalLines + ' lines · ' + fmt(j.size); vl.redraw();
        });
        var vl = virtualList(body, 19, function () { return totalLines; }, function (i) {
            var pg = Math.floor(i / PAGE); var rows = cache[pg];
            var row = document.createElement('div'); row.className = 'tline';
            var g = el('span', 'tgutter', row); text(g, i + 1); g.style.minWidth = gutterW + 'ch';
            var c = el('span', 'tcontent', row); c.textContent = rows ? (rows[i - pg * PAGE] === '' ? ' ' : rows[i - pg * PAGE]) : '';
            if (!rows) ensure(pg);
            return row;
        });
        function ensure(pg) {
            if (cache[pg] || inflight[pg]) return; inflight[pg] = true;
            fetch(api + 'text/page?path=' + encodeURIComponent(path) + '&offset=' + (pg * PAGE) + '&limit=' + PAGE).then(json).then(function (j) { delete inflight[pg]; if (j.ok) { cache[pg] = j.lines; vl.redraw(); } }).catch(function () { delete inflight[pg]; });
        }
        editBtn.addEventListener('click', function () {
            info.textContent = 'loading for edit…';
            fetch(src).then(function (r) { return r.text(); }).then(function (content) {
                body.style.display = 'none';
                var ed = el('div', 'file-editor', host);
                var ta = el('textarea', 'file-editor-area', ed); ta.value = content;
                var save = el('button', 'btn sm primary', ed); text(save, '💾 Save');
                var cancel = el('button', 'btn sm', ed); text(cancel, 'Cancel'); cancel.style.marginLeft = '6px';
                editBtn.disabled = true; info.textContent = '';
                cancel.addEventListener('click', function () { ed.remove(); body.style.display = ''; editBtn.disabled = false; });
                save.addEventListener('click', function () {
                    var fd = new FormData(); fd.append('path', path); fd.append('content', ta.value);
                    fetch(api + 'files/save', { method: 'POST', body: fd }).then(json).then(function (j) {
                        if (j.ok) { window.location.reload(); } else { info.textContent = 'save failed: ' + (j.error || ''); }
                    });
                });
            });
        });
    }

    function renderTextClient(host, content, name, meta) {
        var lines = content.split(LF);
        if (lines.length && lines[lines.length - 1] === '') lines.pop();
        for (var i = 0; i < lines.length; i++) if (lines[i].length && lines[i].charCodeAt(lines[i].length - 1) === CR) lines[i] = lines[i].slice(0, -1);
        meta.textContent = lines.length + ' lines · ' + fmt(content.length);
        var body = el('div', 'vwr-body mono', host);
        var gw = String(lines.length).length + 1;
        virtualList(body, 19, function () { return lines.length; }, function (i) {
            var row = document.createElement('div'); row.className = 'tline';
            var g = el('span', 'tgutter', row); text(g, i + 1); g.style.minWidth = gw + 'ch';
            var c = el('span', 'tcontent', row); c.textContent = lines[i] === '' ? ' ' : lines[i];
            return row;
        }).redraw();
    }

    function initViewer(opts) {
        var host = opts.host; host.innerHTML = '';
        var head = el('div', 'vwr-head', host);
        var title = el('div', null, head);
        text(el('span', 'vwr-name', title), opts.name || 'file');
        var meta = el('span', 'vwr-meta dim small', title); meta.style.marginLeft = '12px';
        var dl = el('a', 'btn sm', head); text(dl, '⬇ Download'); dl.href = opts.src; dl.style.marginLeft = 'auto';
        var bodyHost = el('div', null, host);
        var isCsv = /\.(csv|tsv)$/i.test(opts.name || '');
        var server = opts.api && opts.path;
        if (server) {
            if (isCsv) renderCsvServer(bodyHost, opts.api, opts.path, opts.name || '', meta);
            else renderTextServer(bodyHost, opts.api, opts.path, opts.name || '', opts.src, meta);
        } else {
            var loading = el('div', 'dim', bodyHost); text(loading, 'Loading…');
            fetch(opts.src).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
                .then(function (content) { bodyHost.innerHTML = ''; renderTextClient(bodyHost, content, opts.name || '', meta); })
                .catch(function (e) { bodyHost.innerHTML = ''; showErr(bodyHost, e.message); });
        }
    }
    global.initViewer = initViewer;
})(window);
