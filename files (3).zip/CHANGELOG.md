# Changelog

All notable changes to the CMOD Legal Hold / Preservation template.

## [0.1] — initial

### Added
- Fillable DOCX template (US Letter, Arial) for a CMOD-on-IBM i legal hold / preservation document, Legal + IT audience.
- Front matter: document control table, table of contents, "template note" callout.
- Section 1 — Purpose & scope, with the "CMOD is a document archive, not a relational database" key-concept callout.
- Section 2 — System identification table.
- Section 3 — Data model (6.1.1): logical objects, two physical planes, AFP resources, and Figure 1 (`cmod_data_model.png`).
- Section 4 — Data dictionary (6.1.2): worked finance example + empty field table to complete; physical-to-logical and key-dataset notes.
- Section 5 — Sample queries (6.1.3): Level 1 (`arsdoc` / ODWEK, returns documents) and Level 2 (DB2 SQL, index only), with a "Critical" callout and code blocks.
- Section 6 — Query guidance (6.1.4): twelve peculiarities.
- Section 7 — Preservation & legal hold controls: expiration suspension, storage/resource/ASM-TSM preservation, access, chain of custody, hold register.
- Appendix A (glossary) and Appendix B (completion checklist).
- Placeholders highlighted in yellow as `[[ ... ]]`; header/footer with page numbering and classification placeholder.

### Build notes
- Generated with `generate_docx.js` (Node, `docx` v9.x).
- Post-build fix: docx-js emits an invalid `highlightCs` element with run highlighting. Strip it before issue:
  ```
  unpack → sed -i '/highlightCs/d' word/document.xml word/header1.xml → pack
  ```
  After this the document passes OOXML validation.

### To verify before issue
- All `arsdoc` flags and `ARS*` table/column names against the target CMOD version.
- Date-field storage representation and application-group segmentation on the instance.

## [1.0] — worked sample (Banca Cisalpina S.p.A.)

A fully populated copy of the template, issued as `CMOD_Legal_Hold_LH-2026-0147.docx`, using **fictitious** institution and data for illustration. All placeholders replaced; the "template note" and completion-checklist were converted to final content.

### Invented installation (sample)
- Bank: Banca Cisalpina S.p.A. (fictitious); matter LH-2026-0147 (supervisory inquiry into investment advisory / suitability, 2017–2024).
- Instance `ARCHPROD` on IBM Power S914 / IBM i 7.4; CMOD for i 10.5.0.4; Spectrum Protect (LTO-8) + legacy optical; CCSID 280.
- In-scope application groups: `STMTSEC`, `CUSTCOMM`, `CUSTDOCS`, `CONTRACTS`, `ASRES` (resources); out of scope: `STMTACCT`.
- Common key across datasets: `cust_id` (customer NDG). Full field tables, two-level sample queries, query guidance, preservation controls, hold register and verification record all populated.

> All names, numbers and identifiers are illustrative and do not refer to any real institution.
