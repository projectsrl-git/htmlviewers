package com.legalarchive.orchestrator.model.run;

public enum RunStatus {
    RUNNING, WAITING_APPROVAL, SUCCESS, FAILED, SKIPPED, REJECTED, ABORTED
}
